import React, { useState, useEffect } from 'react';
import { 
  Shield, Lock, Eye, LogOut, Globe, User as UserIcon, Settings, 
  AlertTriangle, Key, LogIn, ChevronDown, CheckCircle,
  Radio, Users, RefreshCw, AlertCircle, Wifi, WifiOff
} from 'lucide-react';

import { 
  Language, Anime, Season, Episode, User, ServiceConnections, 
  AdCampaign, RealtimeEvent, ContinueWatching, SecurityLog, FileAsset 
} from './types';

import { 
  INITIAL_LANGUAGES, DICTIONARY, INITIAL_ANIME, INITIAL_SEASONS, 
  INITIAL_EPISODES, INITIAL_USERS, INITIAL_SERVICE_CONNECTIONS, 
  INITIAL_ADS, INITIAL_SECURITY_LOGS, INITIAL_REALTIME_EVENTS, 
  INITIAL_FILE_ASSETS 
} from './db/mockData';

import ThemeStyles from './components/ThemeStyles';
import UserDashboard from './components/UserDashboard';
import AdminPanel from './components/AdminPanel';

const DEFAULT_THEME = {
  primaryColor: '#e11d48', // Elegant deep rose-600
  secondaryColor: '#be123c',
  bgColor: '#080a10', // Slate off-black cosmic slate
  cardBgColor: '#0f1322', // Deep velvet card blue
  textColor: '#e2e8f0', // Cold slate whites
  fontFamily: 'Space Grotesk',
  borderRadius: '12px',
  headerStyle: 'glass',
  heroSliderLayout: 'standard'
};

export default function App() {

  // Local Storage loaders
  const [animeList, setAnimeList] = useState<Anime[]>([]);
  const [seasonsList, setSeasonsList] = useState<Season[]>([]);
  const [episodesList, setEpisodesList] = useState<Episode[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [languagesList, setLanguagesList] = useState<Language[]>([]);
  const [themeConfig, setThemeConfig] = useState(DEFAULT_THEME);
  const [connections, setConnections] = useState<ServiceConnections>(INITIAL_SERVICE_CONNECTIONS);
  const [adCampaigns, setAdCampaigns] = useState<AdCampaign[]>([]);
  const [continueWatching, setContinueWatching] = useState<ContinueWatching[]>([]);
  
  // Custom interactive feeds
  const [realtimeEvents, setRealtimeEvents] = useState<RealtimeEvent[]>([]);
  const [securityLogs, setSecurityLogs] = useState<SecurityLog[]>([]);
  const [fileAssets, setFileAssets] = useState<FileAsset[]>([]);

  // Real-time server-sent events stream & presence mapping configurations
  const [realtimeConnected, setRealtimeConnected] = useState(false);
  const [onlinePresences, setOnlinePresences] = useState<any[]>([]);
  const [realtimeEnabled, setRealtimeEnabled] = useState(true);
  const [customRealtimeUrl, setCustomRealtimeUrl] = useState(() => localStorage.getItem('otaku_custom_realtime_url') || '');
  const [simulatedColleagueActive, setSimulatedColleagueActive] = useState(false);
  const [showSyncDropdown, setShowSyncDropdown] = useState(false);

  const handleSetCustomRealtimeUrl = (url: string) => {
    localStorage.setItem('otaku_custom_realtime_url', url);
    setCustomRealtimeUrl(url);
    triggerToast(url ? 'Custom real-time Stream Connection Link updated!' : 'Restored default Real-time connection endpoint.');
  };

  // User details & login statuses
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [activeTabAdmin, setActiveTabAdmin] = useState(false);

  // Translation Locale
  const [currentLocale, setCurrentLocale] = useState('en');

  // Trigger feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Helper to persist state to the central Express server
  const saveKeyToServer = async (key: string, data: any) => {
    try {
      await fetch('/api/update-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ key, data }),
      });
    } catch (err) {
      console.error(`Failed to push key ${key} to backend:`, err);
    }
  };

  // Pull complete synchronized dataset from backend database
  const loadSharedData = async () => {
    try {
      const res = await fetch('/api/shared-data');
      if (res.ok) {
        const db = await res.json();
        if (db.anime) setAnimeList(db.anime);
        if (db.seasons) setSeasonsList(db.seasons);
        if (db.episodes) setEpisodesList(db.episodes);
        if (db.users) setUsersList(db.users);
        if (db.languages) setLanguagesList(db.languages);
        if (db.theme) setThemeConfig(db.theme);
        if (db.connections) setConnections(db.connections);
        if (db.ads) setAdCampaigns(db.ads);
        if (db.realtimeEvents) setRealtimeEvents(db.realtimeEvents);
        if (db.fileAssets) setFileAssets(db.fileAssets);
        if (db.securityLogs) setSecurityLogs(db.securityLogs);
      }
    } catch (err) {
      console.error('Failed to retrieve media library state from backend:', err);
    }
  };

  // Deep Real-time SSE Connection Stream
  useEffect(() => {
    if (!realtimeEnabled) {
      setRealtimeConnected(false);
      return;
    }

    const userId = currentUser?.id || `anon-${Date.now()}`;
    const userName = currentUser?.name || 'Anonymous Viewer';
    const userAvatar = currentUser?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&q=80';
    const userRole = currentUser?.role || 'User';

    const base = customRealtimeUrl ? customRealtimeUrl : '/api/realtime-stream';
    const separator = base.includes('?') ? '&' : '?';
    const url = `${base}${separator}userId=${encodeURIComponent(userId)}&userName=${encodeURIComponent(userName)}&userAvatar=${encodeURIComponent(userAvatar)}&userRole=${encodeURIComponent(userRole)}`;
    
    let eventSource: EventSource | null = null;
    let fallbackInterval: any = null;

    try {
      eventSource = new EventSource(url);
      setRealtimeConnected(true);

      eventSource.onopen = () => {
        setRealtimeConnected(true);
      };

      eventSource.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === 'state' && payload.db) {
            const db = payload.db;
            if (db.anime) setAnimeList(db.anime);
            if (db.seasons) setSeasonsList(db.seasons);
            if (db.episodes) setEpisodesList(db.episodes);
            if (db.users) setUsersList(db.users);
            if (db.languages) setLanguagesList(db.languages);
            if (db.theme) setThemeConfig(db.theme);
            if (db.connections) setConnections(db.connections);
            if (db.ads) setAdCampaigns(db.ads);
            if (db.realtimeEvents) setRealtimeEvents(db.realtimeEvents);
            if (db.fileAssets) setFileAssets(db.fileAssets);
            if (db.securityLogs) setSecurityLogs(db.securityLogs);
          } else if (payload.type === 'presence' && payload.presence) {
            setOnlinePresences(payload.presence);
          }
        } catch (e) {
          console.error("Failed parsing incoming SSE message event stream", e);
        }
      };

      eventSource.onerror = (err) => {
        setRealtimeConnected(false);
        if (eventSource) {
          eventSource.close();
        }
      };
    } catch (err) {
      console.error("Failed establishing Real-time SSE Client Connection", err);
      setRealtimeConnected(false);
    }

    // Dynamic lightweight active status sync helper fallback every 6 seconds
    fallbackInterval = setInterval(() => {
      if (!realtimeConnected || !eventSource || eventSource.readyState === EventSource.CLOSED) {
        loadSharedData();
      }
    }, 6000);

    return () => {
      if (eventSource) {
        eventSource.close();
      }
      if (fallbackInterval) {
        clearInterval(fallbackInterval);
      }
    };
  }, [currentUser, realtimeEnabled, customRealtimeUrl]);

  // Simulated Colleague Interactive Loop
  useEffect(() => {
    if (!simulatedColleagueActive) return;

    const colleague = {
      userId: 'colleague-kazuto',
      name: 'Kazuto Kirigaya (Anime Editor)',
      avatar: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=100&q=80',
      role: 'Editor',
      lastSeen: Date.now()
    };

    // Inject colleague locally to display visual active badge
    setOnlinePresences(prev => {
      const exists = prev.some(p => p.userId === colleague.userId);
      return exists ? prev : [colleague, ...prev];
    });

    const triggerColleagueAction = async () => {
      // Pick simulated activity
      const actions = [
        async () => {
          // Push a Simulated Realtime Event
          const newEvent: RealtimeEvent = {
            id: `evt-${Date.now()}`,
            eventName: 'Simulated Subtitle Upload',
            timestamp: new Date().toLocaleTimeString(),
            description: 'Kazuto Kirigaya uploaded custom Japanese translation tracks.',
            status: 'success'
          };
          handleAddRealtimeEvent(newEvent);
          triggerToast('Colleague Kazuto published a Japanese subtitle track!');
        },
        async () => {
          // Push a Simulated Audit Security Log
          const newLog: SecurityLog = {
            id: `sec-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            email: 'kazuto@otaku.io',
            action: 'Published Episode Metadata',
            status: 'Success',
            ipAddress: '192.168.1.99',
            device: 'Amusphere NerveGear OS',
            country: 'Japan'
          };
          const newList = [newLog, ...securityLogs];
          handleUpdateSecurityLogs(newList);
          triggerToast('Colleague Kazuto triggered an admin session security audit.');
        },
        async () => {
          // Push a File Asset
          const newAsset: FileAsset = {
            id: `asset-${Date.now()}`,
            name: 'Sword_Art_Online_Prerelease_Teaser.mp4',
            type: 'video',
            url: 'https://sample-videos.com/video321/mp4/710/big_buck_bunny_720p_1mb.mp4',
            size: '8.4 MB',
            uploadedAt: new Date().toLocaleDateString()
          };
          handleAddFileAsset(newAsset);
          triggerToast('Colleague Kazuto uploaded a Sword Art Online teaser trailer asset.');
        }
      ];

      const chosenAction = actions[Math.floor(Math.random() * actions.length)];
      await chosenAction();
    };

    const interval = setInterval(() => {
      triggerColleagueAction();
    }, 12000);

    return () => {
      clearInterval(interval);
    };
  }, [simulatedColleagueActive, realtimeEvents, securityLogs, fileAssets]);

  // Main local loader and tab config hook
  useEffect(() => {
    // Initial data hydration from backend Server
    loadSharedData();

    // Focus syncer: pull update as soon as tab/window gains active visibility focus
    const handleWindowFocus = () => {
      loadSharedData();
    };
    window.addEventListener('focus', handleWindowFocus);

    // Continue watching details (kept client-local to avoid cross-user timestamp disruption)
    const localCW = localStorage.getItem('otaku_cw');
    if (localCW) {
      setContinueWatching(JSON.parse(localCW));
    }

    // Static dictionaries fallback configuration
    const localDict = localStorage.getItem('otaku_dictionary');
    if (!localDict) {
      localStorage.setItem('otaku_dictionary', JSON.stringify(DICTIONARY));
    }

    // Current session persistence
    const savedSession = localStorage.getItem('otaku_current_user');
    if (savedSession) {
      setCurrentUser(JSON.parse(savedSession));
    } else {
      const defaultUser = INITIAL_USERS.find(u => u.email === 'user.mufasa@gmail.com');
      if (defaultUser) {
        setCurrentUser(defaultUser);
        localStorage.setItem('otaku_current_user', JSON.stringify(defaultUser));
      }
    }

    // Hash or query link trigger support for testing admin
    if (window.location.hash === '#admin' || window.location.search.includes('admin=true')) {
      setLoginModalOpen(true);
      setLoginEmail('tanvirahmeda98@gmail.com');
      setLoginPassword('tanvir12#');
    }

    return () => {
      window.removeEventListener('focus', handleWindowFocus);
    };
  }, []);

  // Set Default Dynamic Locale translation on load
  useEffect(() => {
    if (languagesList.length > 0) {
      const def = languagesList.find(l => l.isDefault);
      if (def) {
        setCurrentLocale(def.code);
      }
    }
  }, [languagesList]);

  // Unified persistent State Sinks synchronized globally
  const handleUpdateAnimeList = (newList: Anime[]) => {
    setAnimeList(newList);
    localStorage.setItem('otaku_anime', JSON.stringify(newList));
    saveKeyToServer('anime', newList);
  };

  const handleUpdateSeasonsList = (newList: Season[]) => {
    setSeasonsList(newList);
    localStorage.setItem('otaku_seasons', JSON.stringify(newList));
    saveKeyToServer('seasons', newList);
  };

  const handleUpdateEpisodesList = (newList: Episode[]) => {
    setEpisodesList(newList);
    localStorage.setItem('otaku_episodes', JSON.stringify(newList));
    saveKeyToServer('episodes', newList);
  };

  const handleUpdateUsersList = (newList: User[]) => {
    setUsersList(newList);
    localStorage.setItem('otaku_users', JSON.stringify(newList));
    saveKeyToServer('users', newList);
    
    // Auto sync self if current session details get overridden
    if (currentUser) {
      const updatedSelf = newList.find(u => u.id === currentUser.id);
      if (updatedSelf) {
        setCurrentUser(updatedSelf);
        localStorage.setItem('otaku_current_user', JSON.stringify(updatedSelf));
      }
    }
  };

  const handleUpdateLanguagesList = (newList: Language[]) => {
    setLanguagesList(newList);
    localStorage.setItem('otaku_langs', JSON.stringify(newList));
    saveKeyToServer('languages', newList);
    
    const def = newList.find(l => l.isDefault);
    if (def) {
      setCurrentLocale(def.code);
    }
  };

  const handleUpdateThemeConfig = (newConfig: any) => {
    setThemeConfig(newConfig);
    localStorage.setItem('otaku_theme', JSON.stringify(newConfig));
    saveKeyToServer('theme', newConfig);
  };

  const handleUpdateConnections = (newConns: ServiceConnections) => {
    setConnections(newConns);
    localStorage.setItem('otaku_conns', JSON.stringify(newConns));
    saveKeyToServer('connections', newConns);
  };

  const handleUpdateAdCampaigns = (newList: AdCampaign[]) => {
    setAdCampaigns(newList);
    localStorage.setItem('otaku_ads', JSON.stringify(newList));
    saveKeyToServer('ads', newList);
  };

  const handleUpdateContinueWatching = (item: ContinueWatching) => {
    const list = continueWatching.filter(c => c.episodeId !== item.episodeId);
    const updated = [item, ...list].slice(0, 10);
    setContinueWatching(updated);
    localStorage.setItem('otaku_cw', JSON.stringify(updated));
  };

  const handleAddRealtimeEvent = (evt: RealtimeEvent) => {
    const newList = [evt, ...realtimeEvents].slice(0, 50);
    setRealtimeEvents(newList);
    localStorage.setItem('otaku_realtime_events', JSON.stringify(newList));
    saveKeyToServer('realtimeEvents', newList);
  };

  const handleAddFileAsset = (asset: FileAsset) => {
    const newList = [asset, ...fileAssets];
    setFileAssets(newList);
    localStorage.setItem('otaku_files', JSON.stringify(newList));
    saveKeyToServer('fileAssets', newList);
  };

  const handleUpdateSecurityLogs = (newList: SecurityLog[]) => {
    setSecurityLogs(newList);
    localStorage.setItem('otaku_security_logs', JSON.stringify(newList));
    saveKeyToServer('securityLogs', newList);
  };

  // Login handler supporting hidden admin and regular accounts
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    // Specific user specified hidden admin account matching requirement:
    // Email: tanvirahmeda98@gmail.com
    // Pass: tanvir12#
    const trimmedEmail = loginEmail.trim().toLowerCase();
    
    if (trimmedEmail === 'tanvirahmeda98@gmail.com' && loginPassword === 'tanvir12#') {
      const adminAcc = usersList.find(u => u.email === 'tanvirahmeda98@gmail.com');
      if (adminAcc) {
        // Enforce account active status
        if (adminAcc.status !== 'active') {
          setLoginError('This administrator clearance is suspended!');
          return;
        }
        setCurrentUser(adminAcc);
        localStorage.setItem('otaku_current_user', JSON.stringify(adminAcc));
      } else {
        // Fallback construct if parsed list was custom cleared
        const fallbackAdmin: User = {
          id: 'u-1',
          name: 'Tanvir Ahmed',
          email: 'tanvirahmeda98@gmail.com',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100',
          role: 'Super Admin',
          status: 'active',
          registeredAt: '2026-06-07'
        };
        setCurrentUser(fallbackAdmin);
        localStorage.setItem('otaku_current_user', JSON.stringify(fallbackAdmin));
        // Add to list
        handleUpdateUsersList([...usersList, fallbackAdmin]);
      }

      // Save security log
      const logSec: SecurityLog = {
        id: 'sec-' + Date.now(),
        timestamp: new Date().toISOString().replace('T', ' ').split('.')[0],
        email: 'tanvirahmeda98@gmail.com',
        action: 'System Dashboard Entrance (Local)',
        status: 'Success',
        ipAddress: '103.112.54.91',
        device: 'Chrome / Linux Container',
        country: 'Bangladesh'
      };
      const updatedSecList = [logSec, ...securityLogs];
      handleUpdateSecurityLogs(updatedSecList);

      // Trigger realtime log update
      handleAddRealtimeEvent({
        id: 'evt-' + Date.now(),
        eventName: 'user_login',
        timestamp: 'Now',
        description: 'Super Admin "Tanvir Ahmed" gained entrance into the OTT cockpit.',
        status: 'success'
      });

      triggerToast('Welcome Back, Commander Tanvir! 🛡️ Dashboard fully unlocked.');
      setLoginModalOpen(false);
      setActiveTabAdmin(true); // Open admin dashboard immediately
      return;
    }

    // Normal User lookups
    const matchUser = usersList.find(
      u => u.email.toLowerCase() === trimmedEmail
    );

    if (matchUser) {
      if (matchUser.status !== 'active') {
        setLoginError('This user account access is suspended or banned.');
        return;
      }
      setCurrentUser(matchUser);
      localStorage.setItem('otaku_current_user', JSON.stringify(matchUser));
      
      const logSec: SecurityLog = {
        id: 'sec-' + Date.now(),
        timestamp: new Date().toISOString().replace('T', ' ').split('.')[0],
        email: matchUser.email,
        action: 'Normal User login',
        status: 'Success',
        ipAddress: '103.115.22.4',
        device: 'Safari / iPhone 15 Pro',
        country: 'Bangladesh'
      };
      const updatedSecLogs = [logSec, ...securityLogs];
      handleUpdateSecurityLogs(updatedSecLogs);

      triggerToast(`Successfully logged in as: ${matchUser.name}`);
      setLoginModalOpen(false);
    } else {
      // Dynamic Auto-Registration for any entered Gmail/Credentials as Normal User
      const emailPrefix = trimmedEmail.split('@')[0] || 'user';
      const cleanName = emailPrefix.charAt(0).toUpperCase() + emailPrefix.slice(1);
      
      const avatarPool = [
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&q=80',
        'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
        'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100&q=80',
        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80'
      ];
      const randomAvatar = avatarPool[Math.floor(Math.random() * avatarPool.length)];

      const newUser: User = {
        id: 'u-' + Date.now(),
        name: cleanName,
        email: trimmedEmail,
        avatar: randomAvatar,
        role: 'User',
        status: 'active',
        registeredAt: new Date().toISOString().split('T')[0]
      };

      const updatedUsersList = [...usersList, newUser];
      handleUpdateUsersList(updatedUsersList);

      setCurrentUser(newUser);
      localStorage.setItem('otaku_current_user', JSON.stringify(newUser));

      const logSec: SecurityLog = {
        id: 'sec-' + Date.now(),
        timestamp: new Date().toISOString().replace('T', ' ').split('.')[0],
        email: trimmedEmail,
        action: 'New User Registered & Logged In',
        status: 'Success',
        ipAddress: '103.115.22.5',
        device: 'Chrome Mobile / Android',
        country: 'Bangladesh'
      };
      const updatedSecLogs = [logSec, ...securityLogs];
      handleUpdateSecurityLogs(updatedSecLogs);

      triggerToast(`Registered and logged in as: ${cleanName}`);
      setLoginModalOpen(false);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('otaku_current_user');
    setActiveTabAdmin(false);
    triggerToast('Logged out of system dashboard sessions.');
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Active validation dictionary reference
  const activeDict = localStorage.getItem('otaku_dictionary') 
    ? JSON.parse(localStorage.getItem('otaku_dictionary')!) 
    : DICTIONARY;

  const showAdminAccessButton = currentUser?.role === 'Super Admin' || currentUser?.role === 'Admin' || currentUser?.role === 'Moderator' || currentUser?.role === 'Uploader';

  return (
    <>
      {/* Global CSS Style Custom Overrides generated dynamically */}
      <ThemeStyles theme={themeConfig} />

      {/* Floating Application Toast Alerts */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-gray-900 border border-gray-800 text-gray-100 font-semibold text-xs px-5 py-3 rounded-xl shadow-2xl z-55 flex items-center gap-2.5 antialiased">
          <CheckCircle className="h-4.5 w-4.5 text-red-500 animate-pulse" /> {toastMessage}
        </div>
      )}

      {/* Primary Landing Page Nav bar header */}
      <header className="sticky top-0 w-full bg-gray-950/80 border-b border-gray-900 flex items-center justify-between px-6 py-3.5 z-40 backdrop-blur-md">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTabAdmin(false)}>
            <div className="h-7 w-7 bg-red-600 rounded flex items-center justify-center font-black text-white text-base shadow shadow-red-600/30">
              Ω
            </div>
            <span className="font-sans font-black tracking-tighter text-white uppercase text-base animate-pulse">
              OTAKU UNIVERSE
            </span>
          </div>

          {/* Quick hidden Admin bypass details */}
          <span className="hidden md:inline font-mono text-[9px] text-gray-500 font-semibold">
            SEC_TUNNEL_PORT: 3000
          </span>
        </div>

        {/* Right Nav Utilities */}
        <div className="flex items-center gap-4">
          
          {/* Global Language Selector Dropdown */}
          <div className="flex items-center gap-2 relative">
            <Globe className="h-4 w-4 text-gray-400" />
            <select
              value={currentLocale}
              onChange={(e) => setCurrentLocale(e.target.value)}
              className="bg-transparent border-0 text-xs font-semibold text-gray-300 hover:text-white focus:ring-0 cursor-pointer pr-5 py-1.5 focus:outline-none"
            >
              {languagesList.map((lang) => (
                <option key={lang.code} value={lang.code} className="bg-gray-950 text-white text-xs">
                  {lang.name}
                </option>
              ))}
            </select>
          </div>

          {/* Glowing Admin Control panel button toggles */}
          {showAdminAccessButton && (
            <button
              onClick={() => setActiveTabAdmin(!activeTabAdmin)}
              className="px-3.5 py-1.5 rounded-lg border border-red-500/35 bg-red-600/10 text-red-400 text-xs font-extrabold hover:bg-red-600 hover:text-white transition-all flex items-center gap-1.5 shadow-md shadow-red-600/10 animate-bounce"
            >
              <Settings className="h-4 w-4" /> Admin Console
            </button>
          )}

          {/* Identity details button */}
          {currentUser ? (
            <div className="flex items-center gap-2.5">
              <img 
                src={currentUser.avatar} 
                alt="" 
                className="h-7 w-7 rounded-full border border-gray-800" 
              />
              <span className="hidden md:inline text-xs font-bold text-gray-300">
                {currentUser.name}
              </span>
              <button 
                onClick={handleLogout} 
                title="Log Out"
                className="text-gray-400 hover:text-red-500 transition-colors p-1"
              >
                <LogOut className="h-4.5 w-4.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setLoginModalOpen(true)}
              className="bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs px-3.5 py-1.5 rounded-lg shadow transition flex items-center gap-1 cursor-pointer"
            >
              <LogIn className="h-3.5 w-3.5" /> Sign In
            </button>
          )}

        </div>
      </header>

      {/* CORE CONTENT SWITCH ROUTE */}
      {activeTabAdmin && showAdminAccessButton ? (
        <AdminPanel
          onClose={() => setActiveTabAdmin(false)}
          currentUser={currentUser}
          animeList={animeList}
          onUpdateAnimeList={handleUpdateAnimeList}
          seasonsList={seasonsList}
          onUpdateSeasonsList={handleUpdateSeasonsList}
          episodesList={episodesList}
          onUpdateEpisodesList={handleUpdateEpisodesList}
          usersList={usersList}
          onUpdateUsersList={handleUpdateUsersList}
          languagesList={languagesList}
          onUpdateLanguagesList={handleUpdateLanguagesList}
          themeConfig={themeConfig}
          onUpdateThemeConfig={handleUpdateThemeConfig}
          connections={connections}
          onUpdateConnections={handleUpdateConnections}
          adCampaigns={adCampaigns}
          onUpdateAdCampaigns={handleUpdateAdCampaigns}
          realtimeEvents={realtimeEvents}
          onAddRealtimeEvent={handleAddRealtimeEvent}
          securityLogs={securityLogs}
          fileAssets={fileAssets}
          onAddFileAsset={handleAddFileAsset}
          realtimeConnected={realtimeConnected}
          realtimeEnabled={realtimeEnabled}
          onSetRealtimeEnabled={setRealtimeEnabled}
          simulatedColleagueActive={simulatedColleagueActive}
          onSetSimulatedColleagueActive={setSimulatedColleagueActive}
          onlinePresences={onlinePresences}
          onTriggerSharedDataRefresh={loadSharedData}
          customRealtimeUrl={customRealtimeUrl}
          onSetCustomRealtimeUrl={handleSetCustomRealtimeUrl}
        />
      ) : (
        <UserDashboard
          animeList={animeList}
          seasonsList={seasonsList}
          episodesList={episodesList}
          continueWatchingList={continueWatching}
          onUpdateContinueWatching={handleUpdateContinueWatching}
          activeAds={adCampaigns}
          locale={currentLocale}
          dictionary={activeDict}
          onOpenAdminLogin={() => setLoginModalOpen(true)}
          userSession={currentUser}
          onLogout={handleLogout}
        />
      )}

      {/* SIGN IN HANDLER MODAL (Supports Hidden Super Admin) */}
      {loginModalOpen && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-55 flex items-center justify-center p-4">
          <div className="bg-gray-950 border border-gray-900 rounded-2xl max-w-sm w-full p-6 text-left shadow-2xl relative space-y-4">
            
            {/* Close */}
            <button
              onClick={() => setLoginModalOpen(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-white"
            >
              <XIcon className="h-4 w-4" />
            </button>

            <div className="text-center space-y-1">
              <div className="h-10 w-10 bg-red-600 rounded-lg flex items-center justify-center mx-auto text-white font-black text-lg">
                Ω
              </div>
              <h2 className="text-sm font-black text-white uppercase tracking-wider">Sign In to Dashboard</h2>
              <p className="text-[10px] text-gray-500 font-semibold font-mono">Hidden Admin trigger routing supported</p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              
              {loginError && (
                <div className="p-2.5 rounded bg-red-600/10 border border-red-500/20 text-red-500 text-[10px] font-bold leading-relaxed flex items-center gap-1.5 shadow">
                  <AlertTriangle className="h-4 w-4 flex-shrink-0" /> {loginError}
                </div>
              )}

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase">GMAIL ADDRESS</label>
                <input
                  type="email"
                  required
                  placeholder="your.email@gmail.com"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs text-white placeholder-gray-650 focus:outline-none focus:border-red-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase">ACCESS SECURE PASSWORD</label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    placeholder="••••••••"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-805 rounded p-2 pr-10 text-xs text-white placeholder-gray-650 focus:outline-none focus:border-red-600 font-sans"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-all cursor-pointer"
                    title={showPassword ? "Hide Password" : "Show Password"}
                  >
                    <Eye className={`h-4.5 w-4.5 ${showPassword ? 'text-red-500' : 'text-gray-500'}`} />
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg shadow-md transition"
              >
                Connect Credentials
              </button>
            </form>

            <div className="pt-2 text-center border-t border-gray-901">
              <span className="text-[10.5px] font-semibold text-gray-600">
                Tip: Enter Administrator credentials above to login as Super Admin and unlock full CMS.
              </span>
            </div>

          </div>
        </div>
      )}

    </>
  );
}

// Minimal helpers
function XIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </svg>
  );
}
