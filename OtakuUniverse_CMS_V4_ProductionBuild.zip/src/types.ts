export interface Language {
  code: string;
  name: string;
  isDefault: boolean;
}

export interface TranslationMap {
  [key: string]: {
    [lang: string]: string;
  };
}

export interface ThemeConfig {
  primaryColor: string;
  secondaryColor: string;
  bgColor: string;
  cardBgColor: string;
  textColor: string;
  fontFamily: string;
  borderRadius: string;
  headerStyle: 'glass' | 'solid' | 'transparent';
  heroSliderLayout: 'standard' | 'minimal' | 'cinematic';
}

export interface Review {
  id: string;
  userName: string;
  userAvatar: string;
  rating: number;
  content: string;
  createdAt: string;
}

export interface Character {
  id: string;
  name: string;
  role: 'Main' | 'Supporting';
  image: string;
  voiceActor: string;
}

export interface Anime {
  id: string;
  name: string;
  altNames: string[];
  poster: string;
  banner: string;
  trailer: string;
  synopsis: string;
  studio: string;
  year: number;
  status: 'Ongoing' | 'Completed' | 'Upcoming';
  genres: string[];
  tags: string[];
  views: number;
  likes: number;
  watchTime: number; // in hours
  favorites: number;
  rating: number;
  bannerVideoUrl?: string;
  reviews: Review[];
  characters: Character[];
  screenshots: string[];
}

export interface Season {
  id: string;
  animeId: string;
  name: string;
  number: number;
}

export interface SourceLink {
  id: string;
  label: string; // e.g., 'Google Drive', 'Mega'
  url: string;
}

export interface Episode {
  id: string;
  seasonId: string;
  animeId: string;
  name: string;
  number: number;
  duration: number; // minutes
  videoUrl: string;
  subtitleUrl: string;
  subtitles?: { label: string; src: string; lang: string }[];
  downloads: SourceLink[];
  sources?: SourceLink[];
  views: number;
  skipIntroStart?: number; // seconds
  skipIntroEnd?: number;
  skipOutroStart?: number;
  language?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: 'Super Admin' | 'Admin' | 'Moderator' | 'Uploader' | 'Editor' | 'Support' | 'User';
  status: 'active' | 'banned' | 'suspended';
  registeredAt: string;
}

export interface ServiceConnections {
  websiteUrl: string;
  realtimeEnabled: boolean;
  socketUrl: string;
  socketPath: string;
  reconnectAttempts: number;
  reconnectDelay: number;
  socketStatus: 'connected' | 'disconnected' | 'connecting';
  
  mongoUri: string;
  mongoStatus: 'connected' | 'disconnected' | 'connecting';
  
  firebaseConfig: {
    apiKey: string;
    projectId: string;
    appId: string;
    authDomain: string;
    storageBucket: string;
  };
  firebaseStatus: 'connected' | 'disconnected';
  
  storageProvider: 'cloudinary' | 'bunny' | 's3' | 'backblaze' | 'local';
  cloudinaryConfig: {
    cloudName: string;
    apiKey: string;
    apiSecret: string;
  };
  bunnyConfig: {
    storageZone: string;
    apiKey: string;
    cdnUrl: string;
  };
  storageStatus: 'connected' | 'disconnected';
  
  smtpConfig: {
    host: string;
    port: number;
    user: string;
    pass: string;
  };
  smtpStatus: 'connected' | 'disconnected';
  
  telegramConfig: {
    botToken: string;
    channelId: string;
    groupId: string;
  };
  telegramStatus: 'connected' | 'disconnected';
  
  discordWebhookUrl?: string;
  discordWebhookEnabled?: boolean;
  googleAnalyticsId?: string;
  adsensePublisherId?: string;
}

export interface AdCampaign {
  id: string;
  title: string;
  type: 'pre-roll' | 'mid-roll' | 'post-roll' | 'overlay' | 'banner-top' | 'banner-sidebar' | 'banner-footer' | 'popup';
  imageUrl?: string;
  videoUrl?: string; // for rolls
  ctaLink: string;
  targetCountry: string; // 'All' or specific country name
  enabled: boolean;
  startTime?: string; // MM:SS minutes in player
  duration?: number; // duration of ad video in seconds
  popupTrigger?: 'immediate' | '10s' | 'daily' | 'first-visit';
  impressions: number;
  clicks: number;
}

export interface RealtimeEvent {
  id: string;
  eventName: string; // e.g. 'anime_created'
  timestamp: string;
  description: string;
  status: 'success' | 'warn' | 'info';
}

export interface ContinueWatching {
  animeId: string;
  episodeId: string;
  timestamp: number; // in seconds
  duration: number; // in seconds
  updatedAt: string;
}

export interface SecurityLog {
  id: string;
  timestamp: string;
  email: string;
  action: string;
  status: 'Success' | 'Failed';
  ipAddress: string;
  device: string;
  country: string;
}

export interface FileAsset {
  id: string;
  name: string;
  type: 'image' | 'video' | 'subtitle' | 'logo';
  url: string;
  size: string;
  uploadedAt: string;
}
