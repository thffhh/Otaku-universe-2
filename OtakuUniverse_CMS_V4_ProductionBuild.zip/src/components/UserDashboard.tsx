import React, { useState, useEffect } from 'react';
import { 
  Tv, Film, Search, Flame, Clock, Heart, Play, Star, ChevronLeft, 
  ChevronRight, Calendar, User, MessageSquare, ExternalLink, X, Info
} from 'lucide-react';
import { Anime, Episode, Season, ContinueWatching, AdCampaign, Language, TranslationMap } from '../types';
import CustomPlayer from './CustomPlayer';

interface UserDashboardProps {
  animeList: Anime[];
  seasonsList: Season[];
  episodesList: Episode[];
  continueWatchingList: ContinueWatching[];
  onUpdateContinueWatching: (item: ContinueWatching) => void;
  activeAds: AdCampaign[];
  locale: string;
  dictionary: TranslationMap;
  onOpenAdminLogin: () => void;
  userSession: any;
  onLogout: () => void;
}

export default function UserDashboard({
  animeList,
  seasonsList,
  episodesList,
  continueWatchingList,
  onUpdateContinueWatching,
  activeAds,
  locale,
  dictionary,
  onOpenAdminLogin,
  userSession,
  onLogout
}: UserDashboardProps) {

  // UI state managers
  const [selectedAnime, setSelectedAnime] = useState<Anime | null>(null);
  const [selectedEpisode, setSelectedEpisode] = useState<Episode | null>(null);
  const [activeSeasonNum, setActiveSeasonNum] = useState<number>(1);
  const [activeLanguage, setActiveLanguage] = useState<'Japanese' | 'English' | 'Hindi' | 'Bangla'>('Japanese');
  
  // Search
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<Anime[]>([]);
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);

  // Active Slider index
  const [heroIndex, setHeroIndex] = useState(0);

  // User Review form state
  const [revRating, setRevRating] = useState(10);
  const [revContent, setRevContent] = useState('');

  // Watch State
  const [playerAnime, setPlayerAnime] = useState<Anime | null>(null);

  // Translation helper
  const translate = (key: string) => {
    return dictionary[key]?.[locale] || dictionary[key]?.['en'] || key;
  };

  // Autoplay hero slider
  useEffect(() => {
    if (playerAnime) return; // don't cycle when watching
    const timer = setInterval(() => {
      setHeroIndex((prev) => (prev + 1) % Math.max(1, animeList.slice(0, 3).length));
    }, 8500);
    return () => clearInterval(timer);
  }, [animeList, playerAnime]);

  // Handle live type search suggestions
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResult([]);
      setShowSearchDropdown(false);
      return;
    }

    const query = searchQuery.toLowerCase();
    const matches = animeList.filter((a) => {
      const matchName = a.name.toLowerCase().includes(query);
      const matchAlt = a.altNames.some(alt => alt.toLowerCase().includes(query));
      const matchStudio = a.studio.toLowerCase().includes(query);
      const matchGenres = a.genres.some(g => g.toLowerCase().includes(query));
      const matchTags = a.tags.some(t => t.toLowerCase().includes(query));
      const matchChar = a.characters?.some(ch => ch.name.toLowerCase().includes(query) || ch.voiceActor.toLowerCase().includes(query));
      
      return matchName || matchAlt || matchStudio || matchGenres || matchTags || matchChar;
    });

    setSearchResult(matches);
    setShowSearchDropdown(true);
  }, [searchQuery, animeList]);

  // Watch actions
  const startWatchingEpisode = (episode: Episode, anime: Anime) => {
    setPlayerAnime(anime);
    setSelectedEpisode(episode);
    setSelectedAnime(null); // Close detail view
    
    if (episode.language) {
      setActiveLanguage(episode.language as any);
    } else {
      setActiveLanguage('Japanese');
    }
    
    // Auto increment views click mock tracker
    episode.views += 1;
    anime.views += 1;

    // Scroll to top safely
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Exit watching
  const stopWatching = () => {
    setPlayerAnime(null);
    setSelectedEpisode(null);
  };

  // Submit dynamic review
  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAnime || !revContent) return;

    const newReview = {
      id: 'rev-' + Date.now(),
      userName: userSession ? userSession.name : 'Web Guest Viewer',
      userAvatar: userSession ? userSession.avatar : 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100',
      rating: revRating,
      content: revContent,
      createdAt: new Date().toISOString().split('T')[0]
    };

    const updatedReviews = [newReview, ...selectedAnime.reviews];
    
    // Recalc mean rating
    const total = updatedReviews.reduce((sum, r) => sum + r.rating, 0);
    selectedAnime.rating = parseFloat((total / updatedReviews.length).toFixed(1));
    selectedAnime.reviews = updatedReviews;

    // Reset Form
    setRevContent('');
    setRevRating(10);
  };

  // Handle ad clicks logging to console safely
  const handleAdClick = (ad: AdCampaign) => {
    ad.clicks += 1;
  };

  // Filter lists helpers
  const trendingAnime = [...animeList].sort((a,b) => b.rating - a.rating).slice(0, 4);
  const latestEpisodes = episodesList.slice(0, 5);
  const popularWeek = [...animeList].sort((a,b) => b.views - a.views).slice(0, 4);
  const upcomingReleases = animeList.filter(a => a.status === 'Upcoming');

  const bannerAdTop = activeAds.find(ad => ad.enabled && ad.type === 'banner-top');
  const bannerAdSidebar = activeAds.find(ad => ad.enabled && ad.type === 'banner-sidebar');
  const bannerAdFooter = activeAds.find(ad => ad.enabled && ad.type === 'banner-footer');

  return (
    <div className="min-h-screen bg-gray-950 pb-16 font-sans">
      
      {/* Dynamic Top Ads layout */}
      {bannerAdTop && (
        <a 
          href={bannerAdTop.ctaLink} 
          target="_blank" 
          rel="no-referrer"
          onClick={() => handleAdClick(bannerAdTop)}
          className="block w-full text-center relative hover:opacity-95 transition-opacity"
        >
          <img 
            src={bannerAdTop.imageUrl} 
            alt="Ad Banner" 
            className="w-full h-12 md:h-16 object-cover" 
          />
          <div className="absolute inset-0 bg-black/35 flex items-center justify-center">
            <span className="text-white text-xs md:text-sm font-black tracking-wide flex items-center gap-2">
              <span className="text-[9px] uppercase font-bold bg-amber-500/20 text-yellow-400 border border-yellow-500/30 px-1.5 py-0.5 rounded leading-none">SPONSORED AD</span>
              {bannerAdTop.title} • CLICK TO EXPLORE <ExternalLink className="h-4.5 w-4.5" />
            </span>
          </div>
        </a>
      )}

      {/* Embedded Watch Page Video Viewer Area */}
      {playerAnime && selectedEpisode && (
        <div id="otaku-stream-watch-section" className="bg-black/95 py-6 border-b border-gray-900">
          <div className="max-w-6xl mx-auto px-4 md:px-6">
            
            {/* Nav actions */}
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={stopWatching}
                className="text-xs font-bold text-gray-400 hover:text-white flex items-center gap-1.5 transition-colors"
                id="stop-watching-action"
              >
                <ChevronLeft className="h-4.5 w-4.5" /> Stop / Return Home
              </button>
              
              <span className="text-xs font-mono text-gray-500">
                Watching: <strong className="text-red-500 font-bold">{playerAnime.name}</strong> • Ep {selectedEpisode.number}
              </span>
            </div>

            {/* Custom player wrapper */}
            <CustomPlayer
              episode={selectedEpisode}
              anime={playerAnime}
              continueWatching={continueWatchingList.find(cw => cw.episodeId === selectedEpisode.id) || null}
              onTimestampUpdate={(sec) => {
                onUpdateContinueWatching({
                  animeId: playerAnime.id,
                  episodeId: selectedEpisode.id,
                  timestamp: Math.floor(sec),
                  duration: selectedEpisode.duration * 60,
                  updatedAt: new Date().toISOString()
                });
              }}
              activeAds={activeAds}
              onEpisodeEnded={() => {
                // Find next episode auto next
                const currentEpNo = selectedEpisode.number;
                const targetSeasonId = selectedEpisode.seasonId;
                const nextEpisode = episodesList.find(
                  e => e.animeId === playerAnime.id && e.seasonId === targetSeasonId && e.number === currentEpNo + 1
                );
                if (nextEpisode) {
                  startWatchingEpisode(nextEpisode, playerAnime);
                } else {
                  alert('You have completed this season arc!');
                }
              }}
            />

            {/* Detailed Metadata below Player */}
            <div className="mt-6 flex flex-col md:flex-row gap-6 bg-gray-900 border border-gray-800 rounded-xl p-5">
              <img 
                src={playerAnime.poster} 
                className="h-40 w-28 object-cover rounded-lg shadow-lg border border-gray-800" 
                alt="" 
              />
              <div className="flex-1 space-y-2">
                <h1 className="text-xl font-bold text-white tracking-tight">{playerAnime.name}</h1>
                <p className="text-xs text-gray-400 leading-relaxed font-semibold max-w-2xl">{playerAnime.synopsis}</p>
                <div className="flex flex-wrap gap-1.5 pt-2">
                  {playerAnime.genres.map(g => (
                    <span key={g} className="text-[10px] bg-red-600/10 text-red-400 border border-red-500/10 font-bold px-2.5 py-0.5 rounded">
                      {g}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Other episodes listing select panel */}
            <div className="mt-6 bg-gray-900 border border-gray-800 rounded-xl p-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-gray-850">
                <h4 className="text-xs font-bold text-gray-300 uppercase tracking-wider">Select Audio Language Track</h4>
                <div className="flex flex-wrap gap-1">
                  {(['Japanese', 'English', 'Hindi', 'Bangla'] as const).map((lang) => {
                    const hasEpsForLang = episodesList.some(
                      ep => ep.animeId === playerAnime.id && (ep.language || 'Japanese') === lang
                    );
                    return (
                      <button
                        key={lang}
                        onClick={() => {
                          setActiveLanguage(lang);
                          // Select the first episode of that language if available
                          const firstEp = episodesList
                            .filter(ep => ep.animeId === playerAnime.id && ep.seasonId === selectedEpisode.seasonId && (ep.language || 'Japanese') === lang)
                            .sort((a, b) => a.number - b.number)[0];
                          if (firstEp) {
                            setSelectedEpisode(firstEp);
                          }
                        }}
                        className={`px-3 py-1 text-[11px] font-bold rounded transition-all ${
                          activeLanguage === lang
                            ? 'bg-red-650/20 border border-red-500/40 text-red-400 font-extrabold'
                            : hasEpsForLang
                            ? 'bg-gray-950 text-gray-400 hover:text-white border border-gray-850 hover:bg-gray-900'
                            : 'bg-transparent text-gray-650 border-transparent hover:text-gray-500'
                        }`}
                      >
                        {lang} {hasEpsForLang ? '' : '•'}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2">
                {episodesList
                  .filter(ep => ep.animeId === playerAnime.id && ep.seasonId === selectedEpisode.seasonId && (ep.language || 'Japanese') === activeLanguage)
                  .sort((a, b) => a.number - b.number)
                  .map(ep => (
                    <button
                      key={ep.id}
                      onClick={() => startWatchingEpisode(ep, playerAnime)}
                      className={`text-center py-2 text-xs font-bold rounded-lg border transition-all ${
                        selectedEpisode.id === ep.id 
                          ? 'bg-red-600 border-red-700 text-white shadow-md' 
                          : 'bg-gray-950 hover:bg-gray-920 border-gray-800 text-gray-400 hover:text-white'
                      }`}
                    >
                      EP {ep.number}
                    </button>
                ))}
              </div>

              {episodesList.filter(ep => ep.animeId === playerAnime.id && ep.seasonId === selectedEpisode.seasonId && (ep.language || 'Japanese') === activeLanguage).length === 0 && (
                <div className="text-xs text-gray-550 py-6 text-center font-mono font-medium">
                  No {activeLanguage} audio tracks uploaded yet for this season.
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* Advanced Global Search bar and Recommendations suggestions UI */}
      <div className="max-w-6xl mx-auto px-4 md:px-6 pt-6">
        <div className="relative">
          <div className="flex h-12 w-full items-center bg-gray-900 border border-gray-800 hover:border-gray-700 transition-all rounded-xl pl-4 pr-2">
            <Search className="h-5 w-5 text-gray-400 flex-shrink-0" />
            <input
              type="text"
              placeholder={translate('search_placeholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setShowSearchDropdown(true)}
              className="w-full bg-transparent px-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:ring-0 leading-none"
              id="search-anime-input"
            />
            {searchQuery && (
              <button 
                onClick={() => { setSearchQuery(''); setSearchResult([]); }}
                className="p-1 cursor-pointer text-gray-400 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Search Suggestion dropdown list with micro indicators */}
          {showSearchDropdown && searchResult.length > 0 && (
            <div className="absolute top-13 left-0 right-0 max-h-72 overflow-y-auto bg-gray-900 border border-gray-800 rounded-xl shadow-2xl p-2 z-40 space-y-1">
              <span className="text-[9px] uppercase font-bold text-gray-500 px-2 block border-b border-gray-950 pb-1 mb-1">Found Anime Suggestions Matches</span>
              {searchResult.map((anime) => (
                <div
                  key={anime.id}
                  onClick={() => {
                    setSelectedAnime(anime);
                    setSearchQuery('');
                    setShowSearchDropdown(false);
                    // Open modal
                  }}
                  className="flex items-center gap-3 p-2 hover:bg-gray-950 rounded-lg cursor-pointer transition-colors"
                >
                  <img src={anime.poster} className="h-10 w-7 rounded object-cover" alt="" />
                  <div className="truncate">
                    <h4 className="text-xs font-bold text-white truncate">{anime.name}</h4>
                    <span className="text-[10px] text-gray-500 font-mono">{anime.status} • {anime.studio}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Landing OTT Slider component */}
      {!playerAnime && animeList.length > 0 && (
        <div className="max-w-6xl mx-auto px-4 md:px-6 pt-6">
          <div className="relative aspect-[21/9] w-full overflow-hidden rounded-2xl bg-black border border-gray-900 shadow-2xl group">
            {/* Animated slide background */}
            <img 
              src={animeList[heroIndex]?.banner} 
              alt="" 
              className="absolute inset-0 h-full w-full object-cover opacity-65 transition-transform duration-[12000ms] scale-105 group-hover:scale-100" 
            />
            
            <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/20 to-transparent p-6 md:p-10 flex flex-col justify-end">
              <div className="max-w-lg space-y-2.5">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-red-600/10 border border-red-500/20 px-2 px-3.5 py-0.5 text-xs font-black text-red-500 font-mono tracking-wider animate-pulse">
                  <Flame className="h-3.5 w-3.5" /> EXCLUSIVE PREMERE
                </span>
                <h1 className="text-2xl md:text-3.5xl font-black text-white tracking-tight leading-none drop-shadow">
                  {animeList[heroIndex]?.name}
                </h1>
                <p className="text-[11px] md:text-xs text-gray-400 font-medium leading-relaxed font-semibold line-clamp-2 md:line-clamp-3 md:max-w-md">
                  {animeList[heroIndex]?.synopsis}
                </p>
                <div className="flex gap-3 pt-2">
                  <button
                    onClick={() => {
                      const eps = episodesList.filter(e => e.animeId === animeList[heroIndex].id);
                      if (eps.length > 0) {
                        startWatchingEpisode(eps[0], animeList[heroIndex]);
                      } else {
                        setSelectedAnime(animeList[heroIndex]);
                      }
                    }}
                    className="inline-flex items-center gap-2 rounded-xl bg-red-600 hover:bg-red-700 px-5 py-2.5 text-xs font-extrabold text-white shadow-lg shadow-red-650/25 transition-all cursor-pointer hover:scale-102"
                  >
                    <Play className="h-3.5 w-3.5 fill-current" /> {translate('watch_now')}
                  </button>
                  <button
                    onClick={() => setSelectedAnime(animeList[heroIndex])}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-gray-900/90 border border-gray-800 px-4 py-2 text-xs font-bold text-gray-300 hover:bg-gray-800 transition"
                  >
                    <Info className="h-4 w-4" /> More Details
                  </button>
                </div>
              </div>
            </div>

            {/* Navigation Dots */}
            <div className="absolute bottom-4 right-4 flex gap-1.5 z-10">
              {animeList.slice(0, 3).map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setHeroIndex(idx)}
                  className={`h-1.5 rounded-full transition-all duration-300 ${heroIndex === idx ? 'w-4.5 bg-red-600' : 'w-1.5 bg-white/40'}`}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main landing grids layout */}
      {!playerAnime && (
        <div className="max-w-6xl mx-auto px-4 md:px-6 mt-8 space-y-10">
          
          {/* Continue Watching Section */}
          {continueWatchingList.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
                <Clock className="h-4.5 w-4.5 text-red-500" /> {translate('continue_watching')}
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                {continueWatchingList.map((cw, index) => {
                  const show = animeList.find(a => a.id === cw.animeId);
                  const epNumObj = episodesList.find(e => e.id === cw.episodeId);
                  if (!show || !epNumObj) return null;
                  
                  return (
                    <div 
                      key={index} 
                      className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden p-3 relative group text-left"
                    >
                      <div className="relative aspect-video w-full rounded-lg overflow-hidden mb-2">
                        <img src={show.banner} className="h-full w-full object-cover opacity-75 group-hover:opacity-100 transition-opacity" alt="" />
                        
                        <div 
                          onClick={() => startWatchingEpisode(epNumObj, show)}
                          className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
                        >
                          <div className="h-9 w-9 rounded-full bg-red-600 text-white flex items-center justify-center font-bold shadow shadow-red-500">
                            <Play className="h-4.5 w-4.5 fill-current ml-0.5" />
                          </div>
                        </div>

                        {/* Progress slider bar */}
                        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-950">
                          <div 
                            style={{ width: `${(cw.timestamp / cw.duration) * 100}%` }}
                            className="h-full bg-red-600" 
                          />
                        </div>
                      </div>

                      <h4 className="text-xs font-bold text-white truncate">{show.name}</h4>
                      <p className="text-[10px] text-gray-500 font-semibold truncate leading-normal">Episode {epNumObj.number}: {epNumObj.name}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Trending now cards mapping */}
          <div className="space-y-4 text-left">
            <h2 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
              <Flame className="h-4.5 w-4.5 text-red-500 animate-pulse" /> {translate('trending')}
            </h2>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {trendingAnime.map((anime) => (
                <div 
                  key={anime.id} 
                  className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden group text-left cursor-pointer relative"
                  onClick={() => setSelectedAnime(anime)}
                >
                  <div className="relative aspect-[3/4] w-full overflow-hidden">
                    <img 
                      src={anime.poster} 
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" 
                      alt="" 
                    />
                    
                    {/* Score badges */}
                    <div className="absolute top-2 left-2 bg-black/75 rounded-lg px-2 py-0.5 text-[9px] font-mono font-bold text-amber-400 border border-yellow-500/20 flex items-center gap-0.5">
                      <Star className="h-3 w-3 fill-current text-yellow-500" /> {anime.rating}
                    </div>

                    <div className="absolute inset-0 bg-gradient-to-t from-gray-950/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                      <button className="w-full py-1.5 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-700 transition">
                        Quick View
                      </button>
                    </div>
                  </div>

                  <div className="p-3 space-y-0.5">
                    <h3 className="text-xs font-bold text-gray-200 truncate group-hover:text-red-500 transition-colors leading-tight">
                      {anime.name}
                    </h3>
                    <p className="text-[10px] text-gray-500 font-semibold font-mono">{anime.studio} • {anime.year}</p>
                    <div className="flex gap-2 text-[9px] font-mono text-gray-400 mt-1.5">
                      <span>👁 {anime.views.toLocaleString()}</span>
                      <span>❤️ {anime.likes.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Latest Episodes Section with dynamic direct video player switch */}
          <div className="space-y-4 text-left">
            <h2 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
              <Tv className="h-4.5 w-4.5 text-red-500" /> {translate('latest_episodes')}
            </h2>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {latestEpisodes.map((ep) => {
                const anime = animeList.find(a => a.id === ep.animeId);
                const seasonObj = seasonsList.find(s => s.id === ep.seasonId);
                if (!anime) return null;
                
                return (
                  <div 
                    key={ep.id} 
                    className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden cursor-pointer group hover-brand-glow text-left"
                    onClick={() => startWatchingEpisode(ep, anime)}
                  >
                    <div className="relative aspect-video w-full overflow-hidden">
                      <img src={anime.banner} className="h-full w-full object-cover opacity-80" alt="" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                      
                      {/* Play badge HUD */}
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="h-8 w-8 rounded-full bg-red-600 text-white flex items-center justify-center shadow">
                          <Play className="h-4 w-4 fill-current ml-0.5" />
                        </div>
                      </div>

                      <div className="absolute bottom-2 left-2 right-2 flex justify-between items-center text-[10px] font-bold">
                        <span className="bg-red-600/90 text-white px-2 py-0.5 rounded-md leading-none">
                          EP {ep.number}
                        </span>
                        <span className="text-gray-300 font-mono tracking-wide">
                          {ep.duration} m
                        </span>
                      </div>
                    </div>

                    <div className="p-2.5">
                      <h4 className="text-[11px] font-extrabold text-white truncate" title={anime.name}>{anime.name}</h4>
                      <p className="text-[10px] text-gray-500 truncate mt-0.5" title={ep.name}>{ep.name}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Popular This Week */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left lists column */}
            <div className="col-span-2 space-y-4 text-left">
              <h2 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
                <Heart className="h-4.5 w-4.5 text-red-500" /> {translate('popular_week')}
              </h2>

              <div className="space-y-2.5">
                {popularWeek.map((anime, index) => (
                  <div 
                    key={anime.id} 
                    onClick={() => setSelectedAnime(anime)}
                    className="bg-gray-900 hover:bg-gray-800 border border-gray-800 rounded-xl p-3 flex justify-between items-center gap-4 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3.5">
                      <span className="text-lg font-black text-gray-600 font-mono w-4">#{index + 1}</span>
                      <img src={anime.poster} className="h-12 w-9 rounded object-cover border border-gray-800" alt="" />
                      <div>
                        <h4 className="text-xs font-extrabold text-white leading-tight">{anime.name}</h4>
                        <p className="text-[10px] text-gray-500 mt-0.5 leading-normal">{anime.studio} • {anime.year}</p>
                      </div>
                    </div>

                    <div className="text-right text-[10px] font-mono">
                      <span className="text-gray-300 font-semibold block">{anime.views.toLocaleString()} Views</span>
                      <span className="text-yellow-500 block">★ {anime.rating}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right sidebar banner ad */}
            {bannerAdSidebar && (
              <div className="space-y-4">
                <span className="text-[9px] uppercase tracking-wider font-extrabold text-gray-500 block">Advertisement</span>
                <a 
                  href={bannerAdSidebar.ctaLink} 
                  target="_blank" 
                  rel="no-referrer"
                  onClick={() => handleAdClick(bannerAdSidebar)}
                  className="block relative overflow-hidden rounded-xl border border-amber-500/10 shadow-lg group text-left"
                >
                  <img src={bannerAdSidebar.imageUrl} alt="" className="w-full aspect-[4/5] object-cover opacity-80" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent p-4 flex flex-col justify-end text-center">
                    <h4 className="text-sm font-bold text-white mb-2">{bannerAdSidebar.title}</h4>
                    <span className="text-[10px] bg-yellow-500 hover:bg-yellow-600 font-semibold text-black py-1.5 px-3 rounded-lg flex items-center justify-center gap-1">
                      Buy Merchandise <ExternalLink className="h-3 w-4" />
                    </span>
                  </div>
                </a>
              </div>
            )}

          </div>

          {/* Upcoming releases */}
          <div className="space-y-4 text-left">
            <h2 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
              <Calendar className="h-4.5 w-4.5 text-red-500" /> {translate('upcoming')}
            </h2>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {upcomingReleases.map((anime) => (
                <div 
                  key={anime.id} 
                  className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden group text-left"
                >
                  <div className="relative aspect-[3/4]">
                    <img src={anime.poster} className="h-full w-full object-cover opacity-60" alt="" />
                    <div className="absolute inset-y-0 inset-x-0 flex items-center justify-center p-4 text-center">
                      <span className="text-[10px] uppercase font-bold tracking-wider bg-red-600/90 text-white px-3 py-1 rounded-full shadow-lg">
                        COMING {anime.year}
                      </span>
                    </div>
                  </div>
                  <div className="p-3">
                    <h3 className="text-xs font-bold text-gray-200 truncate leading-tight">{anime.name}</h3>
                    <p className="text-[10px] text-gray-500 font-mono mt-0.5">{anime.studio}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* Global Footer Banner */}
      {bannerAdFooter && (
        <div className="max-w-6xl mx-auto px-4 md:px-6 mt-12 pb-4">
          <a
            href={bannerAdFooter.ctaLink}
            target="_blank"
            rel="no-referrer"
            onClick={() => handleAdClick(bannerAdFooter)}
            className="block relative rounded-xl border border-amber-500/10 overflow-hidden"
          >
            <img src={bannerAdFooter.imageUrl} className="w-full h-24 object-cover opacity-75" alt="" />
            <div className="absolute inset-0 bg-black/45 flex justify-center items-center p-4">
              <span className="text-white text-xs md:text-sm font-semibold tracking-wide text-center">{bannerAdFooter.title}</span>
            </div>
          </a>
        </div>
      )}

      {/* ANIME DETAILS POPUP MODAL (CINEMATIC BRIEFING & REVIEWS GALLERY) */}
      {selectedAnime && (
        <div id="anime-detail-modal" className="fixed inset-0 bg-black/90 backdrop-blur-sm z-45 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-gray-950 border border-gray-900 rounded-2xl max-w-4xl w-full text-left overflow-hidden shadow-2xl relative my-8">
            
            {/* Close */}
            <button
              onClick={() => setSelectedAnime(null)}
              className="absolute top-4 right-4 h-8 w-8 rounded-full bg-black/65 border border-gray-800 text-gray-400 hover:text-white flex items-center justify-center transition-colors z-10 hover:scale-105"
            >
              <X className="h-4.5 w-4.5" />
            </button>

            {/* Banner top */}
            <div className="relative h-56 md:h-72 w-full">
              <img src={selectedAnime.banner} className="h-full w-full object-cover opacity-45" alt="" />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-gray-950 to-transparent p-6 flex items-end">
                <div className="flex flex-col md:flex-row gap-5 items-end">
                  <img src={selectedAnime.poster} className="h-40 w-28 object-cover rounded-lg shadow-2xl border border-gray-800 md:block hidden" alt="" />
                  <div className="space-y-1.5 text-left mb-2">
                    <h2 className="text-xl md:text-3xl font-black text-white tracking-tight leading-none drop-shadow">
                      {selectedAnime.name}
                    </h2>
                    <p className="text-xs text-gray-400 font-semibold font-mono">Alternative: {selectedAnime.altNames.join(' / ') || 'None'}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Tab components inside details */}
            <div className="p-6 space-y-6">
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* General facts */}
                <div className="space-y-4">
                  <div className="bg-gray-900 border border-gray-800 rounded-xl p-4.5 space-y-3 font-medium text-xs text-gray-400 text-left">
                    <h3 className="text-xs font-bold text-white border-b border-gray-850 pb-2 uppercase tracking-widest">{translate('details_studio')} Details</h3>
                    <div>
                      <span className="text-gray-500 font-bold uppercase text-[9px] block">Director Studio</span>
                      <span className="text-gray-200">{selectedAnime.studio}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 font-bold uppercase text-[9px] block">{translate('details_year')} of Release</span>
                      <span className="text-gray-200">{selectedAnime.year}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 font-bold uppercase text-[9px] block">Watch status</span>
                      <span className="text-red-400 font-bold">{selectedAnime.status}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 font-bold uppercase text-[9px] block">Ecosystem rating score</span>
                      <span className="text-yellow-500 font-extrabold flex items-center gap-0.5">★ {selectedAnime.rating} / 10.0</span>
                    </div>
                  </div>

                  {/* Related Suggestions AI Based */}
                  <div className="bg-gray-900 border border-gray-800 rounded-xl p-4.5 space-y-3 text-left">
                    <h3 className="text-xs font-bold text-white border-b border-gray-850 pb-2 uppercase tracking-widest">{translate('related')}</h3>
                    <div className="space-y-2">
                      {animeList
                        .filter(a => a.id !== selectedAnime.id && a.genres.some(g => selectedAnime.genres.includes(g)))
                        .slice(0, 2)
                        .map(sa => (
                          <div 
                            key={sa.id} 
                            onClick={() => setSelectedAnime(sa)}
                            className="flex items-center gap-2.5 p-1.5 hover:bg-gray-950 rounded cursor-pointer transition-colors"
                          >
                            <img src={sa.poster} className="h-10 w-7 object-cover rounded" alt="" />
                            <div className="truncate text-xs">
                              <h4 className="font-bold text-white truncate leading-tight">{sa.name}</h4>
                              <span className="text-[10px] text-gray-500">★ {sa.rating}</span>
                            </div>
                          </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right Side episodes groups and review submissions */}
                <div className="col-span-2 space-y-5 text-left">
                  
                  {/* Synopsis */}
                  <div className="space-y-1.5">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500">Synopsis Overview</h3>
                    <p className="text-xs text-gray-300 leading-relaxed font-semibold">{selectedAnime.synopsis}</p>
                  </div>

                  {/* Interactive Seasons/Episodes selector */}
                  <div className="space-y-3 bg-gray-950/40 p-4 border border-gray-900 rounded-xl">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2 border-b border-gray-905">
                      <span className="text-xs font-bold text-white uppercase tracking-wider">{translate('episodes')} catalogue</span>
                      
                      {/* Season Toggles */}
                      <div className="flex gap-1.5 flex-wrap">
                        {[1, 2].map((sNum) => (
                          <button
                            key={sNum}
                            onClick={() => setActiveSeasonNum(sNum)}
                            className={`px-3 py-1 rounded text-[11px] font-extrabold ${activeSeasonNum === sNum ? 'bg-red-600 text-white' : 'bg-gray-905 text-gray-400 hover:bg-gray-800'}`}
                          >
                            Season {sNum}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Audio Language Selection bar */}
                    <div className="flex items-center justify-between gap-1 py-1">
                      <span className="text-[10px] uppercase font-bold text-gray-500">Audio Language:</span>
                      <div className="flex gap-1 flex-wrap">
                        {(['Japanese', 'English', 'Hindi', 'Bangla'] as const).map((lang) => {
                          const hasEpsForLang = episodesList.some(
                            ep => ep.animeId === selectedAnime.id && ep.seasonId.endsWith(`_${activeSeasonNum}`) && (ep.language || 'Japanese') === lang
                          );
                          return (
                            <button
                              key={lang}
                              onClick={() => setActiveLanguage(lang)}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border transition ${
                                activeLanguage === lang
                                  ? 'bg-red-600/20 text-red-400 border-red-500/30'
                                  : hasEpsForLang
                                  ? 'bg-gray-900 text-gray-400 border-gray-850 hover:text-white'
                                  : 'bg-transparent text-gray-600 border-transparent hover:text-gray-500 hover:bg-gray-900/20'
                              }`}
                            >
                              {lang} {hasEpsForLang ? '' : '•'}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-44 overflow-y-auto pr-1">
                      {episodesList
                        .filter(ep => ep.animeId === selectedAnime.id && ep.seasonId.endsWith(`_${activeSeasonNum}`) && (ep.language || 'Japanese') === activeLanguage)
                        .sort((a,b) => a.number - b.number)
                        .map((ep) => (
                          <div 
                            key={ep.id}
                            onClick={() => startWatchingEpisode(ep, selectedAnime)}
                            className="p-2.5 bg-gray-900 hover:bg-gray-850 border border-gray-850 hover:border-red-500/20 transition rounded-lg flex items-center justify-between gap-3 cursor-pointer group"
                          >
                            <span className="text-xs font-bold text-gray-200 truncate group-hover:text-red-400">
                              Episode {ep.number}: {ep.name}
                            </span>
                            <Play className="h-3.5 w-3.5 text-red-500 opacity-60 group-hover:opacity-100 fill-current" />
                          </div>
                      ))}

                      {episodesList.filter(ep => ep.animeId === selectedAnime.id && ep.seasonId.endsWith(`_${activeSeasonNum}`) && (ep.language || 'Japanese') === activeLanguage).length === 0 && (
                        <div className="col-span-2 text-xs text-gray-500 py-6 text-center font-mono font-medium">
                          No episodes uploaded for Season {activeSeasonNum} in {activeLanguage} yet. Try another audio language!
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Screenshots gallery */}
                  {selectedAnime.screenshots && selectedAnime.screenshots.length > 0 && (
                    <div className="space-y-2">
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider">{translate('screenshots')}</h3>
                      <div className="grid grid-cols-3 gap-2">
                        {selectedAnime.screenshots.map((src, i) => (
                          <img key={i} src={src} className="aspect-video w-full object-cover rounded-lg border border-gray-805" alt="" />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Reviews Section */}
                  <div className="space-y-4 pt-2">
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">{translate('reviews')} ({selectedAnime.reviews.length})</h3>
                    
                    {/* Write customized reviews */}
                    <form onSubmit={handleReviewSubmit} className="bg-gray-900 border border-gray-850 rounded-xl p-3.5 space-y-2.5">
                      <span className="text-[10px] font-bold text-gray-400 uppercase">Write your streaming feedback</span>
                      <div className="flex gap-3 justify-between items-center text-xs">
                        <select 
                          value={revRating}
                          onChange={(e) => setRevRating(parseInt(e.target.value))}
                          className="bg-gray-950 border border-gray-800 rounded p-1.5 text-yellow-500 font-bold"
                        >
                          {[10,9,8,7,6,5,4,3,2,1].map(v => (
                            <option key={v} value={v}>★ {v}.0 Rating</option>
                          ))}
                        </select>
                        <input 
                          type="text" 
                          required
                          placeholder="Your comments or critique on animation, character paths..." 
                          value={revContent}
                          onChange={(e) => setRevContent(e.target.value)}
                          className="flex-1 bg-gray-950 border border-gray-800 rounded p-2 text-xs text-white"
                        />
                        <button 
                          type="submit"
                          className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs px-3.5 py-2 rounded-lg"
                        >
                          Submit Review
                        </button>
                      </div>
                    </form>

                    {/* Mapped Reviews */}
                    <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                      {selectedAnime.reviews.map((rev) => (
                        <div key={rev.id} className="p-3 bg-gray-900/60 border border-gray-900 rounded-xl space-y-1 text-xs">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-gray-200">{rev.userName}</span>
                            <span className="text-yellow-500 font-bold">★ {rev.rating}</span>
                          </div>
                          <p className="text-gray-400 font-semibold">{rev.content}</p>
                          <span className="text-[9px] text-gray-500 font-mono block text-right">{rev.createdAt}</span>
                        </div>
                      ))}
                    </div>

                  </div>

                </div>

              </div>

            </div>

          </div>
        </div>
      )}

      {/* Styled Footer Block */}
      <footer className="mt-16 border-t border-gray-900 pt-8 max-w-6xl mx-auto px-4 text-center text-gray-500 space-y-4 antialiased">
        <div className="flex items-center justify-center gap-3">
          <div className="h-6 w-6 bg-red-600 rounded flex items-center justify-center font-bold text-white text-xs">Ω</div>
          <span className="text-sm font-bold text-gray-400">OTAKU UNIVERSE OTT</span>
        </div>
        <p className="text-[11px] leading-relaxed max-w-md mx-auto font-semibold">
          Your Ultimate Enterprise Anime Management hub connecting PostgreSQL DBs, Cloud S3 bucket CDNs, dynamic subtitles translators and real-time Socket notifications.
        </p>
        <span className="text-[10px] font-mono block">© 2026 Otaku Universe CMS. Built with standard clean structures.</span>
      </footer>

    </div>
  );
}
