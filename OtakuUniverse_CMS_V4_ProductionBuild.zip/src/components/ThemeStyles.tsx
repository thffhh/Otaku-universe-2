import React from 'react';
import { ThemeConfig } from '../types';

interface ThemeStylesProps {
  theme: ThemeConfig;
}

export default function ThemeStyles({ theme }: ThemeStylesProps) {
  // Translate system font choices
  const getFontFamily = (fontName: string) => {
    switch (fontName) {
      case 'Space Grotesk':
        return "'Space Grotesk', sans-serif";
      case 'Outfit':
        return "'Outfit', sans-serif";
      case 'JetBrains Mono':
        return "'JetBrains Mono', monospace";
      case 'Playfair Display':
        return "'Playfair Display', serif";
      case 'Inter':
      default:
        return "'Inter', sans-serif";
    }
  };

  const cssStyle = `
    :root {
      --font-custom: ${getFontFamily(theme.fontFamily)};
      --theme-primary: ${theme.primaryColor};
      --theme-secondary: ${theme.secondaryColor};
      --theme-bg: ${theme.bgColor};
      --theme-card: ${theme.cardBgColor};
      --theme-text: ${theme.textColor};
      --theme-radius: ${theme.borderRadius};
    }

    body {
      background-color: var(--theme-bg);
      font-family: var(--font-custom), sans-serif;
      color: var(--theme-text);
      transition: background-color 0.3s ease, color 0.3s ease;
    }

    /* Apply primary brand colors systematically */
    .bg-brand-primary {
      background-color: var(--theme-primary) !important;
    }
    .text-brand-primary {
      color: var(--theme-primary) !important;
    }
    .border-brand-primary {
      border-color: var(--theme-primary) !important;
    }
    .ring-brand-primary:focus {
      --tw-ring-color: var(--theme-primary) !important;
    }

    /* Custom Theme Card styling */
    .custom-card {
      background-color: var(--theme-card);
      border-radius: var(--theme-radius);
      border: 1px solid rgba(255, 255, 255, 0.05);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .custom-card:hover {
      border-color: rgba(255, 255, 255, 0.12);
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
    }

    /* Hover brand glow text */
    .hover-brand-glow:hover {
      text-shadow: 0 0 8px var(--theme-primary);
    }
  `;

  return (
    <style dangerouslySetInnerHTML={{ __html: cssStyle }} />
  );
}
