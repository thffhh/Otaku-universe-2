import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, Pause, Volume2, VolumeX, Maximize2, Minimize2, 
  RotateCcw, RotateCw, SkipForward, Settings, Captions, Info, 
  Download, ExternalLink, RefreshCw, Radio, Tv, X
} from 'lucide-react';
import { Episode, Anime, AdCampaign, ContinueWatching, SourceLink } from '../types';

interface CustomPlayerProps {
  episode: Episode;
  anime: Anime;
  onEpisodeEnded?: () => void;
  continueWatching: ContinueWatching | null;
  onTimestampUpdate: (seconds: number) => void;
  activeAds: AdCampaign[];
}

export default function CustomPlayer({
  episode,
  anime,
  onEpisodeEnded,
  continueWatching,
  onTimestampUpdate,
  activeAds
}: CustomPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // States
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [quality, setQuality] = useState('1080p');
  const [subtitlesEnabled, setSubtitlesEnabled] = useState(true);
  const [isPip, setIsPip] = useState(false);
  const [isAutoPlay, setIsAutoPlay] = useState(true);
  const [isAutoNext, setIsAutoNext] = useState(true);

  // Resume State
  const [resumePrompt, setResumePrompt] = useState(false);

  // Google Drive Helpers & State
  const isGoogleDriveUrl = (url: string) => {
    if (!url) return false;
    return url.includes('drive.google.com') || url.includes('docs.google.com') || url.includes('/file/d/') || url.includes('id=');
  };

  const getGoogleDriveEmbedUrl = (url: string) => {
    if (!url) return '';
    const match = url.match(/(?:\/d\/|id=)([\w-]+)/);
    if (match && match[1]) {
      return `https://drive.google.com/file/d/${match[1]}/preview`;
    }
    return url;
  };

  const getGoogleDriveDirectUrl = (url: string) => {
    if (!url) return '';
    const match = url.match(/(?:\/d\/|id=)([\w-]+)/);
    if (match && match[1]) {
      return `https://drive.google.com/uc?export=download&id=${match[1]}`;
    }
    return url;
  };

  const [activeVideoUrl, setActiveVideoUrl] = useState(episode.videoUrl);
  const [selectedServerLabel, setSelectedServerLabel] = useState('Default Host');

  useEffect(() => {
    if (episode.sources && episode.sources.length > 0) {
      setActiveVideoUrl(episode.sources[0].url);
      setSelectedServerLabel(episode.sources[0].label);
    } else {
      setActiveVideoUrl(episode.videoUrl);
      setSelectedServerLabel('Default Host');
    }
  }, [episode.id, episode.videoUrl, episode.sources]);

  const [playerMode, setPlayerMode] = useState<'html5' | 'embed'>('html5');

  // Sync mode on active video change
  useEffect(() => {
    if (isGoogleDriveUrl(activeVideoUrl)) {
      setPlayerMode('embed');
    } else {
      setPlayerMode('html5');
    }
  }, [activeVideoUrl]);

  // Ads States
  const [currentAd, setCurrentAd] = useState<AdCampaign | null>(null);
  const [adTimeLeft, setAdTimeLeft] = useState(0);
  const [adSkipTimeLeft, setAdSkipTimeLeft] = useState(5);
  const [canSkipAd, setCanSkipAd] = useState(false);
  const [hasTriggeredMidRoll, setHasTriggeredMidRoll] = useState(false);
  const [isAdPlaying, setIsAdPlaying] = useState(false);

  // Effect: Handle episode loading and check resume
  useEffect(() => {
    setIsPlaying(false);
    setHasTriggeredMidRoll(false);
    setIsAdPlaying(false);
    setCurrentAd(null);

    // Look for Pre-roll active ads
    const preRollAd = activeAds.find(ad => ad.enabled && ad.type === 'pre-roll');
    if (preRollAd) {
      setCurrentAd(preRollAd);
      setIsAdPlaying(true);
      const duration = preRollAd.duration || 8;
      setAdTimeLeft(duration);
      setAdSkipTimeLeft(Math.min(5, duration));
      setCanSkipAd(false);
    } else {
      // Check for continue watching
      if (continueWatching && continueWatching.episodeId === episode.id && continueWatching.timestamp > 10) {
        setResumePrompt(true);
      }
    }

    if (videoRef.current) {
      videoRef.current.load();
      if (!preRollAd && isAutoPlay) {
        // Safe play
        videoRef.current.play()
          .then(() => setIsPlaying(true))
          .catch(() => setIsPlaying(false));
      }
    }
  }, [episode, activeAds]);

  // Handle continuous timer for custom ad
  useEffect(() => {
    let timer: any;
    if (isAdPlaying && currentAd) {
      timer = setInterval(() => {
        setAdTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            handleAdComplete();
            return 0;
          }
          return prev - 1;
        });

        setAdSkipTimeLeft(prevSkip => {
          if (prevSkip <= 1) {
            setCanSkipAd(true);
            return 0;
          }
          return prevSkip - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isAdPlaying, currentAd]);

  const handleResumePlay = (resume: boolean) => {
    setResumePrompt(false);
    if (videoRef.current) {
      if (resume && continueWatching) {
        videoRef.current.currentTime = continueWatching.timestamp;
      }
      videoRef.current.play()
        .then(() => setIsPlaying(true))
        .catch(() => {});
    }
  };

  const handleAdComplete = () => {
    setIsAdPlaying(false);
    setCurrentAd(null);
    if (videoRef.current) {
      videoRef.current.play()
        .then(() => setIsPlaying(true))
        .catch(() => {});
    }
  };

  const skipAdAction = () => {
    if (canSkipAd || adSkipTimeLeft <= 0) {
      handleAdComplete();
    }
  };

  const togglePlay = () => {
    if (isAdPlaying) return;
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play()
          .then(() => setIsPlaying(true))
          .catch(() => {});
      }
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current && !isAdPlaying) {
      const current = videoRef.current.currentTime;
      setCurrentTime(current);
      onTimestampUpdate(current);

      // Analyze Mid-roll at 10 seconds or midway
      if (!hasTriggeredMidRoll && current > 12 && current < 15) {
        const midRollAd = activeAds.find(ad => ad.enabled && ad.type === 'mid-roll');
        if (midRollAd) {
          videoRef.current.pause();
          setIsPlaying(false);
          setHasTriggeredMidRoll(true);
          setCurrentAd(midRollAd);
          setIsAdPlaying(true);
          const duration = midRollAd.duration || 7;
          setAdTimeLeft(duration);
          setAdSkipTimeLeft(Math.min(5, duration));
          setCanSkipAd(false);
        }
      }

      // Check for Skip Intro endpoints (e.g., episode.skipIntroStart and skipIntroEnd)
      // Standard default is 10s to 80s if not specified
      // Check for Skip Outro endpoint
    }
  };

  const handleDurationChange = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    setIsMuted(val === 0);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      const mode = !isMuted;
      setIsMuted(mode);
      videoRef.current.muted = mode;
      if (!mode && volume === 0) {
        setVolume(0.5);
        videoRef.current.volume = 0.5;
      }
    }
  };

  const skipIntro = () => {
    if (videoRef.current) {
      const end = episode.skipIntroEnd || 90;
      videoRef.current.currentTime = end;
      setCurrentTime(end);
    }
  };

  const skipOutro = () => {
    if (videoRef.current && onEpisodeEnded) {
      onEpisodeEnded();
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen()
        .then(() => setIsFullscreen(true))
        .catch(() => {});
    } else {
      document.exitFullscreen()
        .then(() => setIsFullscreen(false))
        .catch(() => {});
    }
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isAdPlaying || !videoRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    videoRef.current.currentTime = pos * duration;
    setCurrentTime(pos * duration);
  };

  const handlePlaybackSpeed = (rate: number) => {
    setPlaybackRate(rate);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
    setShowSettings(false);
  };

  const togglePip = async () => {
    if (!videoRef.current) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setIsPip(false);
      } else {
        await videoRef.current.requestPictureInPicture();
        setIsPip(true);
      }
    } catch (e) {
      // Browsers might block in sandboxes
      setIsPip(prev => !prev);
    }
  };

  // Helper formats seconds to MM:SS
  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return '00:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const activeOverlayAd = activeAds.find(ad => ad.enabled && ad.type === 'overlay');

  return (
    <div id="otaku-universe-player-container" className="w-full">
      {/* Cinematic Main Player Frame */}
      <div 
        ref={containerRef}
        id="video-player-viewport" 
        className="relative aspect-video w-full overflow-hidden bg-black shadow-2xl transition-all rounded-xl border border-gray-800"
      >
        {/* Toggle Mode button for Google Drive urls */}
        {isGoogleDriveUrl(activeVideoUrl) && (
          <div className="absolute top-4 left-4 z-30 flex items-center gap-1.5">
            <button
              onClick={() => setPlayerMode(playerMode === 'embed' ? 'html5' : 'embed')}
              className="px-3 py-1.5 text-[10px] uppercase font-bold tracking-wider rounded-lg bg-red-600 hover:bg-red-700 text-white shadow-xl transition-all flex items-center gap-1.5 leading-none hover:scale-105"
            >
              <RefreshCw className="h-3 w-3 animate-pulse" />
              Player Mode: {playerMode === 'embed' ? 'Google Embed' : 'HTML5 Direct'}
            </button>
            <span className="text-[10px] font-semibold bg-black/75 px-2 py-1 rounded text-gray-400 border border-gray-800">
              {playerMode === 'embed' ? 'Natively buffered' : 'Direct file stream'}
            </span>
          </div>
        )}

        {/* Main Video Element */}
        {playerMode === 'embed' && isGoogleDriveUrl(activeVideoUrl) ? (
          <iframe
            src={getGoogleDriveEmbedUrl(activeVideoUrl)}
            className="absolute inset-0 h-full w-full border-0 bg-black z-10"
            allow="autoplay; encrypted-media; picture-in-picture"
            allowFullScreen
          />
        ) : (
          <video
            ref={videoRef}
            src={isGoogleDriveUrl(activeVideoUrl) ? getGoogleDriveDirectUrl(activeVideoUrl) : activeVideoUrl}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleDurationChange}
            onEnded={() => {
              if (isAdPlaying) {
                handleAdComplete();
              } else if (onEpisodeEnded) {
                onEpisodeEnded();
              }
            }}
            className="h-full w-full object-contain cursor-pointer"
            onClick={togglePlay}
            preload="auto"
          />
        )}

        {/* Big Play Pause Central Hover Button */}
        {playerMode === 'html5' && !isPlaying && !isAdPlaying && !resumePrompt && (
          <div 
            onClick={togglePlay}
            className="absolute inset-0 flex items-center justify-center bg-black/40 cursor-pointer group"
          >
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-red-600 text-white transition-transform duration-300 group-hover:scale-110 shadow-lg">
              <Play className="h-8 w-8 fill-current ml-1" />
            </div>
          </div>
        )}

        {/* Ad Video Overlay */}
        {isAdPlaying && currentAd && (
          <div className="absolute inset-0 flex flex-col justify-between bg-black/95 p-6 z-[60] backdrop-blur-sm rounded-xl overflow-hidden">
            {/* Top Bar info */}
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 rounded bg-amber-500/10 px-2.5 py-1 text-[10px] font-bold text-amber-400 border border-amber-500/20 uppercase tracking-wider">
                <Radio className="h-3 w-3 animate-pulse" /> Sponsored
              </span>
              <span className="text-xs font-semibold text-gray-400">
                Playing Ad: <strong className="text-white text-sm font-mono">{adTimeLeft}s</strong> remaining
              </span>
            </div>

            {/* Clickable Ad Campaign content */}
            <div className="flex flex-col items-center justify-center text-center my-auto transition-all p-4">
              <h4 className="text-lg font-bold md:text-xl text-white mb-2 max-w-xl leading-snug">
                {currentAd.title}
              </h4>
              <p className="text-xs text-gray-400 mb-6 font-mono max-w-md">
                Click this message to visit our sponsor and support the stream.
              </p>
              
              <a 
                href={currentAd.ctaLink} 
                target="_blank"
                rel="no-referrer"
                className="inline-flex items-center gap-1.5 rounded bg-yellow-500 hover:bg-yellow-600 px-5 py-2 text-black font-extrabold text-[11px] shadow-md transition-colors uppercase tracking-wider"
              >
                Visit Site <ExternalLink className="h-3 w-3" />
              </a>
            </div>

            {/* Simple Ad Timer or Choto Cross Option on top-right of ad overlay */}
            <div className="absolute top-4 right-4 z-50">
              {adSkipTimeLeft > 0 ? (
                <div className="bg-black/60 border border-gray-800 backdrop-blur-sm text-gray-400 px-2.5 py-1 rounded text-[10px] font-bold font-mono tracking-wider">
                  Skip in {adSkipTimeLeft}s
                </div>
              ) : (
                <button
                  onClick={skipAdAction}
                  className="bg-red-650 hover:bg-red-700 text-white w-7 h-7 rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-105 active:scale-95 cursor-pointer border border-red-500"
                  title="Skip Ad"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Overlay Banner Ads (Sits on bottom center of player) */}
        {!isAdPlaying && activeOverlayAd && (
          <div className="absolute bottom-16 left-1/2 -translate-x-1/2 bg-gray-900/90 border border-amber-500/30 rounded px-4 py-2 flex items-center gap-3 z-10 max-w-[80%] shadow-lg">
            <span className="text-[10px] uppercase tracking-wider font-extrabold bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded leading-none">
              Ad
            </span>
            <div className="text-xs text-gray-200">
              <a 
                href={activeOverlayAd.ctaLink} 
                target="_blank" 
                rel="no-referrer"
                className="hover:underline font-medium hover:text-red-400 transition-colors flex items-center gap-1.5"
              >
                {activeOverlayAd.title} <ExternalLink className="h-3 w-4 inline" />
              </a>
            </div>
          </div>
        )}

        {/* Continue Watching / Resume Prompt */}
        {!isAdPlaying && resumePrompt && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/85 p-6 z-20">
            <div className="max-w-md rounded-xl bg-gray-900 border border-gray-800 p-6 text-center shadow-2xl">
              <HistoryPromptIcon className="mx-auto h-12 w-12 text-red-500 mb-4" />
              <h4 className="text-lg font-bold text-white mb-1">Resume Episode?</h4>
              <p className="text-sm text-gray-400 mb-6">
                We saved your spot at <span className="text-red-400 font-semibold">{formatTime(continueWatching?.timestamp || 0)}</span>. Would you like to resume?
              </p>
              <div className="flex gap-4 justify-center">
                <button
                  onClick={() => handleResumePlay(false)}
                  className="px-4 py-2 text-sm rounded bg-gray-800 hover:bg-gray-700 font-medium text-white transition-colors"
                >
                  Start Over
                </button>
                <button
                  onClick={() => handleResumePlay(true)}
                  className="px-5 py-2 text-sm rounded bg-red-600 hover:bg-red-700 font-semibold text-white transition-colors shadow-lg"
                >
                  Yes, Resume
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic SKIP INTRO Button (Show between 10s and 80s) */}
        {!isAdPlaying && isPlaying && currentTime > 10 && currentTime < (episode.skipIntroEnd || 90) && (
          <button
            onClick={skipIntro}
            className="absolute bottom-16 right-4 bg-red-600/90 text-white border border-red-500 px-4 py-2 rounded-lg text-xs font-bold hover:bg-red-700 transition-colors flex items-center gap-1.5 shadow-md z-10 opacity-90 hover:opacity-100"
          >
            <SkipForward className="h-3.5 w-3.5" /> Skip Intro
          </button>
        )}

        {/* Dynamic SKIP OUTRO Button (Show near end) */}
        {!isAdPlaying && isPlaying && duration > 0 && currentTime > (duration - 60) && (
          <button
            onClick={skipOutro}
            className="absolute bottom-16 right-4 bg-red-600/90 text-white border border-red-500 px-4 py-2 rounded-lg text-xs font-bold hover:bg-red-700 transition-colors flex items-center gap-1.5 shadow-md z-10 opacity-90"
          >
            Next Episode <SkipForward className="h-3.5 w-3.5" />
          </button>
        )}

        {/* Custom Player Controls */}
        {playerMode === 'html5' && (
          <div id="player-controls-hud" className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-4 flex flex-col justify-end z-10">
            
            {/* Progress Timeline and Hover Slider */}
            <div 
              onClick={handleProgressClick}
              className="group relative h-2.5 w-full bg-gray-800/90 hover:h-3.5 transition-all cursor-pointer rounded-full mb-3.5 shadow-inner"
            >
              {/* Played timeline */}
              <div 
                style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
                className="absolute top-0 left-0 bottom-0 bg-gradient-to-r from-red-600 to-rose-500 rounded-full transition-all duration-75 relative flex items-center"
              >
                {/* Always-visible highly-readable progress handle */}
                <div className="absolute right-0 translate-x-1/2 h-4 w-4 rounded-full bg-white border-2 border-red-600 shadow-[0_0_10px_rgba(239,68,68,0.9)] scale-100 group-hover:scale-125 transition-transform z-10" />
              </div>
            </div>

            <div className="flex items-center justify-between text-gray-200">
              {/* Left Controls */}
              <div className="flex items-center gap-4">
                <button 
                  onClick={togglePlay} 
                  className="hover:text-red-500 transition-colors text-white"
                  title={isPlaying ? 'Pause' : 'Play'}
                >
                  {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 fill-current" />}
                </button>

                {/* Rewind 10s */}
                <button
                  onClick={() => {
                    if (videoRef.current) {
                      const nextTime = Math.max(0, videoRef.current.currentTime - 10);
                      videoRef.current.currentTime = nextTime;
                      setCurrentTime(nextTime);
                    }
                  }}
                  className="hover:text-red-500 text-gray-400 transition-colors flex items-center gap-1 cursor-pointer"
                  title="Rewind 10s"
                >
                  <RotateCcw className="h-5 w-5" />
                  <span className="text-[10px] font-extrabold font-sans">-10s</span>
                </button>

                {/* Skip Forward 10s */}
                <button
                  onClick={() => {
                    if (videoRef.current) {
                      const nextTime = Math.min(duration || 0, videoRef.current.currentTime + 10);
                      videoRef.current.currentTime = nextTime;
                      setCurrentTime(nextTime);
                    }
                  }}
                  className="hover:text-red-500 text-gray-400 transition-colors flex items-center gap-1 cursor-pointer"
                  title="Forward 10s"
                >
                  <span className="text-[10px] font-extrabold font-sans">+10s</span>
                  <RotateCw className="h-5 w-5" />
                </button>

                {/* Volume sliders */}
                <div className="flex items-center gap-1.5 group">
                  <button onClick={toggleMute} className="hover:text-white text-gray-300">
                    {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={isMuted ? 0 : volume}
                    onChange={handleVolumeChange}
                    className="w-16 h-1 bg-gray-700 accent-red-600 rounded-lg appearance-none cursor-pointer group-hover:w-20 transition-all opacity-40 group-hover:opacity-100"
                  />
                </div>

                {/* Timestamp label */}
                <span className="text-xs font-mono tracking-wide text-gray-300">
                  {formatTime(currentTime)} <span className="text-gray-500">/</span> {formatTime(duration)}
                </span>
              </div>

              {/* Right Controls */}
              <div className="flex items-center gap-4">
                {/* Autoplay & AutoNext Switches */}
                <label className="hidden md:flex items-center gap-1.5 text-xs text-gray-400 hover:text-white cursor-pointer antialiased">
                  <input 
                    type="checkbox" 
                    checked={isAutoPlay}
                    onChange={(e) => setIsAutoPlay(e.target.checked)}
                    className="rounded border-gray-700 text-red-600 bg-gray-900 focus:ring-0 focus:ring-offset-0 h-3.5 w-3.5"
                  />
                  AutoPlay
                </label>

                <label className="hidden md:flex items-center gap-1.5 text-xs text-gray-400 hover:text-white cursor-pointer antialiased">
                  <input 
                    type="checkbox" 
                    checked={isAutoNext}
                    onChange={(e) => setIsAutoNext(e.target.checked)}
                    className="rounded border-gray-700 text-red-600 bg-gray-900 focus:ring-0 focus:ring-offset-0 h-3.5 w-3.5"
                  />
                  AutoNext
                </label>

                {/* Subtitles toggle icon */}
                <button 
                  onClick={() => setSubtitlesEnabled(!subtitlesEnabled)}
                  className={`hover:text-white transition-colors relative ${subtitlesEnabled ? 'text-red-500' : 'text-gray-400'}`}
                  title="Subtitles"
                >
                  <Captions className="h-4.5 w-4.5" />
                  {subtitlesEnabled && (
                    <span className="absolute bottom-0 -right-0.5 h-1.5 w-1.5 bg-red-500 rounded-full" />
                  )}
                </button>

                <button 
                  onClick={togglePip} 
                  className="hover:text-white text-gray-400 transition-colors"
                  title="Picture-in-Picture"
                >
                  <Tv className="h-4.5 w-4.5" />
                </button>

                {/* Custom Settings Popover trigger */}
                <div className="relative">
                  <button 
                    onClick={() => setShowSettings(!showSettings)} 
                    className={`hover:text-white transition-colors ${showSettings ? 'text-red-500' : 'text-gray-400'}`}
                    title="Player Settings"
                  >
                    <Settings className="h-4.5 w-4.5" />
                  </button>

                  {showSettings && (
                    <div className="absolute bottom-8 right-0 bg-gray-950 border border-gray-800 rounded-lg p-3 w-48 shadow-2xl z-35 flex flex-col gap-2">
                      <div className="text-[10px] uppercase font-bold tracking-wider text-gray-500 border-b border-gray-900 pb-1.5">
                        Quality
                      </div>
                      {['1080p', '720p', '480p', 'Auto'].map((q) => (
                        <button
                          key={q}
                          onClick={() => { setQuality(q); setShowSettings(false); }}
                          className={`text-left text-xs px-2 py-1 rounded transition-colors ${quality === q ? 'bg-red-600/20 text-red-400 font-semibold' : 'text-gray-300 hover:bg-gray-900'}`}
                        >
                          {q}
                        </button>
                      ))}

                      <div className="text-[10px] uppercase font-bold tracking-wider text-gray-500 border-b border-gray-900 pt-2 pb-1.5">
                        Speed
                      </div>
                      {[0.5, 1.0, 1.5, 2.0].map((rate) => (
                        <button
                          key={rate}
                          onClick={() => handlePlaybackSpeed(rate)}
                          className={`text-left text-xs px-2 py-1 rounded transition-colors ${playbackRate === rate ? 'bg-red-600/20 text-red-400 font-semibold' : 'text-gray-300 hover:bg-gray-900'}`}
                        >
                          {rate === 1.0 ? 'Normal (1.0x)' : `${rate}x`}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <button 
                  onClick={toggleFullscreen} 
                  className="hover:text-white text-gray-400 transition-colors"
                  title="Full-Screen"
                >
                  {isFullscreen ? <Minimize2 className="h-5 w-5" /> : <Maximize2 className="h-5 w-5" />}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Downloads / Sources Manager Block */}
      <div className="mt-4 bg-gray-900 border border-gray-800 rounded-xl p-4 overflow-hidden">
        {/* Live Streaming Server Selection */}
        <div className="pb-3 mb-4 border-b border-gray-855">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2.5">
            <span className="text-[11px] uppercase font-extrabold text-red-400 tracking-wider flex items-center gap-1.5 font-sans">
              <Tv className="h-3.5 w-3.5 animate-pulse text-red-500" /> Choose Stream Server / Hosting Mirror
            </span>
            <span className="text-[10px] text-gray-500 font-mono font-bold">Selected Host: {selectedServerLabel}</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {/* Primary Google Cloud CDN */}
            <button
              onClick={() => {
                setActiveVideoUrl(episode.videoUrl);
                setSelectedServerLabel('Primary Server (Original)');
              }}
              className={`px-3 py-1.5 rounded text-xs font-bold transition flex items-center gap-1.5 ${
                activeVideoUrl === episode.videoUrl 
                  ? 'bg-red-650/20 text-red-400 border border-red-500/30' 
                  : 'bg-gray-950 text-gray-400 hover:text-white border border-gray-850 hover:bg-gray-900'
              }`}
            >
              Default Engine (Direct CDN)
            </button>
            {/* Additional sources (TeraBox, Cloudinary, etc.) */}
            {episode.sources && episode.sources.map((src, idx) => (
              <button
                key={src.id || idx}
                onClick={() => {
                  setActiveVideoUrl(src.url);
                  setSelectedServerLabel(src.label);
                }}
                className={`px-3 py-1.5 rounded text-xs font-bold border transition ${
                  activeVideoUrl === src.url 
                    ? 'bg-red-650/20 text-red-400 border-red-500/30 font-extrabold' 
                    : 'bg-gray-950 text-gray-400 hover:text-white border border-gray-850 hover:bg-gray-900'
                }`}
              >
                {src.label} Source
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-gray-800 pb-3 mb-3">
          <div>
            <h3 className="text-sm font-bold text-gray-200">
              Episode {episode.number}: {episode.name}
            </h3>
            <p className="text-xs text-gray-400 font-medium">
              Audio Track: <span className="text-red-400 font-extrabold uppercase">{episode.language || 'Japanese'} Audio</span> • Resolution: <span className="text-red-400 font-semibold">{quality}</span> • Subtitles: {subtitlesEnabled ? 'English Mapped' : 'Off'}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-gray-400">Downloads Mirror:</span>
            <div className="flex gap-2">
              <span className="text-xs font-mono bg-red-600/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded font-semibold flex items-center gap-1">
                <Radio className="h-3 w-3 animate-pulse" /> Live Streaming Mirror
              </span>
            </div>
          </div>
        </div>

        {/* Source link grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
          {episode.downloads.length > 0 ? (
            episode.downloads.map((source, index) => (
              <a
                key={source.id || index}
                href={source.url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-between px-3.5 py-2.5 bg-gray-950 hover:bg-gray-900 border border-gray-800 rounded-lg text-xs font-semibold text-gray-300 hover:text-red-400 transition-all"
              >
                <span className="truncate">{source.label}</span>
                <Download className="h-3.5 w-3.5" />
              </a>
            ))
          ) : (
            <>
              {/* Fallback default download sources if empty */}
              {['Google Drive Cloud', 'TeraBox Fast Mirror', 'Mega Core Link', 'OneDrive Mirror'].map((label, index) => (
                <a
                  key={index}
                  href={`https://otakuuniverse.com/dl/${episode.id}?server=${index}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-between px-3.5 py-2.5 bg-gray-950 hover:bg-gray-900 border border-gray-800 rounded-lg text-xs font-semibold text-gray-300 hover:text-red-400 transition-all"
                >
                  <span className="truncate">{label}</span>
                  <Download className="h-3.5 w-3.5" />
                </a>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function HistoryPromptIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 8v4l3 3" />
      <path d="M3.3 14a9 9 0 1 1 .1 4.5" />
      <path d="M1.3 18h4.5v-4.5" />
    </svg>
  );
}
