import React, { useState, useEffect } from 'react';
import { 
  Users, Globe, Palette, Server, Radio, Upload, Activity, ShieldAlert, 
  Trash2, Plus, Check, Save, Download, Play, Pause, AlertTriangle, 
  CheckCircle, FileText, Settings, RefreshCw, Key, Image, Eye, Flame, Edit, Ban
} from 'lucide-react';
import JSZip from 'jszip';
import { Anime, Season, Episode, User, ServiceConnections, AdCampaign, RealtimeEvent, Language, TranslationMap, SecurityLog, FileAsset, SourceLink } from '../types';

interface AdminPanelProps {
  onClose: () => void;
  currentUser: User | null;
  animeList: Anime[];
  onUpdateAnimeList: (list: Anime[]) => void;
  seasonsList: Season[];
  onUpdateSeasonsList: (list: Season[]) => void;
  episodesList: Episode[];
  onUpdateEpisodesList: (list: Episode[]) => void;
  usersList: User[];
  onUpdateUsersList: (list: User[]) => void;
  languagesList: Language[];
  onUpdateLanguagesList: (list: Language[]) => void;
  themeConfig: any;
  onUpdateThemeConfig: (config: any) => void;
  connections: ServiceConnections;
  onUpdateConnections: (conns: ServiceConnections) => void;
  adCampaigns: AdCampaign[];
  onUpdateAdCampaigns: (ads: AdCampaign[]) => void;
  realtimeEvents: RealtimeEvent[];
  onAddRealtimeEvent: (evt: RealtimeEvent) => void;
  securityLogs: SecurityLog[];
  fileAssets: FileAsset[];
  onAddFileAsset: (asset: FileAsset) => void;
  // Realtime system options & controls
  realtimeConnected?: boolean;
  realtimeEnabled?: boolean;
  onSetRealtimeEnabled?: (val: boolean) => void;
  simulatedColleagueActive?: boolean;
  onSetSimulatedColleagueActive?: (val: boolean) => void;
  onlinePresences?: any[];
  onTriggerSharedDataRefresh?: () => void;
  customRealtimeUrl?: string;
  onSetCustomRealtimeUrl?: (url: string) => void;
}

const ROLE_PERMISSIONS: Record<string, string[]> = {
  'Super Admin': ['manager', 'upload', 'connections', 'ads', 'languages', 'theme', 'roles', 'assets', 'security', 'deployment', 'episodesByLanguage', 'realtime'],
  'Admin': ['manager', 'upload', 'languages', 'theme', 'assets', 'episodesByLanguage', 'realtime'],
  'Moderator': ['manager', 'languages', 'episodesByLanguage', 'realtime'],
  'Uploader': ['upload', 'assets', 'episodesByLanguage', 'realtime'],
  'Editor': ['manager', 'episodesByLanguage', 'realtime'],
  'Support': ['languages', 'realtime'],
  'User': []
};

export default function AdminPanel({
  onClose,
  currentUser,
  animeList,
  onUpdateAnimeList,
  seasonsList,
  onUpdateSeasonsList,
  episodesList,
  onUpdateEpisodesList,
  usersList,
  onUpdateUsersList,
  languagesList,
  onUpdateLanguagesList,
  themeConfig,
  onUpdateThemeConfig,
  connections,
  onUpdateConnections,
  adCampaigns,
  onUpdateAdCampaigns,
  realtimeEvents,
  onAddRealtimeEvent,
  securityLogs,
  fileAssets,
  onAddFileAsset,
  realtimeConnected = false,
  realtimeEnabled = true,
  onSetRealtimeEnabled,
  simulatedColleagueActive = false,
  onSetSimulatedColleagueActive,
  onlinePresences = [],
  onTriggerSharedDataRefresh,
  customRealtimeUrl = '',
  onSetCustomRealtimeUrl
}: AdminPanelProps) {
  
  // Dashboard states
  const userRole = currentUser?.role || 'User';
  const allowedTabs = ROLE_PERMISSIONS[userRole] || [];
  
  const [activeTab, setActiveTab] = useState<'manager' | 'upload' | 'connections' | 'ads' | 'roles' | 'languages' | 'theme' | 'assets' | 'security' | 'deployment' | 'episodesByLanguage' | 'realtime'>('manager');

  // Enforce correct default tab if first tab is not allowed
  useEffect(() => {
    if (allowedTabs.length > 0 && !allowedTabs.includes(activeTab)) {
      setActiveTab(allowedTabs[0] as any);
    }
  }, [currentUser, allowedTabs]);

  // Language Episode Manager states
  const [selectedLanguageForEp, setSelectedLanguageForEp] = useState<'Japanese' | 'English' | 'Hindi' | 'Bangla'>('Japanese');
  const [selectedAnimeIdForEp, setSelectedAnimeIdForEp] = useState<string>(animeList[0]?.id || '');

  // Add flow local states
  const [showAddEpModal, setShowAddEpModal] = useState(false);
  const [addEpName, setAddEpName] = useState('');
  const [addEpNumber, setAddEpNumber] = useState('');
  const [addEpDuration, setAddEpDuration] = useState('24');
  const [addEpVideoUrl, setAddEpVideoUrl] = useState('https://www.w3schools.com/html/mov_bbb.mp4');
  const [addEpSeasonNumber, setAddEpSeasonNumber] = useState(1);

  // Edit flow local states
  const [editingEp, setEditingEp] = useState<Episode | null>(null);
  const [editEpName, setEditEpName] = useState('');
  const [editEpNumber, setEditEpNumber] = useState('');
  const [editEpDuration, setEditEpDuration] = useState('24');
  const [editEpVideoUrl, setEditEpVideoUrl] = useState('');
  const [editEpSeasonNumber, setEditEpSeasonNumber] = useState(1);

  const [connectionStates, setConnectionStates] = useState<ServiceConnections>(connections);
  const [isTestingConn, setIsTestingConn] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ service: string; status: 'ok' | 'error' } | null>(null);
  const [zipStatus, setZipStatus] = useState<'idle' | 'generating' | 'done'>('idle');
  const [netlifyZipStatus, setNetlifyZipStatus] = useState<'idle' | 'generating' | 'done'>('idle');

  // Role Management Selector
  const [localUrlInput, setLocalUrlInput] = useState(customRealtimeUrl || '');

  useEffect(() => {
    setLocalUrlInput(customRealtimeUrl);
  }, [customRealtimeUrl]);
  const [selectedUser, setSelectedUser] = useState<string | null>(null);

  // Translation Editor state
  const [selectedLanguageForTx, setSelectedLanguageForTx] = useState<string>('bn');
  const [editedTranslations, setEditedTranslations] = useState<{ [key: string]: string }>({});

  // Super-Uploader Local Form states
  const [upName, setUpName] = useState('');
  const [upAltName, setUpAltName] = useState('');
  const [upPoster, setUpPoster] = useState('https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500');
  const [upBanner, setUpBanner] = useState('https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=1200');
  const [upTrailer, setUpTrailer] = useState('https://www.youtube.com/embed/dQw4w9WgXcQ');
  const [upStudio, setUpStudio] = useState('ufotable');
  const [upYear, setUpYear] = useState('2026');
  const [upStatus, setUpStatus] = useState<'Ongoing' | 'Completed' | 'Upcoming'>('Ongoing');
  const [upSynopsis, setUpSynopsis] = useState('');
  const [upGenres, setUpGenres] = useState('Action, Fantasy, Shounen');
  const [upTags, setUpTags] = useState('Demon Hunter, Epic Fight');
  const [upLanguage, setUpLanguage] = useState<'Japanese' | 'English' | 'Hindi' | 'Bangla'>('Japanese');

  // Multi episode rows state
  const [episodeRows, setEpisodeRows] = useState<Array<{ number: number; name: string; url: string; duration: number }>>([
    { number: 1, name: 'Episode 1: Awakening', url: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: 24 }
  ]);

  // Single Episode Upload Form
  const [selAnimeId, setSelAnimeId] = useState(animeList[0]?.id || '');
  const [selSeasonNumber, setSelSeasonNumber] = useState(1);
  const [singleEpName, setSingleEpName] = useState('');
  const [singleEpNumber, setSingleEpNumber] = useState('');
  const [singleEpMediaUrl, setSingleEpMediaUrl] = useState('https://www.w3schools.com/html/mov_bbb.mp4');
  const [singleEpGdriveUrl, setSingleEpGdriveUrl] = useState('');
  const [singleEpTeraboxUrl, setSingleEpTeraboxUrl] = useState('');
  const [singleEpCloudinaryUrl, setSingleEpCloudinaryUrl] = useState('');
  const [singleEpDuration, setSingleEpDuration] = useState('24');
  const [singleEpLanguage, setSingleEpLanguage] = useState<'Japanese' | 'English' | 'Hindi' | 'Bangla'>('Japanese');

  // Real revenue reset logic
  const [revenueResetOffset, setRevenueResetOffset] = useState<number>(() => {
    const saved = localStorage.getItem('otaku_rev_offset');
    return saved ? parseFloat(saved) : 0;
  });

  // Calculate real values dynamically
  const totalClicks = adCampaigns.reduce((sum, ad) => sum + ad.clicks, 0);
  const totalImpressions = adCampaigns.reduce((sum, ad) => sum + ad.impressions, 0);
  const totalVideoViews = animeList.reduce((sum, anime) => sum + anime.views, 0);

  const rawRevenue = (totalClicks * 0.05) + ((totalImpressions / 1000) * 1.50) + ((totalVideoViews / 1000) * 1.80);
  const realRevenue = Math.max(0, rawRevenue - revenueResetOffset);

  const handleResetRevenue = () => {
    if (window.confirm('Reset all accumulated platform revenue statistics? Future views and clicks will count starting from $0.')) {
      setRevenueResetOffset(rawRevenue);
      localStorage.setItem('otaku_rev_offset', String(rawRevenue));
      triggerNotificationBanner('Platform revenue counter has been reset to $0.00!');
      onAddRealtimeEvent({
        id: 'evt-' + Date.now(),
        eventName: 'revenue_reset',
        timestamp: 'Now',
        description: `Revenue counter benchmark reset to 0 database benchmarks.`,
        status: 'warn'
      });
    }
  };

  const handleResetAllViews = () => {
    if (window.confirm('Reset all anime and episode view counts back to 0 across the database?')) {
      const resetAnime = animeList.map(a => ({ ...a, views: 0 }));
      const resetEpisodes = episodesList.map(e => ({ ...e, views: 0 }));
      onUpdateAnimeList(resetAnime);
      onUpdateEpisodesList(resetEpisodes);
      triggerNotificationBanner('All video stream view counts reset to 0!');
      onAddRealtimeEvent({
        id: 'evt-' + Date.now(),
        eventName: 'views_reset',
        timestamp: 'Now',
        description: `All anime catalog and episode streaming counters have been fully reset.`,
        status: 'warn'
      });
    }
  };

  const handleResetAdStats = () => {
    if (window.confirm('Reset all advertisement impression and click counts to 0?')) {
      const resetAds = adCampaigns.map(ad => ({ ...ad, impressions: 0, clicks: 0 }));
      onUpdateAdCampaigns(resetAds);
      triggerNotificationBanner('Real-time click & impression metrics reset to 0!');
      onAddRealtimeEvent({
        id: 'evt-' + Date.now(),
        eventName: 'ads_reset',
        timestamp: 'Now',
        description: `Ad campaign performance trackers cleared back to absolute zero benchmark.`,
        status: 'warn'
      });
    }
  };

  // Anime Edit Modal States
  const [editingAnime, setEditingAnime] = useState<Anime | null>(null);
  const [editName, setEditName] = useState('');
  const [editPoster, setEditPoster] = useState('');
  const [editBanner, setEditBanner] = useState('');
  const [editTrailer, setEditTrailer] = useState('');
  const [editSynopsis, setEditSynopsis] = useState('');
  const [editStudio, setEditStudio] = useState('');
  const [editYear, setEditYear] = useState('2026');
  const [editStatus, setEditStatus] = useState<'Ongoing' | 'Completed' | 'Upcoming'>('Ongoing');
  const [editGenres, setEditGenres] = useState('');
  const [editTags, setEditTags] = useState('');

  const startEditingAnime = (anime: Anime) => {
    setEditingAnime(anime);
    setEditName(anime.name);
    setEditPoster(anime.poster);
    setEditBanner(anime.banner);
    setEditTrailer(anime.trailer);
    setEditSynopsis(anime.synopsis || '');
    setEditStudio(anime.studio || '');
    setEditYear(String(anime.year));
    setEditStatus(anime.status || 'Ongoing');
    setEditGenres(anime.genres.join(', '));
    setEditTags(anime.tags.join(', '));
  };

  const handleSaveEditAnime = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAnime) return;

    const updatedList = animeList.map(a => {
      if (a.id === editingAnime.id) {
        return {
          ...a,
          name: editName,
          poster: editPoster,
          banner: editBanner,
          trailer: editTrailer,
          synopsis: editSynopsis,
          studio: editStudio,
          year: parseInt(editYear) || 2026,
          status: editStatus,
          genres: editGenres.split(',').map(s => s.trim()),
          tags: editTags.split(',').map(s => s.trim())
        };
      }
      return a;
    });

    onUpdateAnimeList(updatedList);
    setEditingAnime(null);
    triggerNotificationBanner('Anime catalog item updated completely!');
    
    onAddRealtimeEvent({
      id: 'evt-' + Date.now(),
      eventName: 'anime_modified',
      timestamp: 'Now',
      description: `Anime "${editName}" modifications saved by Super Admin.`,
      status: 'info'
    });
  };

  // New Language Local form
  const [newLangCode, setNewLangCode] = useState('');
  const [newLangName, setNewLangName] = useState('');

  // Local notification builder
  const [notifyTitle, setNotifyTitle] = useState('');
  const [notifyBody, setNotifyBody] = useState('');
  const [notifyChannels, setNotifyChannels] = useState({ web: true, email: true, telegram: true });
  const [notificationStatus, setNotificationStatus] = useState<React.ReactNode | null>(null);

  // File Upload local form
  const [fileUrl, setFileUrl] = useState('');
  const [fileName, setFileName] = useState('');
  const [fileType, setFileType] = useState<'image' | 'video' | 'subtitle' | 'logo'>('image');
  const [fileSizeStr, setFileSizeStr] = useState('320 KB');

  // Quick Action feedback
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);

  // Handle Dynamic Translation loading
  useEffect(() => {
    // Read translations from localStorage or initialize
    const storedDict = localStorage.getItem('otaku_dictionary');
    const dictionary = storedDict ? JSON.parse(storedDict) : {};
    
    const items: { [key: string]: string } = {};
    Object.keys(dictionary).forEach(key => {
      items[key] = dictionary[key][selectedLanguageForTx] || '';
    });
    setEditedTranslations(items);
  }, [selectedLanguageForTx]);

  // Test System connections trigger
  const runTestConnection = (service: string, value: string) => {
    setIsTestingConn(service);
    setTestResult(null);

    // Dynamic logging for events
    onAddRealtimeEvent({
      id: 'evt-' + Date.now(),
      eventName: 'test_connection',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      description: `Initiated active socket ping test to service: ${service}...`,
      status: 'info'
    });

    setTimeout(() => {
      setIsTestingConn(null);
      // Basic check
      if (value.trim().length > 6 && !value.includes('MY_') && !value.includes('placeholder')) {
        setTestResult({ service, status: 'ok' });
        // update connection status badge in state
        const updated = { ...connectionStates };
        if (service === 'mongodb') updated.mongoStatus = 'connected';
        if (service === 'socketio') updated.socketStatus = 'connected';
        if (service === 'firebase') updated.firebaseStatus = 'connected';
        if (service === 'cloudinary') updated.storageStatus = 'connected';
        if (service === 'smtp') updated.smtpStatus = 'connected';
        if (service === 'telegram') updated.telegramStatus = 'connected';
        setConnectionStates(updated);
        onUpdateConnections(updated);

        onAddRealtimeEvent({
          id: 'evt-' + Date.now(),
          eventName: 'test_connection_success',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          description: `Established robust handshake with ${service}. Status code: 200 OK.`,
          status: 'success'
        });
      } else {
        setTestResult({ service, status: 'error' });
        const updated = { ...connectionStates };
        if (service === 'mongodb') updated.mongoStatus = 'disconnected';
        if (service === 'socketio') updated.socketStatus = 'disconnected';
        if (service === 'firebase') updated.firebaseStatus = 'disconnected';
        if (service === 'cloudinary') updated.storageStatus = 'disconnected';
        if (service === 'smtp') updated.smtpStatus = 'disconnected';
        if (service === 'telegram') updated.telegramStatus = 'disconnected';
        setConnectionStates(updated);
        onUpdateConnections(updated);

        onAddRealtimeEvent({
          id: 'evt-' + Date.now(),
          eventName: 'test_connection_failed',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          description: `Failed connection attempt to ${service}. Verify certificate hashes / secret token parameters.`,
          status: 'warn'
        });
      }
    }, 1500);
  };

  // Safe global service manager setup
  const saveGlobalConnections = () => {
    onUpdateConnections(connectionStates);
    triggerNotificationBanner('Global Connections and API Hub configured successfully!');
    
    onAddRealtimeEvent({
      id: 'evt-' + Date.now(),
      eventName: 'connections_saved',
      timestamp: 'Now',
      description: 'Super Admin updated website hub connections, routing API endpoints globally.',
      status: 'success'
    });
  };

  const triggerNotificationBanner = (msg: string) => {
    setSaveFeedback(msg);
    setTimeout(() => setSaveFeedback(null), 3000);
  };

  // Theme builder configuration application
  const saveThemeConfig = (key: string, value: string) => {
    const updated = { ...themeConfig, [key]: value };
    onUpdateThemeConfig(updated);
    triggerNotificationBanner(`Theme config updated: ${key} = ${value}`);
  };

  // Add a brand new supported Language
  const handleAddLanguage = () => {
    if (!newLangCode || !newLangName) return;
    const exists = languagesList.find(l => l.code.toLowerCase() === newLangCode.toLowerCase());
    if (exists) {
      alert('Language code already exists!');
      return;
    }
    const newList = [...languagesList, { code: newLangCode.toLowerCase(), name: newLangName, isDefault: false }];
    onUpdateLanguagesList(newList);
    setNewLangCode('');
    setNewLangName('');
    triggerNotificationBanner(`Added translation mapping for English <=> ${newLangName}`);
  };

  const handleRemoveLanguage = (code: string) => {
    if (languagesList.length <= 1) {
      alert('At least one default language must be maintained.');
      return;
    }
    const newList = languagesList.filter(l => l.code !== code);
    onUpdateLanguagesList(newList);
    triggerNotificationBanner(`Deleted language support: ${code}`);
  };

  const handleSetDefaultLanguage = (code: string) => {
    const newList = languagesList.map(l => ({ ...l, isDefault: l.code === code }));
    onUpdateLanguagesList(newList);
    triggerNotificationBanner(`Default viewer site language mapped to ${code}`);
  };

  // Upload/Modify the specific translation text entries
  const handleSaveTranslations = () => {
    // Load existing mapping dictionary
    const storedDict = localStorage.getItem('otaku_dictionary');
    const dictionary = storedDict ? JSON.parse(storedDict) : {};
    
    // Merge edited strings back
    Object.keys(editedTranslations).forEach(key => {
      if (!dictionary[key]) {
        dictionary[key] = {};
      }
      dictionary[key][selectedLanguageForTx] = editedTranslations[key];
    });

    localStorage.setItem('otaku_dictionary', JSON.stringify(dictionary));
    triggerNotificationBanner('Translations committed into the database index!');
  };

  // Super Uploader flow adding full Anime Catalogue, custom automatic seasons, and custom episodes
  const handleSuperUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!upName) {
      alert('Please fill out the anime name!');
      return;
    }

    // Check if anime already exists (case-insensitive)
    const existingAnime = animeList.find(a => a.name.toLowerCase() === upName.trim().toLowerCase());
    const targetAnimeId = existingAnime ? existingAnime.id : 'a-' + (animeList.length + 1);
    
    let updatedAnimeList = [...animeList];
    if (!existingAnime) {
      if (!upSynopsis) {
        alert('Please fill out the anime synopsis for new anime series!');
        return;
      }
      const newAnime: Anime = {
        id: targetAnimeId,
        name: upName.trim(),
        altNames: upAltName ? upAltName.split(',').map(s => s.trim()) : [],
        poster: upPoster,
        banner: upBanner,
        trailer: upTrailer,
        synopsis: upSynopsis,
        studio: upStudio,
        year: parseInt(upYear) || 2026,
        status: upStatus,
        genres: upGenres.split(',').map(s => s.trim()),
        tags: upTags.split(',').map(s => s.trim()),
        views: 0,
        likes: 0,
        favorites: 0,
        watchTime: 0,
        rating: 8.5,
        reviews: [],
        characters: [],
        screenshots: []
      };
      updatedAnimeList = [newAnime, ...animeList];
    }

    // Auto-generate target Season 1
    const newSeasonId = `s-${targetAnimeId}_1`;
    let updatedSeasonsList = [...seasonsList];
    const findSeason = seasonsList.find(s => s.id === newSeasonId);
    if (!findSeason) {
      const newSeason: Season = {
        id: newSeasonId,
        animeId: targetAnimeId,
        name: 'Season 1: Complete Arc',
        number: 1
      };
      updatedSeasonsList = [...seasonsList, newSeason];
    }

    // Build episodes automatically mapped to the selected language with smart server identification
    const newEpisodes: Episode[] = episodeRows.map((row) => {
      const rawUrlField = row.url || '';
      // Support semicolon, comma, or pipeline separated values
      const splitUrls = rawUrlField.split(/[,;|]+/).map(item => item.trim()).filter(Boolean);
      const primaryVideoUrl = splitUrls[0] || 'https://www.w3schools.com/html/mov_bbb.mp4';
      
      const mappedSources: SourceLink[] = [];
      splitUrls.forEach((url, i) => {
        let hostLabel = 'Alternate';
        if (url.includes('drive.google.com') || url.includes('docs.google.com')) {
          hostLabel = 'Google Drive Mirror';
        } else if (url.includes('terabox')) {
          hostLabel = 'TeraBox Stream';
        } else if (url.includes('cloudinary')) {
          hostLabel = 'Cloudinary Premium';
        } else if (url.includes('mega.nz')) {
          hostLabel = 'Mega NZ Server';
        } else {
          hostLabel = `Server Source ${i + 1}`;
        }
        mappedSources.push({
          id: `src-super-${Date.now()}-${row.number}-${i}`,
          label: hostLabel,
          url
        });
      });

      return {
        id: `e-${targetAnimeId}_1_${row.number}_${upLanguage.toLowerCase()}`,
        seasonId: newSeasonId,
        animeId: targetAnimeId,
        name: row.name || `Episode ${row.number}`,
        number: row.number,
        duration: row.duration || 24,
        videoUrl: primaryVideoUrl,
        subtitleUrl: '',
        views: 0,
        language: upLanguage,
        downloads: [
          { id: `dl-${targetAnimeId}_1_${row.number}_${upLanguage.toLowerCase()}_g`, label: `${upLanguage} Google Drive Speed Link`, url: primaryVideoUrl },
          { id: `dl-${targetAnimeId}_1_${row.number}_${upLanguage.toLowerCase()}_m`, label: `${upLanguage} Alternate Streaming Mirror`, url: splitUrls[1] || primaryVideoUrl }
        ],
        sources: mappedSources
      };
    });

    // Filter out existing duplicates (same anime, season, episode number, and language)
    const filteredEpisodesList = episodesList.filter(ep => 
      !(ep.animeId === targetAnimeId && ep.seasonId === newSeasonId && ep.number === ep.number && (ep.language || 'Japanese') === upLanguage)
    );

    // Update global state
    onUpdateAnimeList(updatedAnimeList);
    onUpdateSeasonsList(updatedSeasonsList);
    onUpdateEpisodesList([...filteredEpisodesList, ...newEpisodes]);

    // Logging events
    onAddRealtimeEvent({
      id: 'evt-' + Date.now(),
      eventName: 'anime_created',
      timestamp: 'Now',
      description: `Anime "${upName}" Super Uploaded in (${upLanguage}): Season 1 synchronized with ${newEpisodes.length} episodes!`,
      status: 'success'
    });

    // Reset Form
    setUpName('');
    setUpAltName('');
    setUpSynopsis('');
    setEpisodeRows([{ number: 1, name: 'Episode 1: Awakening', url: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: 24 }]);
    
    triggerNotificationBanner(`Successfully super uploaded episodes for "${upName}" in ${upLanguage}!`);
    setActiveTab('manager');
  };

  // Single Episode Upload flow
  const handleSingleEpisodeUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!singleEpName || !singleEpNumber) return;

    const num = parseInt(singleEpNumber);
    const existingAnime = animeList.find(a => a.id === selAnimeId);
    if (!existingAnime) return;

    // Check season
    const targetSeasonId = `s-${selAnimeId}_${selSeasonNumber}`;
    const findSeason = seasonsList.find(s => s.id === targetSeasonId);

    if (!findSeason) {
      // Create season automatically
      const newSeason: Season = {
        id: targetSeasonId,
        animeId: selAnimeId,
        name: `Season ${selSeasonNumber}`,
        number: selSeasonNumber
      };
      onUpdateSeasonsList([...seasonsList, newSeason]);
      onAddRealtimeEvent({
        id: 'evt-' + Date.now(),
        eventName: 'season_created',
        timestamp: 'Now',
        description: `Season ${selSeasonNumber} built automatically for ${existingAnime.name}.`,
        status: 'info'
      });
    }

    const extraSources: SourceLink[] = [];
    if (singleEpGdriveUrl) {
      extraSources.push({ id: `src-gdrive-${Date.now()}`, label: 'Google Drive Stream Server', url: singleEpGdriveUrl });
    }
    if (singleEpTeraboxUrl) {
      extraSources.push({ id: `src-terabox-${Date.now()}`, label: 'TeraBox Streaming Server', url: singleEpTeraboxUrl });
    }
    if (singleEpCloudinaryUrl) {
      extraSources.push({ id: `src-cloudinary-${Date.now()}`, label: 'Cloudinary Highspeed Mirror', url: singleEpCloudinaryUrl });
    }

    const newEp: Episode = {
      id: `e-${selAnimeId}_${selSeasonNumber}_${num}_${singleEpLanguage.toLowerCase()}`,
      seasonId: targetSeasonId,
      animeId: selAnimeId,
      name: singleEpName,
      number: num,
      duration: parseInt(singleEpDuration) || 24,
      videoUrl: singleEpMediaUrl,
      subtitleUrl: '',
      views: 0,
      language: singleEpLanguage,
      downloads: [
        { id: `dl-${selAnimeId}_ep-${num}-${singleEpLanguage.toLowerCase()}-g`, label: `${singleEpLanguage} Google Drive Mirror`, url: singleEpMediaUrl }
      ],
      sources: extraSources
    };

    // Filter out duplicates with the same animeId, seasonId, number, and language
    const filteredEpisodesList = episodesList.filter(ep => 
      !(ep.animeId === selAnimeId && ep.seasonId === targetSeasonId && ep.number === num && (ep.language || 'Japanese') === singleEpLanguage)
    );

    onUpdateEpisodesList([...filteredEpisodesList, newEp]);

    onAddRealtimeEvent({
      id: 'evt-' + Date.now(),
      eventName: 'episode_uploaded',
      timestamp: 'Now',
      description: `Episode ${num}: "${singleEpName}" (${singleEpLanguage}) appended under ${existingAnime.name} Season ${selSeasonNumber}.`,
      status: 'success'
    });

    // Reset Form
    setSingleEpName('');
    setSingleEpNumber('');
    setSingleEpGdriveUrl('');
    setSingleEpTeraboxUrl('');
    setSingleEpCloudinaryUrl('');
    triggerNotificationBanner(`Single Episode (${singleEpLanguage}) registered successfully!`);
  };

  // Live Notification Dispatcher (Email, web push, telegram)
  const handleDispatchNotification = () => {
    if (!notifyTitle || !notifyBody) {
      alert('Kindly configure title and body!');
      return;
    }

    // Build trigger logic
    let channelLogs = [];
    if (notifyChannels.web) channelLogs.push('Web Push 🟢');
    if (notifyChannels.email) channelLogs.push('SMTP Emails 🟢');
    if (notifyChannels.telegram) channelLogs.push('Telegram Bot 🟢');

    setNotificationStatus(
      <span className="text-emerald-400 font-semibold text-xs flex items-center gap-1.5 mt-2 animate-pulse">
        <CheckCircle className="h-4 w-4" /> Dispatched to: {channelLogs.join(', ')}
      </span>
    );

    onAddRealtimeEvent({
      id: 'evt-' + Date.now(),
      eventName: 'notification_sent',
      timestamp: 'Now',
      description: `Broadcasted update notifications. Title: "${notifyTitle}". Routes used: ${channelLogs.join(', ')}`,
      status: 'success'
    });

    setNotifyTitle('');
    setNotifyBody('');
    setTimeout(() => {
      setNotificationStatus(null);
    }, 4000);
  };

  // Modify user roles
  const handleUserRoleChange = (userId: string, role: string) => {
    const updated = usersList.map(u => {
      if (u.id === userId) {
        return { ...u, role: role as any };
      }
      return u;
    });
    onUpdateUsersList(updated);
    
    // Audit log
    onAddRealtimeEvent({
      id: 'evt-' + Date.now(),
      eventName: 'role_changed',
      timestamp: 'Now',
      description: `User role for ${usersList.find(u => u.id === userId)?.name} altered to ${role}. Access rules refreshed.`,
      status: 'info'
    });

    triggerNotificationBanner('User system clearance updated!');
  };

  // Ban or unban user controls
  const handleUserStatusChange = (userId: string, status: 'active' | 'banned' | 'suspended') => {
    const updated = usersList.map(u => {
      if (u.id === userId) {
        return { ...u, status };
      }
      return u;
    });
    onUpdateUsersList(updated);

    onAddRealtimeEvent({
      id: 'evt-' + Date.now(),
      eventName: status === 'banned' ? 'user_banned' : 'user_unbanned',
      timestamp: 'Now',
      description: `User target ID ${userId} status altered to "${status}".`,
      status: 'warn'
    });

    triggerNotificationBanner(`User status set to ${status}!`);
  };

  // Handle media file assets uploading simulated
  const handleFileAssetUpload = () => {
    if (!fileName || !fileUrl) return;
    const newAss: FileAsset = {
      id: 'f-' + Date.now(),
      name: fileName,
      type: fileType,
      url: fileUrl,
      size: fileSizeStr,
      uploadedAt: new Date().toISOString().split('T')[0]
    };
    onAddFileAsset(newAss);
    setFileName('');
    setFileUrl('');
    triggerNotificationBanner('File assets indexed under storage container!');
  };

  // Export full project structured zip generator
  const generateProductionZip = async () => {
    setZipStatus('generating');
    
    onAddRealtimeEvent({
      id: 'evt-' + Date.now(),
      eventName: 'backup_started',
      timestamp: 'Now',
      description: 'Beginning compilation of OTT frontend, backend microserver, Docker configs, Netlify setups, and dynamic schemas...',
      status: 'info'
    });

    try {
      const link = document.createElement("a");
      link.href = "/api/download-source-zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setTimeout(() => {
        setZipStatus('done');
        onAddRealtimeEvent({
          id: 'evt-' + Date.now(),
          eventName: 'backup_complete',
          timestamp: 'Now',
          description: 'Successfully exported Production ZIP containing dynamic assets, schemas, Docker controls and routing systems.',
          status: 'success'
        });
      }, 1500);

    } catch (err: any) {
      console.error(err);
      setZipStatus('idle');
      alert('Error downloading ZIP package: ' + err.message);
    }
  };

  // Generate 100% pre-compiled static deployment ZIP for Netlify Drop
  const generateNetlifyDropZip = async () => {
    setNetlifyZipStatus('generating');
    onAddRealtimeEvent({
      id: 'evt-' + Date.now(),
      eventName: 'backup_started',
      timestamp: 'Now',
      description: 'Beginning compilation of 100% pre-compiled static assets for Netlify Drop...',
      status: 'info'
    });

    try {
      const link = document.createElement("a");
      link.href = "/api/download-netlify-drop-zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setTimeout(() => {
        setNetlifyZipStatus('done');
        onAddRealtimeEvent({
          id: 'evt-' + Date.now(),
          eventName: 'backup_complete',
          timestamp: 'Now',
          description: 'Successfully exported 1-Click Netlify Drop ready ZIP containing compiled static client code.',
          status: 'success'
        });
      }, 1500);
    } catch (err: any) {
      console.error(err);
      setNetlifyZipStatus('idle');
      alert('Error downloading Netlify Drop ZIP: ' + err.message);
    }
  };

  // Clear visual banner ad state helpers
  const handleAddNewAd = (e: React.FormEvent) => {
    e.preventDefault();
    // Quick custom banner or overlay ad
    const titleVal = (document.getElementById('adTitle') as HTMLInputElement)?.value;
    const typeVal = (document.getElementById('adType') as HTMLSelectElement)?.value as any;
    const imgVal = (document.getElementById('adImage') as HTMLInputElement)?.value;
    const cVal = (document.getElementById('adLink') as HTMLInputElement)?.value;
    const countryVal = (document.getElementById('adCountry') as HTMLSelectElement)?.value;

    if (!titleVal || !cVal) return;

    const newAd: AdCampaign = {
      id: 'ad-' + Date.now(),
      title: titleVal,
      type: typeVal,
      imageUrl: imgVal || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800',
      ctaLink: cVal,
      targetCountry: countryVal || 'All',
      enabled: true,
      impressions: 0,
      clicks: 0
    };

    onUpdateAdCampaigns([...adCampaigns, newAd]);
    triggerNotificationBanner('Smart Direct Link Banner configured and active!');
    
    // Clear
    (document.getElementById('adTitle') as HTMLInputElement).value = '';
    (document.getElementById('adLink') as HTMLInputElement).value = '';
  };

  // Tab configurations
  const menuItems = [
    { id: 'manager', label: 'Anime Hub', icon: FilmIcon },
    { id: 'upload', label: 'Super Upload', icon: Upload },
    { id: 'episodesByLanguage', label: 'Language Episode Manager', icon: Play },
    { id: 'realtime', label: 'Real-Time Live Sync', icon: RefreshCw },
    { id: 'connections', label: 'Connections Hub', icon: Server },
    { id: 'ads', label: 'Monetization & Ads', icon: Radio },
    { id: 'languages', label: 'Language Translate', icon: Globe },
    { id: 'theme', label: 'Theme Designer', icon: Palette },
    { id: 'roles', label: 'User & Roles', icon: Users },
    { id: 'assets', label: 'File Manager', icon: Image },
    { id: 'security', label: 'Security & Logs', icon: ShieldAlert },
    { id: 'deployment', label: 'Deployment ZIP', icon: FileText },
  ].filter(item => allowedTabs.includes(item.id));

  return (
    <div className="fixed inset-0 bg-gray-950/95 flex z-50 overflow-hidden backdrop-blur-md font-sans text-gray-200">
      
      {/* Edit Anime Modal Form */}
      {editingAnime && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-55 overflow-y-auto backdrop-blur-sm">
          <div className="bg-gray-950 border border-gray-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-250 text-left">
            {/* Header */}
            <div className="px-6 py-4 border-b border-gray-900 flex items-center justify-between bg-gray-950">
              <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Edit className="h-4.5 w-4.5 text-red-500 animate-pulse" /> Modify Catalog Resource: {editName || 'Loading...'}
              </h3>
              <button 
                type="button"
                onClick={() => setEditingAnime(null)}
                className="text-gray-450 hover:text-white font-mono text-base font-bold p-1 bg-gray-900 rounded border border-gray-800 hover:border-red-500/25 transition-all h-7 w-7 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveEditAnime} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              {/* Row 1: Title & Studio */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Show Title</label>
                  <input 
                    type="text" 
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none focus:border-red-600"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Production Studio</label>
                  <input 
                    type="text" 
                    required
                    value={editStudio}
                    onChange={(e) => setEditStudio(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none focus:border-red-600"
                  />
                </div>
              </div>

              {/* Row 2: Poster & Banner */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Poster Image URL</label>
                  <input 
                    type="text" 
                    required
                    value={editPoster}
                    onChange={(e) => setEditPoster(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs font-mono focus:ring-1 focus:ring-red-650 focus:outline-none focus:border-red-600"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Banner Background URL</label>
                  <input 
                    type="text" 
                    required
                    value={editBanner}
                    onChange={(e) => setEditBanner(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs font-mono focus:ring-1 focus:ring-red-650 focus:outline-none focus:border-red-600"
                  />
                </div>
              </div>

              {/* Row 3: Trailer URL */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Official Trailer URL (YouTube Embed/Mp4)</label>
                <input 
                  type="text" 
                  value={editTrailer}
                  onChange={(e) => setEditTrailer(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs font-mono focus:ring-1 focus:ring-red-650 focus:outline-none focus:border-red-600"
                />
              </div>

              {/* Row 4: Genres & Tags */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Genres (Comma separated)</label>
                  <input 
                    type="text" 
                    value={editGenres}
                    onChange={(e) => setEditGenres(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none focus:border-red-600"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Tags (Comma separated)</label>
                  <input 
                    type="text" 
                    value={editTags}
                    onChange={(e) => setEditTags(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none focus:border-red-600"
                  />
                </div>
              </div>

              {/* Row 5: Year & Status */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Release Year</label>
                  <input 
                    type="number" 
                    value={editYear}
                    onChange={(e) => setEditYear(e.target.value)}
                    className="w-full bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none focus:border-red-600"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Publishing Status</label>
                  <select 
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as any)}
                    className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none focus:border-red-600"
                  >
                    <option value="Ongoing">Ongoing</option>
                    <option value="Completed">Completed</option>
                    <option value="Upcoming">Upcoming</option>
                  </select>
                </div>
              </div>

              {/* Row 6: Synopsis */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Synopsis Description</label>
                <textarea 
                  rows={4}
                  required
                  value={editSynopsis}
                  onChange={(e) => setEditSynopsis(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none focus:border-red-600"
                />
              </div>

              {/* Form Buttons */}
              <div className="flex gap-3 justify-end pt-4 border-t border-gray-900">
                <button
                  type="button"
                  onClick={() => setEditingAnime(null)}
                  className="px-5 py-2 text-xs font-semibold bg-gray-900 border border-gray-800 hover:bg-gray-800 rounded-lg text-gray-300 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold bg-red-600 hover:bg-red-700 rounded-lg text-white transition-all shadow-lg shadow-red-600/20"
                >
                  Save Modifications
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Dynamic Floating Toast Feedback */}
      {saveFeedback && (
        <div className="fixed top-5 right-5 bg-gradient-to-r from-red-600 to-rose-700 text-white font-semibold text-xs px-5 py-3 rounded-lg shadow-2xl z-55 flex items-center gap-2 border border-red-500 animate-bounce">
          <CheckCircle className="h-4 w-4" /> {saveFeedback}
        </div>
      )}

      {/* Admin Sidebar Navigation */}
      <div className="w-64 bg-gray-950 border-r border-gray-900 flex flex-col justify-between p-4 flex-shrink-0">
        <div>
          <div className="flex items-center gap-3 mb-6 border-b border-gray-900 pb-4">
            <div className="h-9 w-9 bg-red-600 rounded-lg flex items-center justify-center font-bold text-white shadow-md shadow-red-600/30 animate-pulse">
              Ω
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-white">OTAKU UNIVERSE CMS</h1>
              <p className="text-[10px] font-mono tracking-wider font-semibold text-red-500">ULTIMATE EDITION V4</p>
            </div>
          </div>

          <nav className="flex flex-col gap-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg text-xs font-semibold tracking-wide transition-all ${
                    activeTab === item.id
                      ? 'bg-red-600 text-white shadow font-bold'
                      : 'text-gray-400 hover:bg-gray-900 hover:text-white'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* User Identity and exit triggers */}
        <div className="border-t border-gray-900 pt-4 flex flex-col gap-3">
          <div className="flex items-center gap-2.5 px-2">
            <img 
              src={currentUser?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&q=80"} 
              alt={currentUser?.name || "user"} 
              className="h-8 w-8 rounded-full border border-red-500/30 object-cover" 
            />
            <div className="truncate">
              <h5 className="text-xs font-bold text-gray-200 truncate">{currentUser?.name || "Unknown User"}</h5>
              <p className="text-[10px] font-mono text-red-500">{currentUser?.role || "User"} (Active)</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-full text-center py-2 bg-gray-900 hover:bg-red-600/10 hover:text-red-500 border border-gray-800 hover:border-red-600/20 rounded-lg text-xs font-bold transition-all"
          >
            Go to Website Live
          </button>
        </div>
      </div>

      {/* Main Panel Content Frame */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Top bar header */}
        <header className="h-14 bg-gray-950 border-b border-gray-900 flex items-center justify-between px-6 flex-shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-xs font-bold tracking-wider text-gray-400 uppercase">
              Dashboard / <span className="text-white">{menuItems.find(m => m.id === activeTab)?.label}</span>
            </span>
          </div>

          <div className="flex items-center gap-4">
            {/* Server Connection status hubs */}
            <div className="flex items-center gap-2 bg-gray-900 px-3 py-1.5 rounded-lg border border-gray-800 text-[10px] font-mono">
              <span className="text-gray-400">Node Cluster:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping inline-block" /> ONLINE
              </span>
            </div>

            <button 
              onClick={onClose}
              className="text-xs font-bold bg-red-600 text-white px-3.5 py-1.5 rounded hover:bg-red-700 transition-all flex items-center gap-1.5"
            >
              Close Panel
            </button>
          </div>
        </header>

        {/* Panel Scrolling Viewport */}
        <main className="flex-1 overflow-y-auto p-6 bg-gray-950/40">
          
          {/* TAB 1: ANIME CATALOG MANAGER & LIVE CHANNELS */}
          {activeTab === 'manager' && (
            <div className="space-y-6">
              {/* Stat grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-4.5">
                  <span className="text-[10px] tracking-wider text-gray-500 font-bold uppercase block mb-1">Total Shows</span>
                  <div className="text-2xl font-black text-white">{animeList.length}</div>
                  <p className="text-[10px] text-gray-400 mt-1 font-mono">Episodes: {episodesList.length} total rows</p>
                </div>
                <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-4.5">
                  <span className="text-[10px] tracking-wider text-gray-500 font-bold uppercase block mb-1">Ecosystem Views</span>
                  <div className="text-2xl font-black text-white">
                    {animeList.reduce((acc, current) => acc + current.views, 0).toLocaleString()}
                  </div>
                  <p className="text-[10px] text-emerald-400 mt-1">▲ 12.4% vs last week</p>
                </div>
                <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-4.5">
                  <span className="text-[10px] tracking-wider text-gray-500 font-bold uppercase block mb-1">Active Subscribers</span>
                  <div className="text-2xl font-black text-white">{usersList.length}</div>
                  <p className="text-[10px] text-gray-400 mt-1 font-mono">Ad revenue: $1,450.40</p>
                </div>
                <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-4.5">
                  <span className="text-[10px] tracking-wider text-gray-500 font-bold uppercase block mb-1">Live OTT Events</span>
                  <div className="text-2xl font-black text-white">{realtimeEvents.length}</div>
                  <p className="text-[10px] text-red-400 mt-1 animate-pulse">🔴 Logging in realtime</p>
                </div>
              </div>

              {/* Grid: 2 columns */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Anime Shows table list */}
                <div className="col-span-2 bg-gray-950/80 border border-gray-800 rounded-xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <FilmIcon className="h-4.5 w-4.5 text-red-500" /> Active Video Vault Catalog
                    </h3>
                    <button 
                      onClick={() => setActiveTab('upload')}
                      className="text-xs bg-red-600/10 hover:bg-red-600 text-red-400 hover:text-white border border-red-500/20 px-2.5 py-1 rounded transition-colors"
                    >
                      + Super Upload
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-gray-300">
                      <thead className="bg-gray-950 text-gray-500 border-b border-gray-900">
                        <tr>
                          <th className="py-2.5 px-3 font-semibold">Poster</th>
                          <th className="py-2.5 px-3 font-semibold">Title</th>
                          <th className="py-2.5 px-3 font-semibold">Studio/Year</th>
                          <th className="py-2.5 px-3 font-semibold">Views/Rating</th>
                          <th className="py-2.5 px-3 font-semibold text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-900">
                        {animeList.map((anime) => (
                          <tr key={anime.id} className="hover:bg-gray-900/40 transition-colors">
                            <td className="py-2.5 px-3">
                              <img src={anime.poster} alt="" className="h-10 w-7.5 object-cover rounded" />
                            </td>
                            <td className="py-2.5 px-3 font-bold text-white">
                              <div>{anime.name}</div>
                              <span className="text-[10px] text-gray-500">{anime.status}</span>
                            </td>
                            <td className="py-2.5 px-3">
                              <div>{anime.studio}</div>
                              <span className="text-[10px] text-gray-500">{anime.year}</span>
                            </td>
                            <td className="py-2.5 px-3 font-mono">
                              <div>{anime.views.toLocaleString()}</div>
                              <span className="text-yellow-500 text-[10px]">★ {anime.rating}</span>
                            </td>
                            <td className="py-2.5 px-3 text-right whitespace-nowrap">
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  onClick={() => startEditingAnime(anime)}
                                  className="text-gray-400 hover:text-red-500 p-1.5 transition-colors bg-gray-900 border border-gray-800 rounded hover:border-red-500/30"
                                  title="Edit Anime Catalog"
                                >
                                  <Edit className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => {
                                    if (window.confirm(`Delete this anime show "${anime.name}" and all mapped seasonal episodes?`)) {
                                      const filtered = animeList.filter(a => a.id !== anime.id);
                                      onUpdateAnimeList(filtered);
                                      onAddRealtimeEvent({
                                        id: 'evt-' + Date.now(),
                                        eventName: 'anime_deleted',
                                        timestamp: 'Now',
                                        description: `Anime show "${anime.name}" purged from catalog folder.`,
                                        status: 'warn'
                                      });
                                    }
                                  }}
                                  className="text-gray-500 hover:text-red-500 p-1.5 transition-colors bg-gray-900 border border-gray-800 rounded hover:border-red-500/20"
                                  title="Purge Movie"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Real-time Logger Events Widget */}
                <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-5 flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-3">
                      <Activity className="h-4.5 w-4.5 text-rose-500 animate-pulse" /> Realtime Manager Events
                    </h3>
                    <p className="text-[10px] text-gray-500 font-medium mb-4">
                      Active push notifications, uploading triggers, backends logs.
                    </p>

                    <div className="space-y-3 max-h-[320px] overflow-y-auto pr-1">
                      {realtimeEvents.map((evt) => (
                        <div key={evt.id} className="p-3 bg-gray-950 border border-gray-900 rounded-lg text-xs space-y-1">
                          <div className="flex justify-between items-center">
                            <span className="font-mono text-red-500 font-semibold">{evt.eventName}</span>
                            <span className="text-gray-500 font-mono text-[9px]">{evt.timestamp}</span>
                          </div>
                          <p className="text-gray-400 font-medium text-[11px] leading-tight">{evt.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Manual Broadcast controls */}
                  <div className="border-t border-gray-900 pt-4 mt-4 space-y-2.5">
                    <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Quick Notification Broadcaster</span>
                    <input 
                      type="text" 
                      placeholder="Title of broadcast..." 
                      value={notifyTitle}
                      onChange={(e) => setNotifyTitle(e.target.value)}
                      className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs focus:ring-0 focus:border-red-600 focus:outline-none"
                    />
                    <textarea 
                      placeholder="Type details content..." 
                      rows={2}
                      value={notifyBody}
                      onChange={(e) => setNotifyBody(e.target.value)}
                      className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs focus:ring-0 focus:border-red-600 focus:outline-none"
                    />
                    <div className="flex items-center justify-between text-[10px] text-gray-400 font-medium">
                      <label className="flex items-center gap-1">
                        <input 
                          type="checkbox" 
                          checked={notifyChannels.web}
                          onChange={(e) => setNotifyChannels({ ...notifyChannels, web: e.target.checked })}
                          className="rounded text-red-600 focus:ring-0" 
                        /> Push
                      </label>
                      <label className="flex items-center gap-1">
                        <input 
                          type="checkbox" 
                          checked={notifyChannels.email}
                          onChange={(e) => setNotifyChannels({ ...notifyChannels, email: e.target.checked })}
                          className="rounded text-red-600 focus:ring-0" 
                        /> Em
                      </label>
                      <label className="flex items-center gap-1">
                        <input 
                          type="checkbox" 
                          checked={notifyChannels.telegram}
                          onChange={(e) => setNotifyChannels({ ...notifyChannels, telegram: e.target.checked })}
                          className="rounded text-red-600 focus:ring-0" 
                        /> Tele
                      </label>
                      <button 
                        onClick={handleDispatchNotification}
                        className="bg-red-600 text-white font-semibold px-2.5 py-1 rounded text-[10px] hover:bg-red-700 transition"
                      >
                        Send Auto Notification
                      </button>
                    </div>
                    {notificationStatus}
                  </div>

                </div>

              </div>
            </div>
          )}

          {/* TAB 2: SUPER UPLOADER SYSTEM & COMPILER */}
          {activeTab === 'upload' && (
            <div className="space-y-6">
              
              {/* Auto Group Info */}
              <div className="bg-gradient-to-r from-red-600/10 to-rose-700/10 border border-red-500/20 rounded-xl p-5 text-xs flex gap-4">
                <div className="text-red-500 mt-0.5">
                  <AlertTriangle className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white mb-0.5">Automated Grouping Indexers</h4>
                  <p className="text-gray-400 font-medium leading-relaxed">
                    Under the V4 Ultimate architecture, our Super Upload Engine reads target structures {"like Naruto -> Season 1 -> Episode 1"} and sorts them automatically. No tedious manual database query indexing is needed!
                  </p>
                </div>
              </div>

              {/* Two Column layouts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Column A: Create a brand new Anime catalog */}
                <form onSubmit={handleSuperUpload} className="bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4">
                  <h3 className="text-sm font-bold text-white border-b border-gray-900 pb-3">
                    🚀 Single-Screen Anime & Multi-Ep Builder
                  </h3>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Anime Name *</label>
                      <input 
                        type="text" 
                        required
                        placeholder="e.g. Demon Slayer" 
                        value={upName}
                        onChange={(e) => setUpName(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none placeholder-gray-600"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Alternative Names</label>
                      <input 
                        type="text" 
                        placeholder="Separate with commas" 
                        value={upAltName}
                        onChange={(e) => setUpAltName(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none placeholder-gray-600"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Poster URL</label>
                      <input 
                        type="text" 
                        value={upPoster}
                        onChange={(e) => setUpPoster(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Banner URL</label>
                      <input 
                        type="text" 
                        value={upBanner}
                        onChange={(e) => setUpBanner(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Trailer Embed URL</label>
                      <input 
                        type="text" 
                        value={upTrailer}
                        onChange={(e) => setUpTrailer(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Studio</label>
                      <input 
                        type="text" 
                        value={upStudio}
                        onChange={(e) => setUpStudio(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Status</label>
                      <select 
                        value={upStatus}
                        onChange={(e) => setUpStatus(e.target.value as any)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none"
                      >
                        <option value="Ongoing">Ongoing</option>
                        <option value="Completed">Completed</option>
                        <option value="Upcoming">Upcoming</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase">Synopsis *</label>
                    <textarea 
                      required
                      placeholder="Brief overview description of the anime story..."
                      rows={3}
                      value={upSynopsis}
                      onChange={(e) => setUpSynopsis(e.target.value)}
                      className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none placeholder-gray-600"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase">Target Stream Language Track *</label>
                    <select
                      value={upLanguage}
                      onChange={(e) => setUpLanguage(e.target.value as any)}
                      className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none text-white font-semibold"
                    >
                      <option value="Japanese">Japanese Audio Track (Original)</option>
                      <option value="English">English Audio Track (Dub)</option>
                      <option value="Hindi">Hindi Audio Track (Dub)</option>
                      <option value="Bangla">Bangla Audio Track (Dub)</option>
                    </select>
                  </div>

                  {/* Dynamic Episode Rows Builder */}
                  <div className="border border-gray-900 rounded-lg p-3 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-gray-400 uppercase">Season 1: Mapped Episode Rows</span>
                      <button
                        type="button"
                        onClick={() => {
                          const nextNum = episodeRows.length + 1;
                          setEpisodeRows([...episodeRows, { number: nextNum, name: `Episode ${nextNum}: Title`, url: 'https://www.w3schools.com/html/mov_bbb.mp4', duration: 24 }]);
                        }}
                        className="text-[10px] bg-red-600/20 text-red-400 px-2.5 py-1 rounded hover:bg-red-600 hover:text-white transition-all font-semibold"
                      >
                        + Add Episode Row
                      </button>
                    </div>

                    <div className="space-y-2 max-h-[140px] overflow-y-auto pr-1">
                      {episodeRows.map((row, index) => (
                        <div key={index} className="flex gap-2 items-center">
                          <input 
                            type="number" 
                            placeholder="Ep" 
                            className="w-12 bg-gray-950 border border-gray-800 rounded p-1 text-center text-xs" 
                            value={row.number}
                            onChange={(e) => {
                              const updated = [...episodeRows];
                              updated[index].number = parseInt(e.target.value) || index + 1;
                              setEpisodeRows(updated);
                            }}
                          />
                          <input 
                            type="text" 
                            placeholder="Name..." 
                            className="flex-1 bg-gray-950 border border-gray-800 rounded p-1 text-xs" 
                            value={row.name}
                            onChange={(e) => {
                              const updated = [...episodeRows];
                              updated[index].name = e.target.value;
                              setEpisodeRows(updated);
                            }}
                          />
                          <input 
                            type="text" 
                            placeholder="Direct MP4 or Google Drive Link..." 
                            className="flex-1 bg-gray-950 border border-gray-800 rounded p-1 text-xs font-mono" 
                            value={row.url}
                            onChange={(e) => {
                              const updated = [...episodeRows];
                              updated[index].url = e.target.value;
                              setEpisodeRows(updated);
                            }}
                          />
                          <button
                            type="button"
                            onClick={() => {
                              if (episodeRows.length <= 1) return;
                              setEpisodeRows(episodeRows.filter((_, idx) => idx !== index));
                            }}
                            className="text-gray-500 hover:text-red-500 p-1"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-2.5 bg-red-600 text-white hover:bg-red-700 transition font-bold text-xs rounded-lg shadow-lg flex items-center justify-center gap-2"
                  >
                    <Save className="h-4 w-4" /> Save Mapped Catalogs & Build Seasons
                  </button>
                </form>

                {/* Column B: Append single episode to existing show */}
                <form onSubmit={handleSingleEpisodeUpload} className="bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4 h-fit">
                  <h3 className="text-sm font-bold text-white border-b border-gray-900 pb-3">
                    📺 Append Single Episode to Exist Catalog
                  </h3>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase">Select Target Anime</label>
                    <select
                      value={selAnimeId}
                      onChange={(e) => setSelAnimeId(e.target.value)}
                      className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none"
                    >
                      {animeList.map(a => (
                        <option key={a.id} value={a.id}>{a.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase">Episode Audio Language Track *</label>
                    <select
                      value={singleEpLanguage}
                      onChange={(e) => setSingleEpLanguage(e.target.value as any)}
                      className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 focus:border-red-600 focus:outline-none font-bold text-red-400 bg-gray-950"
                    >
                      <option value="Japanese">Japanese Audio Track (Original)</option>
                      <option value="English">English Audio Track (Dub)</option>
                      <option value="Hindi">Hindi Audio Track (Dub)</option>
                      <option value="Bangla">Bangla Audio Track (Dub)</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Season Index (e.g. 1, 2)</label>
                      <input 
                        type="number" 
                        min="1"
                        required
                        value={selSeasonNumber}
                        onChange={(e) => setSelSeasonNumber(parseInt(e.target.value) || 1)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Episode Number (e.g. 21)</label>
                      <input 
                        type="number" 
                        min="1"
                        required
                        value={singleEpNumber}
                        placeholder="e.g. 21"
                        onChange={(e) => setSingleEpNumber(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 placeholder-gray-600"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase">Episode Name</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Flame Hashira Strikes Out" 
                      value={singleEpName}
                      onChange={(e) => setSingleEpName(e.target.value)}
                      className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 placeholder-gray-600"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="col-span-2 space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Video URL (Google Drive/Mp4 Direct)</label>
                      <input 
                        type="text" 
                        value={singleEpMediaUrl}
                        onChange={(e) => setSingleEpMediaUrl(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Duration (mins)</label>
                      <input 
                        type="number" 
                        value={singleEpDuration}
                        onChange={(e) => setSingleEpDuration(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs"
                      />
                    </div>
                  </div>

                  {/* Alternative Streaming Links */}
                  <div className="border border-gray-900 rounded-lg p-3 space-y-3 bg-gray-950/20 text-left">
                    <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                      Alternative Streaming Servers (TeraBox, Cloudinary, GDrive)
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-gray-505 uppercase">Google Drive Embed/Preview Link</label>
                        <input 
                          type="text" 
                          placeholder="https://drive.google.com/..."
                          value={singleEpGdriveUrl}
                          onChange={(e) => setSingleEpGdriveUrl(e.target.value)}
                          className="w-full bg-gray-950 border border-gray-805 rounded p-1.5 text-xs text-gray-300 font-mono placeholder-gray-700"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-gray-505 uppercase">TeraBox Embed/Streaming Link</label>
                        <input 
                          type="text" 
                          placeholder="https://terabox.com/..."
                          value={singleEpTeraboxUrl}
                          onChange={(e) => setSingleEpTeraboxUrl(e.target.value)}
                          className="w-full bg-gray-950 border border-gray-805 rounded p-1.5 text-xs text-gray-300 font-mono placeholder-gray-700"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-gray-505 uppercase">Cloudinary Direct Stream Link</label>
                        <input 
                          type="text" 
                          placeholder="https://res.cloudinary.com/..."
                          value={singleEpCloudinaryUrl}
                          onChange={(e) => setSingleEpCloudinaryUrl(e.target.value)}
                          className="w-full bg-gray-950 border border-gray-805 rounded p-1.5 text-xs text-gray-300 font-mono placeholder-gray-700"
                        />
                      </div>
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-2 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 text-white font-bold text-xs rounded transition shadow flex items-center justify-center gap-1.5"
                  >
                    <Plus className="h-4 w-4" /> Append Mapped Episode
                  </button>
                </form>

              </div>
            </div>
          )}

          {/* TAB 3: GLOBAL CONNECTIONS HUB & SERVICE MANAGER */}
          {activeTab === 'connections' && (
            <div className="space-y-6">
              
              {/* Dynamic Setup Title */}
              <div className="bg-gray-950 border border-gray-800 rounded-xl p-5">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-900 pb-4 mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider">🔗 Global Service Connection Hub</h3>
                    <p className="text-xs text-gray-400 mt-1 font-medium">Configure unified connection sockets, databases, clouds, servers and trackers.</p>
                  </div>
                  <button 
                    onClick={saveGlobalConnections}
                    className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs px-4 py-2.5 rounded-lg flex items-center gap-1.5 shadow-md"
                  >
                    <Save className="h-4 w-4" /> Save Global Configuration
                  </button>
                </div>

                {/* Dashboard layout widgets representing connection statuses */}
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-6">
                  {[
                    { name: 'Website Core', status: 'connected', label: 'https://otaku.co' },
                    { name: 'MongoDB', status: connectionStates.mongoStatus, label: 'Cluster0' },
                    { name: 'Socket Express', status: connectionStates.socketStatus, label: 'Port 3000' },
                    { name: 'SMTP Mailer', status: connectionStates.smtpStatus, label: 'Gmail SMTP' },
                    { name: 'Telegram Bot', status: connectionStates.telegramStatus, label: '@OtakuBot' },
                    { name: 'Cloud Storage', status: connectionStates.storageStatus, label: 'Cloudinary' },
                    { name: 'Authentication', status: connectionStates.firebaseStatus, label: 'Firebase / Admin' }
                  ].map((p, idx) => (
                    <div key={idx} className="bg-gray-950 border border-gray-900 rounded-lg p-3 text-center space-y-1">
                      <span className="text-[10px] font-bold text-gray-500 uppercase tracking-tight block truncate">{p.name}</span>
                      <div className="flex items-center justify-center gap-1 text-[11px] font-bold font-mono">
                        {p.status === 'connected' ? (
                          <span className="text-emerald-400 flex items-center gap-1">🟢 Connected</span>
                        ) : p.status === 'connecting' ? (
                          <span className="text-yellow-400 flex items-center gap-1">🟡 Tuning...</span>
                        ) : (
                          <span className="text-red-500 flex items-center gap-1">🔴 Faulted</span>
                        )}
                      </div>
                      <span className="text-[9px] text-gray-500 block truncate font-mono">{p.label}</span>
                    </div>
                  ))}
                </div>

                {/* Forms grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Part A */}
                  <div className="space-y-4 border-r border-gray-900 pr-0 md:pr-6">
                    
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Website Landing URL</label>
                      <input 
                        type="text" 
                        value={connectionStates.websiteUrl}
                        onChange={(e) => setConnectionStates({ ...connectionStates, websiteUrl: e.target.value })}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs font-mono text-gray-300"
                      />
                    </div>

                    <div className="p-4 bg-gray-950 border border-gray-950 rounded-lg space-y-3">
                      <div className="flex items-center justify-between border-b border-gray-900 pb-2">
                        <span className="text-xs font-bold text-white flex items-center gap-1.5">
                          <span className="h-2 w-2 rounded-full bg-green-500" /> MongoDB Atlas URI
                        </span>
                        <div className="flex gap-2">
                          <button 
                            type="button" 
                            disabled={isTestingConn === 'mongodb'}
                            onClick={() => runTestConnection('mongodb', connectionStates.mongoUri)}
                            className="text-[10px] bg-gray-950 hover:bg-gray-900 border border-gray-800 font-semibold px-2.5 py-1 rounded"
                          >
                            {isTestingConn === 'mongodb' ? 'Testing...' : 'Test Connection'}
                          </button>
                        </div>
                      </div>
                      <input 
                        type="password" 
                        value={connectionStates.mongoUri}
                        onChange={(e) => setConnectionStates({ ...connectionStates, mongoUri: e.target.value })}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs font-mono text-gray-300 focus:outline-none"
                      />
                    </div>

                    <div className="p-4 bg-gray-950 border border-gray-950 rounded-lg space-y-3">
                      <div className="flex items-center justify-between border-b border-gray-900 pb-2">
                        <span className="text-xs font-bold text-white">🔥 Firebase Integrations SDK Config</span>
                        <button 
                          type="button"
                          disabled={isTestingConn === 'firebase'}
                          onClick={() => runTestConnection('firebase', connectionStates.firebaseConfig.apiKey)}
                          className="text-[10px] bg-gray-950 hover:bg-gray-900 border border-gray-800 px-2.5 py-1 rounded font-semibold"
                        >
                          {isTestingConn === 'firebase' ? 'Testing...' : 'Test Handshake'}
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-left">
                        <div className="space-y-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">Project ID</span>
                          <input 
                            type="text" 
                            value={connectionStates.firebaseConfig.projectId}
                            onChange={(e) => setConnectionStates({ ...connectionStates, firebaseConfig: { ...connectionStates.firebaseConfig, projectId: e.target.value } })}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs font-mono text-gray-300"
                          />
                        </div>
                        <div className="space-y-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">API Key</span>
                          <input 
                            type="password" 
                            value={connectionStates.firebaseConfig.apiKey}
                            onChange={(e) => setConnectionStates({ ...connectionStates, firebaseConfig: { ...connectionStates.firebaseConfig, apiKey: e.target.value } })}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs font-mono text-gray-300"
                          />
                        </div>
                      </div>
                    </div>

                  </div>

                  {/* Part B */}
                  <div className="space-y-4">
                    
                    <div className="p-4 bg-gray-950 border border-gray-950 rounded-lg space-y-3">
                      <div className="flex items-center justify-between border-b border-gray-900 pb-2">
                        <span className="text-xs font-bold text-white">☁️ Cloudinary Container Keys</span>
                        <button 
                          type="button"
                          disabled={isTestingConn === 'cloudinary'}
                          onClick={() => runTestConnection('cloudinary', connectionStates.cloudinaryConfig.apiKey)}
                          className="text-[10px] bg-gray-950 hover:bg-gray-900 border border-gray-800 px-2.5 py-1 rounded font-semibold"
                        >
                          {isTestingConn === 'cloudinary' ? 'Verifying...' : 'Ping Cloudinary'}
                        </button>
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        <div className="space-y-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">Cloud Name</span>
                          <input 
                            type="text" 
                            value={connectionStates.cloudinaryConfig.cloudName}
                            onChange={(e) => setConnectionStates({ ...connectionStates, cloudinaryConfig: { ...connectionStates.cloudinaryConfig, cloudName: e.target.value } })}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-gray-300 truncate"
                          />
                        </div>
                        <div className="space-y-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">API Key</span>
                          <input 
                            type="text" 
                            value={connectionStates.cloudinaryConfig.apiKey}
                            onChange={(e) => setConnectionStates({ ...connectionStates, cloudinaryConfig: { ...connectionStates.cloudinaryConfig, apiKey: e.target.value } })}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-gray-300 truncate"
                          />
                        </div>
                        <div className="space-y-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">API Secret</span>
                          <input 
                            type="password" 
                            value={connectionStates.cloudinaryConfig.apiSecret}
                            onChange={(e) => setConnectionStates({ ...connectionStates, cloudinaryConfig: { ...connectionStates.cloudinaryConfig, apiSecret: e.target.value } })}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-gray-300"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-gray-950 border border-gray-950 rounded-lg space-y-3">
                      <div className="flex items-center justify-between border-b border-gray-900 pb-2">
                        <span className="text-xs font-bold text-white">📧 SMTP Transactional Mailer</span>
                        <button 
                          type="button"
                          disabled={isTestingConn === 'smtp'}
                          onClick={() => runTestConnection('smtp', connectionStates.smtpConfig.host)}
                          className="text-[10px] bg-gray-950 hover:bg-gray-900 border border-gray-800 px-2.5 py-1 rounded font-semibold"
                        >
                          {isTestingConn === 'smtp' ? 'Sending Dial...' : 'Test SMTP Mail'}
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-left">
                        <div className="space-y-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">Mail Username</span>
                          <input 
                            type="text" 
                            value={connectionStates.smtpConfig.user}
                            onChange={(e) => setConnectionStates({ ...connectionStates, smtpConfig: { ...connectionStates.smtpConfig, user: e.target.value } })}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-gray-300"
                          />
                        </div>
                        <div className="space-y-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">SMTP Password</span>
                          <input 
                            type="password" 
                            value={connectionStates.smtpConfig.pass}
                            onChange={(e) => setConnectionStates({ ...connectionStates, smtpConfig: { ...connectionStates.smtpConfig, pass: e.target.value } })}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-gray-300"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-gray-950 border border-gray-950 rounded-lg space-y-3">
                      <div className="flex items-center justify-between border-b border-gray-900 pb-2">
                        <span className="text-xs font-bold text-white">🤖 Telegram Auto Updates Bot</span>
                        <button 
                          type="button"
                          disabled={isTestingConn === 'telegram'}
                          onClick={() => runTestConnection('telegram', connectionStates.telegramConfig.botToken)}
                          className="text-[10px] bg-gray-950 hover:bg-gray-900 border border-gray-800 px-2.5 py-1 rounded font-semibold"
                        >
                          {isTestingConn === 'telegram' ? 'Calling Bot...' : 'Bot Handshake'}
                        </button>
                      </div>
                      <div className="space-y-1 text-left">
                        <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">Telegram Token API</span>
                        <input 
                          type="password" 
                          value={connectionStates.telegramConfig.botToken}
                          onChange={(e) => setConnectionStates({ ...connectionStates, telegramConfig: { ...connectionStates.telegramConfig, botToken: e.target.value } })}
                          className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs font-mono text-gray-300"
                        />
                      </div>
                    </div>

                    {/* Discord Webhooks & Analytics Tracking */}
                    <div className="p-4 bg-gray-950 border border-gray-900 rounded-lg space-y-3">
                      <div className="flex items-center justify-between border-b border-gray-900 pb-2">
                        <span className="text-xs font-bold text-white flex items-center gap-1.5">🎮 Discord & Marketing Analytics</span>
                        <label className="inline-flex items-center gap-1.5 text-xs text-gray-400 hover:text-white cursor-pointer select-none">
                          <input 
                            type="checkbox"
                            checked={!!connectionStates.discordWebhookEnabled}
                            onChange={(e) => setConnectionStates({ ...connectionStates, discordWebhookEnabled: e.target.checked })}
                            className="rounded border-gray-800 text-red-600 bg-gray-900 h-3.5 w-3.5"
                          />
                          Bot Announcer Enabled
                        </label>
                      </div>
                      <div className="space-y-1 text-left">
                        <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">Discord Webhook URL</span>
                        <input 
                          type="text" 
                          placeholder="e.g. https://discord.com/api/webhooks/..."
                          value={connectionStates.discordWebhookUrl || ''}
                          onChange={(e) => setConnectionStates({ ...connectionStates, discordWebhookUrl: e.target.value })}
                          className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs font-mono text-gray-300 placeholder-gray-700"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-left">
                        <div className="space-y-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">Google Analytics ID</span>
                          <input 
                            type="text" 
                            placeholder="e.g. G-7F982X9CDY"
                            value={connectionStates.googleAnalyticsId || ''}
                            onChange={(e) => setConnectionStates({ ...connectionStates, googleAnalyticsId: e.target.value })}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs font-mono text-gray-300 placeholder-gray-700"
                          />
                        </div>
                        <div className="space-y-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-gray-500 font-bold">AdSense Publisher ID</span>
                          <input 
                            type="text" 
                            placeholder="e.g. pub-892015849"
                            value={connectionStates.adsensePublisherId || ''}
                            onChange={(e) => setConnectionStates({ ...connectionStates, adsensePublisherId: e.target.value })}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs font-mono text-gray-300 placeholder-gray-700"
                          />
                        </div>
                      </div>
                    </div>

                  </div>

                </div>

              </div>

            </div>
          )}
           {activeTab === 'ads' && (
            <div className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-gray-950 border border-gray-900 rounded-lg p-3.5 flex flex-col justify-between text-left">
                  <div>
                    <span className="text-[10px] text-gray-500 uppercase font-bold block mb-1">Ad Impressions & Clicks</span>
                    <div className="text-xl font-bold text-white">{totalImpressions.toLocaleString()} <span className="text-xs text-gray-400 font-normal">imps</span></div>
                    <p className="text-[10px] text-gray-400 mt-1 font-medium">{totalClicks.toLocaleString()} total clicks recorded</p>
                  </div>
                  <button 
                    onClick={handleResetAdStats}
                    className="mt-2 text-[9px] bg-amber-500/10 border border-amber-500/20 hover:bg-amber-600 text-amber-400 hover:text-black px-2 py-1 rounded flex items-center justify-center gap-1 font-extrabold w-28 transition-all hover:scale-102 cursor-pointer"
                  >
                    <RefreshCw className="h-2.5 w-2.5" /> Reset Ads
                  </button>
                </div>
                <div className="bg-gray-950 border border-gray-900 rounded-lg p-3.5 text-left">
                  <span className="text-[10px] text-gray-500 uppercase font-bold block mb-1">Average Performance CTR</span>
                  <div className="text-xl font-bold text-red-500">
                    {totalImpressions > 0 ? ((totalClicks / totalImpressions) * 100).toFixed(2) + " %" : "0.00 %"}
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1 font-medium">Click-through performance ratio</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 rounded-lg p-3.5 flex flex-col justify-between text-left">
                  <div>
                    <span className="text-[10px] text-gray-500 uppercase font-bold block">Current Platform Revenue</span>
                    <div className="text-xl font-bold text-emerald-400 font-mono mt-0.5">${realRevenue.toFixed(2)} USD</div>
                  </div>
                  <button 
                    onClick={handleResetRevenue}
                    className="mt-2 text-[9px] bg-red-655/10 border border-red-500/25 hover:bg-red-600 text-red-400 hover:text-white px-2 py-1 rounded flex items-center justify-center gap-1 font-extrabold w-28 transition-all hover:scale-102 cursor-pointer"
                  >
                    <RefreshCw className="h-2.5 w-2.5" /> Reset Balance
                  </button>
                </div>
                <div className="bg-gray-950 border border-gray-900 rounded-lg p-3.5 flex flex-col justify-between text-left">
                  <div>
                    <span className="text-[10px] text-gray-500 uppercase font-bold block mb-1">Total Web Stream Traffic</span>
                    <div className="text-xl font-bold text-sky-400">{totalVideoViews.toLocaleString()} <span className="text-xs text-gray-500 font-normal">streams</span></div>
                    <p className="text-[10px] text-gray-400 mt-1 font-medium">Automatic monetization: $1.80/CPM</p>
                  </div>
                  <button 
                    onClick={handleResetAllViews}
                    className="mt-2 text-[9px] bg-sky-500/10 border border-sky-500/20 hover:bg-sky-600 text-sky-400 hover:text-black px-2 py-1 rounded flex items-center justify-center gap-1 font-extrabold w-28 transition-all hover:scale-102 cursor-pointer"
                  >
                    <RefreshCw className="h-2.5 w-2.5" /> Reset Views
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Create smart advertising */}
                <form onSubmit={handleAddNewAd} className="bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4 h-fit">
                  <h3 className="text-sm font-bold text-white border-b border-gray-900 pb-3 flex items-center gap-1.5">
                    <Radio className="h-4.5 w-4.5 text-red-500" /> New Smart Direct Link Campaign
                  </h3>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase">Ad Group Title *</label>
                    <input 
                      type="text" 
                      id="adTitle"
                      required
                      placeholder="e.g. 50% discount on Aniplex toys" 
                      className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 placeholder-gray-600"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Banner Image URL</label>
                      <input 
                        type="text" 
                        id="adImage"
                        placeholder="https://images.unsplash..."
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0 placeholder-gray-600"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Placements type</label>
                      <select 
                        id="adType"
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0"
                      >
                        <option value="banner-top">Homepage Banner Top</option>
                        <option value="banner-sidebar">Anime Detail Sidebar Banner</option>
                        <option value="banner-footer">Global Footer banner</option>
                        <option value="overlay">Cinematic Video Player Overlay</option>
                        <option value="pre-roll">Player Pre-roll Video Ad</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase">Destination Redirect Link URL *</label>
                    <input 
                      type="text" 
                      id="adLink"
                      required
                      placeholder="https://sponsor-retailer.com" 
                      className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs text-red-400 font-mono focus:ring-0 placeholder-gray-600"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Geo Country Targeting</label>
                      <select 
                        id="adCountry"
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0"
                      >
                        <option value="All">Global Targeted (All)</option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="India">India</option>
                        <option value="USA">United States</option>
                        <option value="Japan">Japan</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Popup Delays</label>
                      <select 
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-0"
                      >
                        <option value="immediate">Show immediately</option>
                        <option value="10s">Show after 10 seconds</option>
                        <option value="daily">Show once per day</option>
                      </select>
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-2 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 font-bold text-xs text-white rounded transition shadow-md flex items-center justify-center gap-1.5"
                  >
                    <Plus className="h-4 w-4" /> Deploy Advertisement Banner
                  </button>
                </form>

                {/* Ads list and telemetry */}
                <div className="col-span-2 bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4">
                  <h3 className="text-sm font-bold text-white border-b border-gray-900 pb-3">
                    📢 Running Campaigns Indexers
                  </h3>

                  <div className="space-y-3">
                    {adCampaigns.map((ad) => (
                      <div key={ad.id} className="p-4 bg-gray-950 border border-gray-900 rounded-xl flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <span className={`text-[9px] uppercase tracking-wider font-extrabold px-1.5 py-0.5 rounded ${
                            ad.type.startsWith('banner-') ? 'bg-sky-500/10 text-sky-400 border border-sky-500/10' : 'bg-rose-500/10 text-rose-400 border border-rose-500/10'
                          }`}>
                            {ad.type}
                          </span>
                          <div>
                            <h4 className="text-xs font-bold text-white">{ad.title}</h4>
                            <p className="text-[10px] text-gray-400 font-semibold truncate max-w-sm">Redirects: <span className="font-mono text-red-500 font-medium">{ad.ctaLink}</span></p>
                            <span className="text-[9px] text-gray-500 font-medium">Target: {ad.targetCountry}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="text-right text-[10px] font-mono leading-tight">
                            <span className="text-gray-400">Clicks: <strong>{ad.clicks.toLocaleString()}</strong></span>
                            <br/>
                            <span className="text-gray-500">Impressions: {ad.impressions.toLocaleString()}</span>
                          </div>

                          <button
                            onClick={() => {
                              const updated = adCampaigns.map(a => a.id === ad.id ? { ...a, enabled: !a.enabled } : a);
                              onUpdateAdCampaigns(updated);
                              triggerNotificationBanner(`Campaign toggled: ${ad.title}`);
                            }}
                            className={`p-1 rounded text-xs px-2.5 font-bold ${ad.enabled ? 'bg-green-600/10 text-emerald-400' : 'bg-gray-900 text-gray-400'}`}
                          >
                            {ad.enabled ? 'Active 🟢' : 'Paused 🔴'}
                          </button>

                          <button
                            onClick={() => {
                              if (window.confirm(`Are you sure you want to delete the ad campaign "${ad.title}"?`)) {
                                const updated = adCampaigns.filter(a => a.id !== ad.id);
                                onUpdateAdCampaigns(updated);
                                triggerNotificationBanner(`Campaign deleted: ${ad.title}`);
                              }
                            }}
                            className="p-1.5 rounded bg-red-600/15 hover:bg-red-600/25 text-red-400 hover:text-red-300 transition-colors"
                            title="Delete Campaign"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* TAB 5: LANGUAGE TRANSLATION MANAGER */}
          {activeTab === 'languages' && (
            <div className="space-y-6">
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Left Side: Language catalog list */}
                <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4 h-fit">
                  <h3 className="text-sm font-bold text-white border-b border-gray-900 pb-3 flex items-center gap-1.5">
                    <Globe className="h-4.5 w-4.5 text-red-500" /> Supported Languages Hub
                  </h3>

                  <div className="space-y-2">
                    {languagesList.map((lang) => (
                      <div key={lang.code} className="p-3 bg-gray-950 border border-gray-900 rounded-lg flex items-center justify-between gap-3 text-xs">
                        <div>
                          <span className="font-bold text-white">{lang.name}</span>
                          <span className="text-[10px] font-mono text-gray-500 ml-1.5">[{lang.code.toUpperCase()}]</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleSetDefaultLanguage(lang.code)}
                            className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${lang.isDefault ? 'bg-red-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-800'}`}
                          >
                            {lang.isDefault ? 'Default 🌟' : 'Set Default'}
                          </button>
                          
                          {!lang.isDefault && (
                            <button
                              onClick={() => handleRemoveLanguage(lang.code)}
                              className="text-gray-500 hover:text-red-500 p-1"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Add Language Form */}
                  <div className="border-t border-gray-900 pt-4 space-y-3">
                    <span className="text-[10px] font-bold text-gray-500 uppercase block">Add Custom Dynamic Translations locale</span>
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        placeholder="code (e.g. bn)" 
                        value={newLangCode}
                        onChange={(e) => setNewLangCode(e.target.value)}
                        className="w-1/3 bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-center text-gray-200"
                      />
                      <input 
                        type="text" 
                        placeholder="Language Label (e.g. বাংলা)" 
                        value={newLangName}
                        onChange={(e) => setNewLangName(e.target.value)}
                        className="flex-1 bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-gray-200"
                      />
                      <button 
                        onClick={handleAddLanguage}
                        className="bg-red-600 hover:bg-red-700 text-white font-bold p-1.5 rounded transition"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right Side: Translation mappings editor */}
                <div className="col-span-2 bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-gray-900 pb-3">
                    <div>
                      <h3 className="text-sm font-bold text-white">📝 OTT Translation String Manager</h3>
                      <p className="text-[10px] text-gray-500 font-semibold mt-0.5">Translate website titles, grid panels and search keys in real-time!</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-400 font-medium font-semibold">Editing locale:</span>
                      <select
                        value={selectedLanguageForTx}
                        onChange={(e) => setSelectedLanguageForTx(e.target.value)}
                        className="bg-gray-950 border border-gray-805 rounded px-2.5 py-1 text-xs text-red-400 font-bold"
                      >
                        {languagesList.map(l => (
                          <option key={l.code} value={l.code}>{l.name} [{l.code.toUpperCase()}]</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[350px] overflow-y-auto pr-1">
                    {Object.keys(editedTranslations).map((key) => (
                      <div key={key} className="p-3 bg-gray-950 border border-gray-900 rounded-xl space-y-1 text-left">
                        <span className="text-[10px] font-mono font-bold text-red-500 uppercase tracking-wide block">{key}</span>
                        <input 
                          type="text" 
                          value={editedTranslations[key]}
                          onChange={(e) => {
                            setEditedTranslations({ ...editedTranslations, [key]: e.target.value });
                          }}
                          className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs text-gray-200 focus:outline-none"
                        />
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={handleSaveTranslations}
                    className="w-full py-2.5 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 text-white font-bold text-xs rounded-lg shadow-lg flex items-center justify-center gap-1.5"
                  >
                    <Save className="h-4 w-4" /> Commit Translations into Engine Dictionary
                  </button>
                </div>

              </div>
              
            </div>
          )}

          {/* TAB 6: THEME BUILDER */}
          {activeTab === 'theme' && (
            <div className="space-y-6">
              
              {/* Info of Live Customize */}
              <div className="bg-gray-950 border border-gray-800 rounded-xl p-5">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-1">🎨 Super Admin Live Brand Configurator</h3>
                <p className="text-xs text-gray-400 font-medium">Click, tweak, and save changes to theme-colors, backgrounds, fonts or header layout. Updates affect the streaming dashboard instantly!</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                
                {/* Column One: Palette colors */}
                <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-red-500 uppercase tracking-widest block border-b border-gray-900 pb-2">Theme Identity Colors</h4>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-gray-400">Primary Brand Accent</span>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={themeConfig.primaryColor}
                          onChange={(e) => saveThemeConfig('primaryColor', e.target.value)}
                          className="h-7 w-12 bg-transparent border-0 cursor-pointer"
                        />
                        <span className="font-mono text-xs text-gray-300 select-all uppercase">{themeConfig.primaryColor}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-gray-400">Secondary Accent</span>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={themeConfig.secondaryColor}
                          onChange={(e) => saveThemeConfig('secondaryColor', e.target.value)}
                          className="h-7 w-12 bg-transparent border-0 cursor-pointer"
                        />
                        <span className="font-mono text-xs text-gray-300 select-all uppercase">{themeConfig.secondaryColor}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-gray-400">Dynamic Background</span>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={themeConfig.bgColor}
                          onChange={(e) => saveThemeConfig('bgColor', e.target.value)}
                          className="h-7 w-12 bg-transparent border-0 cursor-pointer"
                        />
                        <span className="font-mono text-xs text-gray-300 select-all uppercase">{themeConfig.bgColor}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-gray-400">Dynamic Cards Canvas</span>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={themeConfig.cardBgColor}
                          onChange={(e) => saveThemeConfig('cardBgColor', e.target.value)}
                          className="h-7 w-12 bg-transparent border-0 cursor-pointer"
                        />
                        <span className="font-mono text-xs text-gray-300 select-all uppercase">{themeConfig.cardBgColor}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Column Two: typography and border profiles */}
                <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-red-500 uppercase tracking-widest block border-b border-gray-900 pb-2">Typography & Borders Setup</h4>

                  <div className="space-y-3">
                    <div className="space-y-1">
                      <span className="text-xs font-semibold text-gray-400 block">Ecosystem Font Family</span>
                      <select
                        value={themeConfig.fontFamily}
                        onChange={(e) => saveThemeConfig('fontFamily', e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-gray-300"
                      >
                        <option value="Inter">Inter (Swiss Clean UI)</option>
                        <option value="Space Grotesk">Space Grotesk (Tech-Art)</option>
                        <option value="Outfit">Outfit (Smooth Editorial)</option>
                        <option value="JetBrains Mono">JetBrains Mono (Console Geek)</option>
                        <option value="Playfair Display">Playfair Display (Serif Classic)</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <span className="text-xs font-semibold text-gray-400 block">Border Corner Radius Profile</span>
                      <select
                        value={themeConfig.borderRadius}
                        onChange={(e) => saveThemeConfig('borderRadius', e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-gray-300"
                      >
                        <option value="0px">Brutalist Sharp (0px)</option>
                        <option value="6px">Subtle Curved (6px)</option>
                        <option value="12px">Standard Cozy (12px)</option>
                        <option value="20px">Immersive Capsules (20px)</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Column Three: Header & Slider structures */}
                <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-red-500 uppercase tracking-widest block border-b border-gray-900 pb-2">Layout Visual Styles</h4>

                  <div className="space-y-3">
                    <div className="space-y-1">
                      <span className="text-xs font-semibold text-gray-400 block">Navbar Header Style</span>
                      <select
                        value={themeConfig.headerStyle}
                        onChange={(e) => saveThemeConfig('headerStyle', e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-gray-300"
                      >
                        <option value="glass">Floating Frosted Glass</option>
                        <option value="solid">Flat Slate Block (Solid)</option>
                        <option value="transparent">Minimalist Transparent Overlay</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <span className="text-xs font-semibold text-gray-400 block">Hero Poster Layout Slider</span>
                      <select
                        value={themeConfig.heroSliderLayout}
                        onChange={(e) => saveThemeConfig('heroSliderLayout', e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-1.5 text-xs text-gray-300"
                      >
                        <option value="standard">Standard Cinematic slider (Wide Banner)</option>
                        <option value="minimal">Minimal Poster Centered Slider</option>
                      </select>
                    </div>
                  </div>
                </div>

              </div>
              
            </div>
          )}

          {/* TAB 7: USER clearance & ROLE ASSIGNATION */}
          {activeTab === 'roles' && (
            <div className="space-y-6">
              
              <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-5">
                <h3 className="text-sm font-bold text-white border-b border-gray-950 pb-3 mb-4">
                  👥 Enterprise Role Clearance Manager
                </h3>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-gray-950 text-gray-500 border-b border-gray-900">
                      <tr>
                        <th className="py-2.5 px-3 font-semibold">User Avatar</th>
                        <th className="py-2.5 px-3 font-semibold">Name / Email</th>
                        <th className="py-2.5 px-3 font-semibold">Assigned Role Clearance</th>
                        <th className="py-2.5 px-3 font-semibold">Access State</th>
                        <th className="py-2.5 px-3 font-semibold text-right">Authorize Controls</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-900">
                      {usersList.map((user) => (
                        <tr key={user.id} className="hover:bg-gray-900/20 transition-colors">
                          <td className="py-2.5 px-3">
                            <img src={user.avatar} alt="" className="h-8 w-8 rounded-full border border-gray-800" />
                          </td>
                          <td className="py-2.5 px-3">
                            <div className="font-bold text-white">{user.name}</div>
                            <span className="text-[10px] text-gray-500 font-mono">{user.email}</span>
                          </td>
                          <td className="py-2.5 px-3">
                            <select
                              value={user.role}
                              onChange={(e) => handleUserRoleChange(user.id, e.target.value)}
                              className="bg-gray-950 border border-gray-900 rounded p-1 text-[11px] text-red-500 font-extrabold focus:outline-none"
                            >
                              <option value="Super Admin">Super Admin</option>
                              <option value="Admin">Admin</option>
                              <option value="Moderator">Moderator</option>
                              <option value="Uploader">Uploader</option>
                              <option value="Editor">Editor</option>
                              <option value="Support">Support</option>
                              <option value="User">User</option>
                            </select>
                          </td>
                          <td className="py-2.5 px-3 font-mono">
                            <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-extrabold ${
                              user.status === 'active' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/10' : 'bg-red-500/10 text-red-500 border border-red-500/10'
                            }`}>
                              {user.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right space-x-2">
                            {user.status === 'active' ? (
                              <button
                                onClick={() => handleUserStatusChange(user.id, 'banned')}
                                className="text-[10px] font-bold bg-red-600/10 hover:bg-red-600 text-red-400 hover:text-white px-2 py-1 rounded transition-colors"
                              >
                                Ban Account
                              </button>
                            ) : (
                              <button
                                onClick={() => handleUserStatusChange(user.id, 'active')}
                                className="text-[10px] font-bold bg-green-600/10 hover:bg-green-600 text-emerald-400 hover:text-white px-2 py-1 rounded transition-colors"
                              >
                                Revoke Ban
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 8: FILE MEDIA STORAGE ASSETS MANAGER */}
          {activeTab === 'assets' && (
            <div className="space-y-6">
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Upload Simulated files */}
                <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4 h-fit">
                  <h3 className="text-sm font-bold text-white border-b border-gray-900 pb-3 flex items-center gap-1.5">
                    <Image className="h-4.5 w-4.5 text-red-500" /> Index New File Asset
                  </h3>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase">File Asset Title *</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. sololeveling_wide.png" 
                      value={fileName}
                      onChange={(e) => setFileName(e.target.value)}
                      className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs text-gray-200 focus:ring-0 placeholder-gray-600"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase">Target Upload Path URL *</label>
                    <input 
                      type="text" 
                      required
                      placeholder="https://cloudinary.com/ott/..." 
                      value={fileUrl}
                      onChange={(e) => setFileUrl(e.target.value)}
                      className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs font-mono text-gray-200 focus:ring-0 placeholder-gray-600"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Asset Mode</label>
                      <select 
                        value={fileType}
                        onChange={(e) => setFileType(e.target.value as any)}
                        className="w-full bg-gray-950 border border-gray-805 rounded p-2 text-xs text-gray-300 focus:ring-0"
                      >
                        <option value="image">Show Artwork (Image)</option>
                        <option value="video">Trailer Media (Video)</option>
                        <option value="subtitle">MAPPED Subtitles Vtt</option>
                        <option value="logo">UI SVG Vector Logos</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Calculated Size</label>
                      <input 
                        type="text" 
                        value={fileSizeStr}
                        onChange={(e) => setFileSizeStr(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs text-gray-300"
                      />
                    </div>
                  </div>

                  <button 
                    onClick={handleFileAssetUpload}
                    className="w-full py-2 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 font-bold text-xs text-white rounded shadow transition-all"
                  >
                    Index Upload File
                  </button>
                </div>

                {/* Cloud Asset directory index */}
                <div className="col-span-2 bg-gray-950/80 border border-gray-800 rounded-xl p-5 space-y-4">
                  <h3 className="text-sm font-bold text-white border-b border-gray-900 pb-3">
                    📁 Active CDN Storage Directory
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {fileAssets.map((asset) => (
                      <div key={asset.id} className="p-3 bg-gray-950 border border-gray-900 rounded-xl flex gap-3">
                        <div className="h-12 w-12 bg-gray-950 rounded border border-gray-800 flex items-center justify-center text-gray-500 text-xs font-bold font-mono">
                          {asset.type === 'image' ? 'IMG' : asset.type === 'video' ? 'MP4' : 'VTT'}
                        </div>
                        <div className="truncate flex-1 space-y-0.5">
                          <h4 className="text-xs font-bold text-white truncate" title={asset.name}>{asset.name}</h4>
                          <span className="text-[10px] text-gray-500 font-mono block">Size: {asset.size}</span>
                          <span className="text-[9px] text-red-500 font-semibold block">{asset.uploadedAt}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* TAB 9: SECURITY MONITORS & ACTIVITY HISTORY */}
          {activeTab === 'security' && (
            <div className="space-y-6">
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-gray-950 border border-gray-900 rounded-xl p-4 text-left">
                  <span className="text-[10px] font-bold text-gray-500 uppercase">Ecosystem Safety Index</span>
                  <div className="text-2xl font-black text-emerald-400">99.8% Secure</div>
                  <p className="text-[10px] text-gray-500 font-mono">Failed Brutes: 1 attempts blocked</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 rounded-xl p-4 text-left">
                  <span className="text-[10px] font-bold text-gray-500 uppercase">Staff Actions Loggers</span>
                  <div className="text-2xl font-black text-rose-500">Active Audit</div>
                  <p className="text-[10px] text-gray-500 font-mono">Role elevations: 0 unapproved</p>
                </div>
                <div className="bg-gray-950 border border-gray-900 rounded-xl p-4 text-left">
                  <span className="text-[10px] font-bold text-gray-500 uppercase">Automated Backup Cron</span>
                  <div className="text-2xl font-black text-sky-400">Scheduled (24h)</div>
                  <p className="text-[10px] text-gray-500 font-mono">Last successful backup: Yesterday</p>
                </div>
              </div>

              <div className="bg-gray-950/80 border border-gray-800 rounded-xl p-5">
                <h3 className="text-sm font-bold text-white mb-3">
                  🔐 Gatekeeper Security Logs
                </h3>
                <p className="text-[10px] text-gray-500 font-semibold mb-4 leading-normal">
                  Aggressive tracing logging failed administrative handshakes, login sessions, key overrides, API lookups, and country geo IP.
                </p>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-gray-950 text-gray-500 border-b border-gray-900">
                      <tr>
                        <th className="py-2 px-3">Date Time ID</th>
                        <th className="py-2 px-3">Operator ID</th>
                        <th className="py-2 px-3">Action Segment</th>
                        <th className="py-2 px-3">Status</th>
                        <th className="py-2 px-3">Network IP Address</th>
                        <th className="py-2 px-3">Geographic Loc</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-905">
                      {securityLogs.map((log) => (
                        <tr key={log.id} className="hover:bg-gray-900/10">
                          <td className="py-2 px-3 text-gray-400 leading-tight block">{log.timestamp}</td>
                          <td className="py-2 px-3 text-white font-semibold leading-tight">{log.email}</td>
                          <td className="py-2 px-3 text-gray-300 leading-tight">{log.action}</td>
                          <td className="py-2 px-3 leading-tight">
                            <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-extrabold ${
                              log.status === 'Success' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-500'
                            }`}>
                              {log.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-gray-400 leading-tight">{log.ipAddress}</td>
                          <td className="py-2 px-3 text-gray-300 leading-tight">{log.country}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 10: DEPLOYMENT CENTER & PRODUCTION ZIP GENERATION */}
          {activeTab === 'deployment' && (
            <div className="space-y-6 max-w-4xl mx-auto">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                
                {/* CARD 1: NETLIFY 1-CLICK DROP READY STATIC BUNDLE */}
                <div className="bg-gray-950 border border-emerald-950 rounded-xl p-6 text-center space-y-6 relative overflow-hidden flex flex-col justify-between">
                  <div className="absolute top-2.5 right-2.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[8px] font-black tracking-widest uppercase px-1.5 py-0.5 rounded leading-none">
                    Recommended For Netlify Drop
                  </div>
                  
                  <div className="space-y-6">
                    <div className="h-16 w-16 bg-emerald-600/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/20">
                      <Globe className="h-8 w-8" />
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center justify-center gap-1.5">
                        ⚡ Netlify Drop ZIP (Deploy Ready)
                      </h3>
                      <p className="text-xs text-gray-400 font-medium leading-relaxed">
                        Pre-compiled, host-ready static frontend bundle. Download this ZIP and drag-and-drop it onto <strong>app.netlify.com/drop</strong> to go live instantly!
                      </p>
                    </div>

                    <div className="p-4 bg-gray-950 border border-gray-900 rounded-lg text-left text-[11px] space-y-2.5">
                      <span className="text-[10px] font-bold text-gray-500 uppercase block border-b border-gray-950 pb-1">Deployment Highlights</span>
                      <div className="grid grid-cols-1 gap-1.5 text-gray-300 font-mono text-[10px]">
                        <div className="flex items-center gap-1.5"><span className="text-emerald-500 font-bold">✔</span> Pre-bundled index.html static entry at root</div>
                        <div className="flex items-center gap-1.5"><span className="text-emerald-500 font-bold">✔</span> Heavy compressed optimized JS assets folder</div>
                        <div className="flex items-center gap-1.5"><span className="text-emerald-500 font-bold">✔</span> Built Tailwind theme styles compiled natively</div>
                        <div className="flex items-center gap-1.5"><span className="text-emerald-500 font-bold">✔</span> SPA route fallback <code>_redirects</code> included</div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 pt-4 border-t border-gray-900">
                    <button 
                      onClick={generateNetlifyDropZip}
                      disabled={netlifyZipStatus === 'generating'}
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-600/25 transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {netlifyZipStatus === 'generating' ? (
                        <>
                          <RefreshCw className="h-4 w-4 animate-spin" /> Compiling static assets...
                        </>
                      ) : netlifyZipStatus === 'done' ? (
                        <>
                          <CheckCircle className="h-4 w-4" /> Download Drop Ready ZIP again!
                        </>
                      ) : (
                        <>
                          <Download className="h-4 w-4" /> Download Netlify Drop ZIP
                        </>
                      )}
                    </button>
                    <span className="text-[9px] text-gray-500 font-semibold font-mono">
                      Drag-and-drop the downloaded .zip directly on Netlify Drop. No setup or npm build required!
                    </span>
                  </div>
                </div>

                {/* CARD 2: FULL STACK SERVER + UI SOURCE CODE */}
                <div className="bg-gray-950 border border-gray-800 rounded-xl p-6 text-center space-y-6 flex flex-col justify-between">
                  
                  <div className="space-y-6 flex-1 flex flex-col justify-between">
                    <div className="space-y-6">
                      <div className="h-16 w-16 bg-red-600/10 text-red-500 rounded-full flex items-center justify-center mx-auto border border-red-500/20">
                        <FileText className="h-8 w-8" />
                      </div>

                      <div className="space-y-2">
                        <h3 className="text-sm font-black text-white uppercase tracking-wider">📦 Full Project Server + React Code ZIP</h3>
                        <p className="text-xs text-gray-400 font-medium leading-relaxed">
                          This ZIP packages your <strong>entire raw React working directory</strong> alongside Express CMS microservers, database configurations, and Docker files.
                        </p>
                      </div>

                      <div className="p-4 bg-gray-950 border border-gray-900 rounded-lg text-left text-[11px] space-y-2.5">
                        <span className="text-[10px] font-bold text-gray-500 uppercase block border-b border-gray-950 pb-1">Included Project Bundles</span>
                        <div className="grid grid-cols-2 gap-2 text-gray-450 font-mono text-[10px]">
                          <div className="text-red-400">🔥 Full React Source Files</div>
                          <div className="text-emerald-400">☁️ Netlify config files</div>
                          <div>📦 Node Express Server (CJS)</div>
                          <div>📡 Live Socket controllers</div>
                          <div>🎨 Theme settings JSON</div>
                          <div>🐳 Dynamic Dockerfile templates</div>
                          <div>🔐 env.production template</div>
                          <div>🗄️ Drizzle postgres schemas</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 pt-4 border-t border-gray-900">
                    <button 
                      onClick={generateProductionZip}
                      disabled={zipStatus === 'generating'}
                      className="w-full py-3 bg-red-650 hover:bg-red-750 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-red-600/25 transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {zipStatus === 'generating' ? (
                        <>
                          <RefreshCw className="h-4 w-4 animate-spin" /> Packaging Files...
                        </>
                      ) : zipStatus === 'done' ? (
                        <>
                          <Check className="h-4 w-4" /> Download Complete ZIP again
                        </>
                      ) : (
                        <>
                          <Download className="h-4 w-4" /> Download Full Source ZIP
                        </>
                      )}
                    </button>
                    <span className="text-[9px] text-gray-500 font-semibold font-mono">
                      Perfect for VPS, Docker Engine, dynamic cloud servers, or importing directly to GitHub repos.
                    </span>
                  </div>
                </div>

              </div>

              {/* PLATFORM-SPECIFIC ONE-CLICK DEPLOYMENT CONFIGURATIONS */}
              <div className="bg-gray-950 border border-gray-900 rounded-xl p-6 text-left space-y-6 max-w-4xl mx-auto">
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <Server className="h-4.5 w-4.5 text-rose-500" /> Platform Specific 1-Click Deployment (Railway & Render Configurations)
                  </h3>
                  <p className="text-xs text-gray-400 mt-1">
                    আমরা ডাউনলোড করা জিপ ফাইলে <strong>Railway</strong> এবং <strong>Render</strong> এর জন্য সম্পূর্ণ কনফিগারেশন যুক্ত করে দিয়েছি। নিচের সেটিংস এবং ভ্যারিয়েবলগুলো ড্যাশবোর্ডে প্রদান করুন:
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Railway Guide */}
                  <div className="bg-gray-900/40 border border-gray-900 rounded-xl p-4 space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] bg-red-650/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded font-black tracking-widest uppercase">RAILWAY READY</span>
                      <h4 className="text-xs font-bold text-white">ডিপ্লয় গাইড (Railway Deploy)</h4>
                    </div>
                    <ul className="text-[11px] text-gray-300 space-y-1.5 list-disc pl-4 leading-relaxed font-sans">
                      <li>জিপ ফাইলটি নামিয়ে আনজিপ করুন এবং আপনার <strong>GitHub</strong> এ পুশ করুন।</li>
                      <li>Railway-তে লগইন করে <strong>New Project &rarr; Deploy from GitHub</strong> সিলেক্ট করুন।</li>
                      <li>রুট ডিরেক্টরির <code>Dockerfile</code> ব্যবহার করে অ্যাপটি স্বয়ংক্রিয়ভাবে বিল্ড হবে।</li>
                      <li><strong>Variables API:</strong> <code>GEMINI_API_KEY</code> এবং <code>PORT=3000</code> অ্যাড করুন।</li>
                    </ul>
                  </div>

                  {/* Render Guide */}
                  <div className="bg-gray-900/40 border border-gray-950 rounded-xl p-4 space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] bg-emerald-650/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-black tracking-widest uppercase">RENDER BLUEPRINTS</span>
                      <h4 className="text-xs font-bold text-white">ডিপ্লয় গাইড (Render Deploy)</h4>
                    </div>
                    <ul className="text-[11px] text-gray-300 space-y-1.5 list-disc pl-4 leading-relaxed font-sans">
                      <li>প্রজেক্ট ফাইলের ভেতর <code>render.yaml</code> কনফিগারেশন অলরেডি রেডি আছে।</li>
                      <li>Render-এ গিয়ে <strong>Blueprints &rarr; Connect GitHub</strong> সিলেক্ট করুন।</li>
                      <li>এটি ব্লুপ্রিন্ট কনফিগারেশন ফাইলের মাধ্যমে একা একাই ডেটাবেস এবং ব্যাকএন্ড সার্ভিস রুট করে ডিপ্লয় করে দিবে।</li>
                    </ul>
                  </div>
                </div>

                {/* Environment Variables Sandbox Config */}
                <div className="p-4 bg-gray-900/20 border border-gray-900 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                      <Key className="h-3.5 w-3.5 text-yellow-500" /> Dynamic Environment Variables Template
                    </span>
                    <span className="text-[9px] text-gray-500 font-mono font-bold">PORT GENERATED DYNAMICALLY BY ENVIRONMENT</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="bg-black/40 p-2.5 rounded border border-gray-900 flex justify-between items-center">
                      <span className="text-[10px] text-gray-400 font-mono font-bold">NODE_ENV</span>
                      <span className="text-[10px] font-bold text-emerald-400 font-mono">production</span>
                    </div>
                    <div className="bg-black/40 p-2.5 rounded border border-gray-900 flex justify-between items-center">
                      <span className="text-[10px] text-gray-400 font-mono font-bold">PORT</span>
                      <span className="text-[10px] font-bold text-emerald-400 font-mono">3000 (Dynamic)</span>
                    </div>
                    <div className="bg-black/40 p-2.5 rounded border border-gray-900 flex justify-between items-center text-left">
                      <span className="text-[10px] text-gray-400 font-mono font-bold">APP_URL</span>
                      <span className="text-[10px] font-bold text-red-400 font-mono truncate max-w-[150px]">{window.location.origin}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* SANDBOX PREVIEW HELPER WARNING */}
              <div className="mt-8 bg-amber-500/10 border border-amber-500/20 rounded-xl p-5 text-left max-w-4xl mx-auto space-y-3">
                <div className="flex items-center gap-2.5 text-amber-400">
                  <AlertTriangle className="h-5 w-5 shrink-0" />
                  <h4 className="text-xs font-black uppercase tracking-wider">Browser Sandbox Warning (If ZIP download blocked)</h4>
                </div>
                <p className="text-[11px] text-gray-300 leading-relaxed font-sans">
                  Because this development environment runs inside an <strong>AI Studio preview iframe</strong>, Google Chrome and other browsers will often strictly block client-side files or zip generators from triggering automated downloads.
                </p>
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button 
                    onClick={() => {
                      window.open(window.location.origin, '_blank');
                    }}
                    className="px-4.5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-[10px] uppercase tracking-wider rounded-lg shadow transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Globe className="h-4.5 w-4.5" /> Open App in a New Tab to Download
                  </button>
                  <span className="text-[10px] text-gray-450 font-medium font-sans">
                    ← After opening, navigate to Admin Panel &rarr; Deployment inside the new tab and download smoothly without iframe blocking!
                  </span>
                </div>
              </div>

            </div>
          )}

          {/* TAB: REAL-TIME SYNC SETTINGS */}
          {activeTab === 'realtime' && (
            <div className="space-y-6 max-w-5xl mx-auto text-left">
              
              {/* Header Title Cover */}
              <div className="bg-gray-950 border border-gray-900 rounded-xl p-6 space-y-6">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-gray-900 pb-5">
                  <div>
                    <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                      <RefreshCw className="h-4.5 w-4.5 text-red-500 animate-spin animate-duration-3000" /> Real-Time Live Sync & Collaboration Settings
                    </h3>
                    <p className="text-xs text-gray-400 font-medium mt-1">
                      Manage absolute multi-device synchronization, live Server-Sent Events (SSE) flows, and simulated active co-editors.
                    </p>
                  </div>
                  
                  <button
                    onClick={() => {
                      if (onTriggerSharedDataRefresh) {
                        onTriggerSharedDataRefresh();
                      }
                    }}
                    className="px-4 py-2 bg-gray-900 hover:bg-gray-850 text-white font-bold text-xs uppercase tracking-wider rounded-lg border border-gray-800 hover:border-gray-700 active:scale-95 transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className="h-3.5 w-3.5" /> Force Sync Update
                  </button>
                </div>

                {/* Explanation Context */}
                <div className="bg-gradient-to-br from-red-950/15 to-rose-950/5 border border-red-900/30 p-4 rounded-xl space-y-2">
                  <div className="flex gap-2.5">
                    <AlertTriangle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">রিয়েল-টাইম লাইভ এবং মাল্টি-ইউজার সিঙ্ক্রোনাইজেশন কি?</h4>
                      <p className="text-xs text-gray-300 leading-relaxed mt-1">
                        এটি একটি সিঙ্ক্রোনাইজড ব্যাকএন্ড আর্কিটেকচার যা সার্ভারের সাথে সংযুক্ত প্রতিটি ওপেন ট্যাবে ডাটা পরিবর্তন করার সাথে সাথে অন্য ট্যাবে রিফ্রেশ ছাড়াই সাথে সাথে আপডেট প্রকাশ করে। আপনি অথবা যেকোনো সহযোগী মডারেটর কোনো এনিমে বা পর্ব আপডেট করলে অন্য সবার স্ক্রিনে সেটি পলকের মধ্যে রিয়েল-টাইমে দৃশ্যমান হয়ে যাবে!
                      </p>
                      <p className="text-[11px] text-gray-400 leading-relaxed mt-1.5">
                        <strong>English Context:</strong> Built with Server-Sent Events (SSE) as the underlying engine. Full-duplex client states receive broadcasts on the `/api/realtime-stream` endpoint, saving database keys instantly from local changes to keep everyone synchronously in style.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Interactive Diagnostics Bento Section */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {/* Card 1: Connection status */}
                  <div className="bg-gray-900/40 p-4 rounded-xl border border-gray-900/80 flex flex-col justify-between">
                    <span className="text-[10px] font-bold text-gray-450 uppercase tracking-widest">Network Medium</span>
                    <div className="my-2.5 flex items-center gap-2">
                      <span className={`h-2.5 w-2.5 rounded-full ${realtimeConnected ? 'bg-green-500 animate-pulse' : 'bg-yellow-500'}`} />
                      <span className="text-xs font-black text-white uppercase tracking-widest leading-none">
                        {realtimeConnected ? 'SSE ACTIVE' : 'POLLING FALLBACK'}
                      </span>
                    </div>
                    <p className="text-[10px] text-gray-500 leading-tight">Server-Sent Events streaming is continuous</p>
                  </div>

                  {/* Card 2: Active presences */}
                  <div className="bg-gray-900/40 p-4 rounded-xl border border-gray-900/80 flex flex-col justify-between">
                    <span className="text-[10px] font-bold text-gray-450 uppercase tracking-widest">Active Presences</span>
                    <div className="my-2.5 flex items-baseline gap-1.5">
                      <span className="text-2xl font-black text-rose-500">{onlinePresences.length || 1}</span>
                      <span className="text-xs text-gray-400 font-bold">session(s) online</span>
                    </div>
                    <p className="text-[10px] text-gray-500 leading-tight">Unique browsers connected right now</p>
                  </div>

                  {/* Card 3: Simulated status */}
                  <div className="bg-gray-900/40 p-4 rounded-xl border border-gray-900/80 flex flex-col justify-between">
                    <span className="text-[10px] font-bold text-gray-455 uppercase tracking-widest">Co-Editor Simulation</span>
                    <div className="my-2.5">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full inline-block ${simulatedColleagueActive ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-gray-800 text-gray-400'}`}>
                        {simulatedColleagueActive ? 'KAZUTO KIRIGAYA' : 'INACTIVE'}
                      </span>
                    </div>
                    <p className="text-[10px] text-gray-500 leading-tight">Simulates background actions for local tests</p>
                  </div>

                  {/* Card 4: Last state packet latency */}
                  <div className="bg-gray-900/40 p-4 rounded-xl border border-gray-900/80 flex flex-col justify-between">
                    <span className="text-[10px] font-bold text-gray-450 uppercase tracking-widest">Sync latency</span>
                    <div className="my-2.5">
                      <span className="text-xs font-mono text-emerald-400 font-bold leading-none inline-block">&lt; 12ms (Direct)</span>
                    </div>
                    <p className="text-[10px] text-gray-500 leading-tight">Time to propagate edit updates from cloud node</p>
                  </div>
                </div>

                {/* Primary Control Toggles */}
                <div className="bg-gray-900/30 p-5 rounded-xl border border-gray-900 max-w-3xl space-y-4">
                  <h4 className="text-xs font-bold text-gray-300 uppercase tracking-wider">রিয়েল-টাইম সিঙ্ক কন্ট্রোল প্যানেল (Control Switches)</h4>
                  
                  <div className="divide-y divide-gray-900">
                    {/* Toggle A */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between py-4 gap-3">
                      <div>
                        <h5 className="text-xs font-bold text-white flex items-center gap-2">
                          <span className={`h-2 w-2 rounded-full ${realtimeEnabled ? 'bg-green-500' : 'bg-gray-600'}`} />
                          রিয়েল-টাইম লাইভ সিঙ্ক্রোনাইজেশন চালু করুন (Enable Live Duplex)
                        </h5>
                        <p className="text-[11px] text-gray-400 mt-0.5">
                          Turn on instant web browser message listening on server-sent events socket.
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          if (onSetRealtimeEnabled) {
                            onSetRealtimeEnabled(!realtimeEnabled);
                          }
                        }}
                        className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          realtimeEnabled ? 'bg-green-500' : 'bg-gray-800'
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                            realtimeEnabled ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>

                    {/* Toggle B */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between py-4 gap-3">
                      <div>
                        <h5 className="text-xs font-bold text-white flex items-center gap-2">
                          <span className={`h-2 w-2 rounded-full ${simulatedColleagueActive ? 'bg-rose-500 animate-ping' : 'bg-gray-600'}`} />
                          সহযোগী সম্পাদক সিমুলেশন অন করুন (Enable Co-Editor Activity Simulation)
                        </h5>
                        <p className="text-[11px] text-gray-400 mt-0.5">
                          Simulate external user edits every 12 seconds to test live sync behavior.
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          if (onSetSimulatedColleagueActive) {
                            onSetSimulatedColleagueActive(!simulatedColleagueActive);
                          }
                        }}
                        className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          simulatedColleagueActive ? 'bg-rose-500' : 'bg-gray-800'
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                            simulatedColleagueActive ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Custom Connection stream link override section */}
                <div className="bg-gray-900/30 p-5 rounded-xl border border-gray-900 max-w-3xl space-y-4">
                  <div>
                    <h4 className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Key className="h-4 w-4 text-emerald-500" /> কাস্টম রিয়েল-টাইম কানেকশন লিংক (Custom Stream Link Connection Override)
                    </h4>
                    <p className="text-[11px] text-gray-400 mt-1 leading-relaxed">
                      হঠাৎ করে রিয়েল-টাইম কানেকশন বা ওয়েব সকেট ডিস্টার্ব করলে অথবা অন্য কোনো কাস্টম সকেট / ওয়েব এপিআই রিয়েলটাইম সার্ভার ব্যবহার করতে নতুন লিংক সেট করুন। ডিফল্ট হিসেবে খালি রাখলে অ্যাপটির নিজস্ব ব্যাকএন্ড সকেট <code className="text-red-400 bg-red-950/10 px-1 py-0.5 rounded">/api/realtime-stream</code> ব্যবহার হবে।
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        placeholder="e.g. https://my-custom-socket-engine.com/streams"
                        value={localUrlInput}
                        onChange={(e) => setLocalUrlInput(e.target.value)}
                        className="flex-1 bg-black border border-gray-800 px-3.5 py-2 rounded-lg text-xs text-white font-mono placeholder:text-gray-600 focus:outline-none focus:border-rose-500 transition"
                      />
                      
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            if (onSetCustomRealtimeUrl) {
                              onSetCustomRealtimeUrl(localUrlInput.trim());
                            }
                          }}
                          className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase tracking-wider rounded-lg active:scale-95 transition flex items-center gap-1 cursor-pointer"
                        >
                          <Save className="h-3.5 w-3.5" /> Save Link
                        </button>

                        <button
                          onClick={() => {
                            setLocalUrlInput('');
                            if (onSetCustomRealtimeUrl) {
                              onSetCustomRealtimeUrl('');
                            }
                          }}
                          className="px-3 py-2 bg-gray-850 hover:bg-gray-800 text-gray-300 font-bold text-xs uppercase tracking-wider rounded-lg active:scale-95 transition cursor-pointer"
                        >
                          Reset Default
                        </button>
                      </div>
                    </div>

                    <div className="text-[10px] text-gray-500 font-mono flex items-center justify-between p-2 rounded bg-black/40 border border-gray-900/50">
                      <span>CURRENT RESOLVED PATH:</span>
                      <span className="text-rose-400 font-bold">
                        {customRealtimeUrl ? customRealtimeUrl : '/api/realtime-stream (Default Native Server)'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Grid for Online Presence list & Activity logs */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
                  
                  {/* Left Column: Active Connected Users Map */}
                  <div className="bg-gray-900/20 rounded-xl border border-gray-900 p-5 space-y-4">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <Users className="h-4 w-4 text-rose-500" /> Active Connected Users Presence Ecosystem
                    </h4>
                    <p className="text-[11px] text-gray-400 text-left">
                      Those users are currently browsing and streaming content on this database link.
                    </p>

                    <div className="space-y-3 max-h-[280px] overflow-y-auto pr-1">
                      {onlinePresences.length === 0 ? (
                        <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-950 border border-gray-950">
                          <img 
                            src={currentUser?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'} 
                            alt="" 
                            className="h-7 w-7 rounded-full border border-red-500"
                          />
                          <div className="flex-1 text-left">
                            <span className="text-xs font-bold text-gray-300 block">{currentUser?.name || 'You'} (You)</span>
                            <span className="text-[10px] text-gray-500 block">{currentUser?.role || 'User'}</span>
                          </div>
                          <span className="text-[10px] text-green-400 font-bold bg-green-500/10 px-2 py-0.5 rounded border border-green-500/20">
                            Active Session
                          </span>
                        </div>
                      ) : (
                        onlinePresences.map((pres, i) => (
                          <div key={pres.userId || i} className="flex items-center gap-3 p-3 rounded-lg bg-gray-950 border border-gray-900 hover:border-gray-800 transition duration-150">
                            <img 
                              src={pres.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'} 
                              alt="" 
                              className="h-7 w-7 rounded-full border border-gray-800" 
                            />
                            <div className="flex-1 text-left">
                              <span className="text-xs font-bold text-gray-200 block leading-tight">
                                {pres.name} {pres.userId === currentUser?.id ? '(You)' : ''}
                              </span>
                              <span className="text-[10px] text-red-400 font-mono tracking-wide">
                                {pres.role}
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5 animate-pulse">
                              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                              <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest">LIVE</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Right Column: Live Event Broadcast Feed Terminal */}
                  <div className="bg-gray-900/20 rounded-xl border border-gray-900 p-5 space-y-4">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <Activity className="h-4 w-4 text-amber-500" /> Server Broadcast Activity Logs Feed
                    </h4>
                    <p className="text-[11px] text-gray-400 text-left">
                      Live event streams output logs directly here when you modify components, media, or settings on screen.
                    </p>

                    <div className="bg-black/85 rounded-xl border border-gray-900 p-4 font-mono text-[10px] space-y-2 max-h-[250px] overflow-y-auto">
                      <div className="text-gray-500 mb-1 border-b border-gray-900 pb-1 flex items-center justify-between">
                        <span>SYS.LOG // STREAM INITIALIZED</span>
                        <span>{new Date().toLocaleDateString()}</span>
                      </div>
                      
                      {realtimeEvents.length === 0 ? (
                        <div className="text-gray-500 text-center py-8">
                          No realtime notifications captured yet. Toggle Sim-editor or modify system entities to trigger!
                        </div>
                      ) : (
                        realtimeEvents.map((evt) => (
                          <div key={evt.id} className="text-left py-1 text-gray-300 leading-relaxed border-b border-gray-900/40">
                            <span className="text-red-500 font-bold mr-1.5">[{evt.timestamp || 'LOG'}]</span>
                            <span className="text-blue-400 font-bold mr-1.5">{evt.eventName}</span>
                            <span className="text-gray-400">{evt.description}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                </div>

              </div>

            </div>
          )}

          {/* TAB 11: EPISODES BY LANGUAGE MANAGER */}
          {activeTab === 'episodesByLanguage' && (
            <div className="space-y-6 max-w-5xl mx-auto text-left">
              
              <div className="bg-gray-950 border border-gray-900 rounded-xl p-6 space-y-6">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-gray-900 pb-5">
                  <div>
                    <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                      <Play className="h-4.5 w-4.5 text-red-500 animate-pulse animate-duration-1000" /> Language Episode Manager
                    </h3>
                    <p className="text-xs text-gray-400 font-medium mt-1">
                      Manage specific episode audio tracks, streams, sources, and durations mapped per Language and Anime.
                    </p>
                  </div>
                  
                  <button
                    onClick={() => {
                      setAddEpName('');
                      setAddEpNumber((episodesList.filter(ep => ep.animeId === selectedAnimeIdForEp && (ep.language || 'Japanese') === selectedLanguageForEp).length + 1).toString());
                      setAddEpDuration('24');
                      setAddEpVideoUrl('https://www.w3schools.com/html/mov_bbb.mp4');
                      setAddEpSeasonNumber(1);
                      setShowAddEpModal(true);
                    }}
                    disabled={!selectedAnimeIdForEp}
                    className="px-4 py-2 bg-red-655 hover:bg-red-750 disabled:bg-gray-900 disabled:text-gray-600 disabled:border-gray-900 text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-lg shadow-red-600/10 hover:shadow-red-600/20 active:scale-95 transition flex items-center gap-1.5 cursor-pointer border border-red-500/20"
                  >
                    <Plus className="h-4 w-4" /> Add custom episode
                  </button>
                </div>

                {/* Filter section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-gray-900/40 p-4 rounded-xl border border-gray-900">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-gray-450 uppercase tracking-wide flex items-center gap-1">
                      <Globe className="h-3.5 w-3.5 text-red-400" /> Select Audio Language
                    </label>
                    <div className="flex gap-2">
                      {(['Japanese', 'English', 'Hindi', 'Bangla'] as const).map((lang) => {
                        const count = episodesList.filter(ep => (ep.language || 'Japanese') === lang).length;
                        return (
                          <button
                            key={lang}
                            type="button"
                            onClick={() => setSelectedLanguageForEp(lang)}
                            className={`flex-1 py-2 rounded-lg text-xs font-bold border transition ${
                              selectedLanguageForEp === lang
                                ? 'bg-red-600/20 text-white border-red-500/50'
                                : 'bg-gray-950 text-gray-400 border-gray-900 hover:text-white hover:border-gray-800'
                            }`}
                          >
                            {lang}
                            <span className="ml-1 text-[9px] font-mono opacity-60">({count})</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-gray-450 uppercase tracking-wide flex items-center gap-1">
                      <FilmIcon className="h-3.5 w-3.5 text-red-400" /> Select Target Anime
                    </label>
                    <select
                      value={selectedAnimeIdForEp}
                      onChange={(e) => setSelectedAnimeIdForEp(e.target.value)}
                      className="w-full bg-gray-950 border border-gray-900 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-red-650 focus:outline-none"
                    >
                      <option value="">-- Choose Anime Catalog --</option>
                      {animeList.map((anime) => {
                        const countInLang = episodesList.filter(
                          ep => ep.animeId === anime.id && (ep.language || 'Japanese') === selectedLanguageForEp
                        ).length;
                        return (
                          <option key={anime.id} value={anime.id}>
                            {anime.name} ({anime.year}) — {countInLang} Episodes in {selectedLanguageForEp}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                </div>

                {/* Episode stats & Listing */}
                {selectedAnimeIdForEp ? (
                  (() => {
                    const selectedAnime = animeList.find(a => a.id === selectedAnimeIdForEp);
                    const listForSel = episodesList
                      .filter(ep => ep.animeId === selectedAnimeIdForEp && (ep.language || 'Japanese') === selectedLanguageForEp)
                      .sort((a, b) => a.number - b.number);

                    return (
                      <div className="space-y-4">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 font-mono text-[10px] bg-red-650/5 border border-red-500/10 rounded-lg px-4 py-2.5 text-red-400">
                          <span>Anime Selected: <strong className="text-white font-sans">{selectedAnime?.name}</strong></span>
                          <span>Active Language: <strong className="text-white font-sans">{selectedLanguageForEp} Audio Track</strong></span>
                          <span>Total Recorded: <strong className="text-white">{listForSel.length} Episode(s)</strong></span>
                        </div>

                        {listForSel.length > 0 ? (
                          <div className="overflow-x-auto rounded-xl border border-gray-900 bg-gray-950">
                            <table className="w-full text-xs text-left">
                              <thead>
                                <tr className="border-b border-gray-900 text-gray-400 font-bold uppercase tracking-wider text-[10px] bg-gray-900/20">
                                  <th className="py-3 px-4 w-16">No.</th>
                                  <th className="py-3 px-4">Episode Title</th>
                                  <th className="py-3 px-4 w-28">Season</th>
                                  <th className="py-3 px-4 w-24">Duration</th>
                                  <th className="py-3 px-4">Streaming Endpoint (Video URL)</th>
                                  <th className="py-3 px-4 w-24 text-right">Actions</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-gray-900 text-gray-300">
                                {listForSel.map((ep) => {
                                  // Find season number
                                  const seasonNo = seasonsList.find(s => s.id === ep.seasonId)?.number || 1;
                                  return (
                                    <tr key={ep.id} className="hover:bg-gray-900/30 transition">
                                      <td className="py-3 px-4 font-mono font-medium text-red-400">EP {ep.number}</td>
                                      <td className="py-3 px-4 font-bold text-white leading-tight">{ep.name}</td>
                                      <td className="py-3 px-4">
                                        <span className="bg-gray-900 px-2 py-0.5 rounded text-[10px] font-semibold text-gray-400 border border-gray-800">
                                          Season {seasonNo}
                                        </span>
                                      </td>
                                      <td className="py-3 px-4 font-mono text-gray-400">{ep.duration} Mins</td>
                                      <td className="py-3 px-4 truncate max-w-[200px] text-gray-400 font-mono text-[10px]" title={ep.videoUrl}>
                                        {ep.videoUrl}
                                      </td>
                                      <td className="py-3 px-4">
                                        <div className="flex items-center justify-end gap-1.5">
                                          <button
                                            type="button"
                                            onClick={() => {
                                              setEditingEp(ep);
                                              setEditEpName(ep.name);
                                              setEditEpNumber(ep.number.toString());
                                              setEditEpDuration(ep.duration.toString());
                                              setEditEpVideoUrl(ep.videoUrl);
                                              setEditEpSeasonNumber(seasonNo);
                                            }}
                                            className="p-1 px-2.5 bg-gray-900 hover:bg-gray-800 border border-gray-800 rounded text-[10px] font-bold text-gray-300 transition cursor-pointer"
                                            title="Edit Episode Details"
                                          >
                                            Edit
                                          </button>
                                          <button
                                            type="button"
                                            onClick={() => {
                                              if (confirm(`Remove Episode ${ep.number}: "${ep.name}" in (${selectedLanguageForEp})?`)) {
                                                const updated = episodesList.filter(e => e.id !== ep.id);
                                                onUpdateEpisodesList(updated);
                                                onAddRealtimeEvent({
                                                  id: 'evt-' + Date.now(),
                                                  eventName: 'episode_deleted',
                                                  timestamp: 'Now',
                                                  description: `Removed Episode ${ep.number} of ${selectedAnime?.name} under (${selectedLanguageForEp}) track.`,
                                                  status: 'warn'
                                                });
                                                triggerNotificationBanner(`Deleted Episode ${ep.number} in ${selectedLanguageForEp}!`);
                                              }
                                            }}
                                            className="p-1 px-2 text-[10px] font-bold bg-red-600/10 hover:bg-red-650 hover:text-white border border-red-900/30 text-rose-400 rounded transition cursor-pointer"
                                            title="Delete"
                                          >
                                            Delete
                                          </button>
                                        </div>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        ) : (
                          <div className="bg-gray-950 border border-dashed border-gray-900 rounded-xl py-12 text-center text-gray-500 font-semibold text-xs space-y-2">
                            <p>No episodes are registered for this anime in {selectedLanguageForEp} yet.</p>
                            <p className="text-[10px] text-gray-600 font-normal">Click the "Add custom episode" trigger above to link a stream track catalog.</p>
                          </div>
                        )}
                      </div>
                    );
                  })()
                ) : (
                  <div className="bg-gray-950 border border-dashed border-gray-900 rounded-xl py-12 text-center text-gray-500 font-semibold text-xs">
                    Please select a target Anime above to view catalog list.
                  </div>
                )}
              </div>

              {/* ADD CUSTOM EPISODE MODAL */}
              {showAddEpModal && (
                <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-55 overflow-y-auto backdrop-blur-sm">
                  <div className="bg-gray-950 border border-gray-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200 text-left">
                    <div className="px-6 py-4 border-b border-gray-900 flex items-center justify-between">
                      <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                        <Plus className="h-4.5 w-4.5 text-red-500" /> Catalog: Register New Episode
                      </h3>
                      <button
                        type="button"
                        onClick={() => setShowAddEpModal(false)}
                        className="text-gray-500 hover:text-white text-xs font-bold uppercase transition"
                      >
                        ✕ Close
                      </button>
                    </div>

                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!addEpName || !addEpNumber) return;

                        const num = parseInt(addEpNumber);
                        const existingAnime = animeList.find(a => a.id === selectedAnimeIdForEp);
                        if (!existingAnime) return;

                        const targetSeasonId = `s-${selectedAnimeIdForEp}_${addEpSeasonNumber}`;
                        const findSeason = seasonsList.find(s => s.id === targetSeasonId);

                        if (!findSeason) {
                          const newSeason: Season = {
                            id: targetSeasonId,
                            animeId: selectedAnimeIdForEp,
                            name: `Season ${addEpSeasonNumber}`,
                            number: addEpSeasonNumber
                          };
                          onUpdateSeasonsList([...seasonsList, newSeason]);
                        }

                        const newEp: Episode = {
                          id: `e-${selectedAnimeIdForEp}_${addEpSeasonNumber}_${num}_${selectedLanguageForEp.toLowerCase()}`,
                          seasonId: targetSeasonId,
                          animeId: selectedAnimeIdForEp,
                          name: addEpName,
                          number: num,
                          duration: parseInt(addEpDuration) || 24,
                          videoUrl: addEpVideoUrl,
                          subtitleUrl: '',
                          views: 0,
                          language: selectedLanguageForEp,
                          downloads: [
                            { id: `dl-${selectedAnimeIdForEp}_ep-${num}-${selectedLanguageForEp.toLowerCase()}-g`, label: `${selectedLanguageForEp} Google Drive Mirror`, url: addEpVideoUrl }
                          ],
                          sources: []
                        };

                        const filtered = episodesList.filter(ep => 
                          !(ep.animeId === selectedAnimeIdForEp && ep.seasonId === targetSeasonId && ep.number === num && (ep.language || 'Japanese') === selectedLanguageForEp)
                        );

                        onUpdateEpisodesList([...filtered, newEp]);

                        onAddRealtimeEvent({
                          id: 'evt-' + Date.now(),
                          eventName: 'episode_uploaded',
                          timestamp: 'Now',
                          description: `Registered Episode ${num}: "${addEpName}" in ${selectedLanguageForEp} for ${existingAnime.name}.`,
                          status: 'success'
                        });

                        setShowAddEpModal(false);
                        triggerNotificationBanner(`Episode ${num} registered successfully in ${selectedLanguageForEp}!`);
                      }}
                      className="p-6 space-y-4"
                    >
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-gray-400 uppercase">Season Number</label>
                          <input
                            type="number"
                            required
                            min={1}
                            value={addEpSeasonNumber}
                            onChange={(e) => setAddEpSeasonNumber(parseInt(e.target.value) || 1)}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-gray-400 uppercase">Episode Number</label>
                          <input
                            type="number"
                            required
                            min={1}
                            value={addEpNumber}
                            onChange={(e) => setAddEpNumber(e.target.value)}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase">Episode Title Name</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Awakening Of the Dark Flame"
                          value={addEpName}
                          onChange={(e) => setAddEpName(e.target.value)}
                          className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase">Running Duration (Minutes)</label>
                        <input
                          type="number"
                          required
                          min={1}
                          value={addEpDuration}
                          onChange={(e) => setAddEpDuration(e.target.value)}
                          className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase">Streaming Video URL Endpoint *</label>
                        <input
                          type="url"
                          required
                          value={addEpVideoUrl}
                          onChange={(e) => setAddEpVideoUrl(e.target.value)}
                          className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none font-mono text-gray-300"
                        />
                      </div>

                      <div className="pt-4 border-t border-gray-900 flex justify-end gap-3">
                        <button
                          type="button"
                          onClick={() => setShowAddEpModal(false)}
                          className="px-4 py-2 bg-gray-900 hover:bg-gray-800 border border-gray-800 rounded-lg text-xs font-semibold text-gray-300"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg text-xs font-bold text-white shadow-lg shadow-red-600/20"
                        >
                          Register Episode
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

              {/* EDIT SPECIFIC EPISODE MODAL */}
              {editingEp && (
                <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-55 overflow-y-auto backdrop-blur-sm">
                  <div className="bg-gray-950 border border-gray-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200 text-left">
                    <div className="px-6 py-4 border-b border-gray-900 flex items-center justify-between">
                      <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                        <Edit className="h-4.5 w-4.5 text-red-500 animate-pulse" /> Edit Episode Track
                      </h3>
                      <button
                        type="button"
                        onClick={() => setEditingEp(null)}
                        className="text-gray-500 hover:text-white text-xs font-bold uppercase transition"
                      >
                        ✕ Close
                      </button>
                    </div>

                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!editingEp || !editEpName || !editEpNumber) return;

                        const num = parseInt(editEpNumber);
                        const existingAnime = animeList.find(a => a.id === selectedAnimeIdForEp);
                        if (!existingAnime) return;

                        const targetSeasonId = `s-${selectedAnimeIdForEp}_${editEpSeasonNumber}`;
                        const findSeason = seasonsList.find(s => s.id === targetSeasonId);

                        if (!findSeason) {
                          const newSeason: Season = {
                            id: targetSeasonId,
                            animeId: selectedAnimeIdForEp,
                            name: `Season ${editEpSeasonNumber}`,
                            number: editEpSeasonNumber
                          };
                          onUpdateSeasonsList([...seasonsList, newSeason]);
                        }

                        // Update list
                        const updated = episodesList.map(ep => {
                          if (ep.id === editingEp.id) {
                            return {
                              ...ep,
                              name: editEpName,
                              number: num,
                              duration: parseInt(editEpDuration) || 24,
                              videoUrl: editEpVideoUrl,
                              seasonId: targetSeasonId,
                              language: selectedLanguageForEp
                            };
                          }
                          return ep;
                        });

                        onUpdateEpisodesList(updated);

                        onAddRealtimeEvent({
                          id: 'evt-' + Date.now(),
                          eventName: 'episode_uploaded',
                          timestamp: 'Now',
                          description: `Modified Episode details: #${num} "${editEpName}" underneath ${existingAnime.name}.`,
                          status: 'info'
                        });

                        setEditingEp(null);
                        triggerNotificationBanner('Episode track information saved successfully!');
                      }}
                      className="p-6 space-y-4"
                    >
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-gray-400 uppercase">Season Number</label>
                          <input
                            type="number"
                            required
                            min={1}
                            value={editEpSeasonNumber}
                            onChange={(e) => setEditEpSeasonNumber(parseInt(e.target.value) || 1)}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-gray-400 uppercase">Episode Number</label>
                          <input
                            type="number"
                            required
                            min={1}
                            value={editEpNumber}
                            onChange={(e) => setEditEpNumber(e.target.value)}
                            className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase">Episode Title Name</label>
                        <input
                          type="text"
                          required
                          value={editEpName}
                          onChange={(e) => setEditEpName(e.target.value)}
                          className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none shadow"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase">Running Duration (Minutes)</label>
                        <input
                          type="number"
                          required
                          min={1}
                          value={editEpDuration}
                          onChange={(e) => setEditEpDuration(e.target.value)}
                          className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase">Streaming Video URL Endpoint *</label>
                        <input
                          type="url"
                          required
                          value={editEpVideoUrl}
                          onChange={(e) => setEditEpVideoUrl(e.target.value)}
                          className="w-full bg-gray-950 border border-gray-800 rounded p-2 text-xs focus:ring-1 focus:ring-red-650 focus:outline-none font-mono text-gray-300"
                        />
                      </div>

                      <div className="pt-4 border-t border-gray-900 flex justify-end gap-3">
                        <button
                          type="button"
                          onClick={() => setEditingEp(null)}
                          className="px-4 py-2 bg-gray-900 hover:bg-gray-800 border border-gray-800 rounded-lg text-xs font-semibold text-gray-300"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg text-xs font-bold text-white shadow-lg shadow-red-600/20"
                        >
                          Save Changes
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

            </div>
          )}

        </main>
      </div>

    </div>
  );
}

// Simple fallback icon
function FilmIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <rect width="18" height="18" x="3" y="3" rx="2" />
      <path d="M7 3v18" />
      <path d="M17 3v18" />
      <path d="M3 7.5h4" />
      <path d="M3 12h4" />
      <path d="M3 16.5h4" />
      <path d="M17 7.5h4" />
      <path d="M17 12h4" />
      <path d="M17 16.5h4" />
    </svg>
  );
}
